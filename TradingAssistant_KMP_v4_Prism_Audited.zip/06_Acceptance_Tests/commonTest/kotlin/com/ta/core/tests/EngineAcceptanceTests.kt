package com.ta.core.tests

import com.ta.core.backtest.BacktestAndEvaluatorEngine
import com.ta.core.quant.BarNode
import com.ta.core.quant.CoreQuantIndicatorsEngine
import com.ta.core.quant.RegimeCode
import com.ta.core.structure.ConfirmDirection
import com.ta.core.structure.StructuralPriceActionEngine
import com.ta.core.structure.WyckoffBias
import com.ta.core.synthesis.SelectionMode
import com.ta.core.synthesis.StrategyConfigRequest
import com.ta.core.synthesis.StrategySynthesizerEngine
import com.ta.core.synthesis.StyleModule
import com.tradingassistant.core.risk.MarketType
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import com.tradingassistant.core.risk.TradeDirection
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object EngineAcceptanceTests {

    fun runAll() {
        test1_wyckoffRangeAnchorStability()
        test2_noDuplicateSignalForSameSetup()
        test3_blockCounterTrendInStrongLtfTrend()
        test4_oppositeWyckoffConfirmCannotTriggerSignal()
        test5_unclosedLiveCandleDoesNotMutateOutput()
        test6_sweepStopLossPlacedBeyondSweepCandleExtreme()
        test7_riskEngineCooldownAutoResetAndDailyReset()
        test8_randomWalk5000BarsDiagnostic()
        PrismEngineUnitTests.runAll()
    }

    private fun test1_wyckoffRangeAnchorStability() {
        val base = buildSyntheticWyckoffAccumulationBars(220)
        val s1 = StructuralPriceActionEngine.analyzeStructure(base.subList(0, 215))
            ?: error("Expected non-null structure")
        val s2 = StructuralPriceActionEngine.analyzeStructure(base, previousRangeState = s1.wyckoff)
            ?: error("Expected non-null structure on extended bars")

        if (s1.wyckoff.isActive) {
            check(s2.wyckoff.anchorClimaxTime == s1.wyckoff.anchorClimaxTime) {
                "Range anchor drifted when adding new candles"
            }
            check(abs(s2.wyckoff.creekResistance - s1.wyckoff.creekResistance) < 1e-6) {
                "Creek level drifted"
            }
            check(abs(s2.wyckoff.iceSupport - s1.wyckoff.iceSupport) < 1e-6) {
                "Ice level drifted"
            }
        }
    }

    private fun test2_noDuplicateSignalForSameSetup() {
        val bars = buildSyntheticWyckoffAccumulationBars(230)
        val cfg = defaultConfig()
        val risk = defaultRisk(bars.last().c, bars.last().t / 1000L)
        val first = StrategySynthesizerEngine.executeSynthesis(bars, bars, cfg, risk)
            ?: error("Expected synthesis report")
        if (first.companionSignal.isSignalActive) {
            val second = StrategySynthesizerEngine.executeSynthesis(
                ltfBars = bars,
                htfBars = bars,
                config = cfg,
                riskTemplate = risk,
                previousLtfWyckoff = first.assistantReport.wyckoffRangeState,
                activeSetupIds = setOf(first.companionSignal.setupId)
            ) ?: error("Expected synthesis report")
            check(!second.companionSignal.isSignalActive) { "Duplicate signal fired for active setupId" }
            check(second.companionSignal.noSignalReasonCode == "DUPLICATE_SETUP_ALREADY_ACTIVE")
        }
    }

    private fun test3_blockCounterTrendInStrongLtfTrend() {
        val bullTrendBars = buildStrongTrendBars(250, bullish = true)
        val quant = CoreQuantIndicatorsEngine.computeSnapshot(bullTrendBars) ?: error("Expected quant")
        check(quant.regime == RegimeCode.TREND_BULL_STRONG) { "Expected TREND_BULL_STRONG, got ${quant.regime}" }
        val cfg = defaultConfig()
        val risk = defaultRisk(bullTrendBars.last().c, bullTrendBars.last().t / 1000L)
        val rep = StrategySynthesizerEngine.executeSynthesis(bullTrendBars, bullTrendBars, cfg, risk)
            ?: error("Expected report")
        if (rep.companionSignal.isSignalActive) {
            check(rep.companionSignal.direction != TradeDirection.SHORT) {
                "Counter-trend SHORT leaked during TREND_BULL_STRONG without MSS+Sweep"
            }
        }
    }

    private fun test4_oppositeWyckoffConfirmCannotTriggerSignal() {
        val distBars = buildSyntheticWyckoffDistributionBars(230)
        val struct = StructuralPriceActionEngine.analyzeStructure(distBars) ?: error("Expected struct")
        if (struct.wyckoff.isActive && struct.wyckoff.bias == WyckoffBias.DISTRIBUTION) {
            check(struct.wyckoff.confirmDirection != ConfirmDirection.LONG) {
                "Distribution range produced LONG confirmation"
            }
        }
    }

    private fun test5_unclosedLiveCandleDoesNotMutateOutput() {
        val closedBars = buildStrongTrendBars(240, bullish = true)
        val liveSpikedCandle = BarNode(
            t = closedBars.last().t + 900_000L,
            o = closedBars.last().c,
            h = closedBars.last().c * 1.12,
            l = closedBars.last().c * 0.85,
            c = closedBars.last().c * 0.88,
            v = 999_999.0,
            closed = false
        )
        val q1 = CoreQuantIndicatorsEngine.computeSnapshot(closedBars)
        val q2 = CoreQuantIndicatorsEngine.computeSnapshot(closedBars + liveSpikedCandle)
        val s1 = StructuralPriceActionEngine.analyzeStructure(closedBars)
        val s2 = StructuralPriceActionEngine.analyzeStructure(closedBars + liveSpikedCandle)
        check(q1 == q2) { "Unclosed candle mutated QuantSnapshot (Repainting detected)" }
        check(s1 == s2) { "Unclosed candle mutated StructuralSnapshot (Repainting detected)" }
    }

    private fun test6_sweepStopLossPlacedBeyondSweepCandleExtreme() {
        val bars = buildSyntheticSweepBars(240)
        val struct = StructuralPriceActionEngine.analyzeStructure(bars) ?: error("Expected struct")
        val sweep = struct.recentSweepPool
        if (sweep != null && sweep.sweepExtremePrice != null && sweep.sweepRejectedCloseInside) {
            val cfg = defaultConfig()
            val risk = defaultRisk(bars.last().c, bars.last().t / 1000L)
            val rep = StrategySynthesizerEngine.executeSynthesis(bars, bars, cfg, risk)
            if (rep != null && rep.companionSignal.isSignalActive) {
                if (rep.companionSignal.direction == TradeDirection.LONG) {
                    check(rep.companionSignal.stopLossPrice < sweep.sweepExtremePrice) {
                        "Long SL (${rep.companionSignal.stopLossPrice}) must be strictly below sweep wick extreme (${sweep.sweepExtremePrice})"
                    }
                } else {
                    check(rep.companionSignal.stopLossPrice > sweep.sweepExtremePrice) {
                        "Short SL (${rep.companionSignal.stopLossPrice}) must be strictly above sweep wick extreme (${sweep.sweepExtremePrice})"
                    }
                }
            }
        }
    }

    private fun test7_riskEngineCooldownAutoResetAndDailyReset() {
        val day1Sec = 1_700_000_000L
        val cooldownUntil = day1Sec + 14_400L
        val locked = RiskAndPsychologyEngine.calculatePositionSize(
            defaultRisk(100.0, day1Sec).copy(
                consecutiveLossesCount = 3,
                cooldownUntilEpochSec = cooldownUntil
            )
        )
        check(!locked.isAllowed) { "Should be locked during active cooldown" }

        val unlocked = RiskAndPsychologyEngine.calculatePositionSize(
            defaultRisk(100.0, cooldownUntil + 60L).copy(
                consecutiveLossesCount = 3,
                cooldownUntilEpochSec = cooldownUntil
            )
        )
        check(unlocked.isAllowed) { "Should auto-unlock after cooldown expires instead of permanent deadlock" }

        val nextDayUnlocked = RiskAndPsychologyEngine.calculatePositionSize(
            defaultRisk(100.0, day1Sec + 90_000L).copy(
                todayRealizedLossUsdt = 500.0,
                todayLossUtcDayIndex = day1Sec / 86_400L
            )
        )
        check(nextDayUnlocked.isAllowed) { "Daily loss limit should reset on new UTC day" }
    }

    private fun test8_randomWalk5000BarsDiagnostic() {
        val rng = Random(42)
        val bars = mutableListOf<BarNode>()
        var price = 50_000.0
        var ts = 1_700_000_000_000L
        for (i in 0 until 5000) {
            val ret = (rng.nextDouble() - 0.5) * 0.012
            val o = price
            val c = max(100.0, o * (1.0 + ret))
            val h = max(o, c) * (1.0 + rng.nextDouble() * 0.004)
            val l = min(o, c) * (1.0 - rng.nextDouble() * 0.004)
            val v = 100.0 + rng.nextDouble() * 400.0
            bars.add(BarNode(ts, o, h, l, c, v, closed = true))
            price = c
            ts += 900_000L
        }
        val cfg = defaultConfig()
        val risk = defaultRisk(bars.last().c, bars.last().t / 1000L)
        val bt = BacktestAndEvaluatorEngine.runWalkForwardBacktest(bars, bars, cfg, risk, numTrialsTested = 5)
        check(bt.statusCode == "OK" || bt.statusCode == "NO_TRADES_EXECUTED")
    }

    private fun defaultConfig() = StrategyConfigRequest(
        symbol = "BTCUSDT",
        marketType = MarketType.FUTURES,
        executionTimeframe = "15m",
        higherTimeframe = "4h",
        selectionMode = SelectionMode.SUGGESTED_COMBINATION,
        userSelectedModules = StyleModule.entries.toSet()
    )

    private fun defaultRisk(price: Double, epochSec: Long) = PositionSizingInput(
        symbol = "BTCUSDT",
        marketType = MarketType.FUTURES,
        direction = TradeDirection.LONG,
        totalCapitalUsdt = 10_000.0,
        baseRiskPct = 1.0,
        entryPrice = price,
        currentMarkPrice = price,
        stopLossPrice = price * 0.985,
        takeProfit1Price = price * 1.035,
        takeProfit2Price = price * 1.06,
        requestedLeverage = 5,
        maxAllowedLeverage = 10,
        currentEpochSec = epochSec
    )

    private fun buildStrongTrendBars(count: Int, bullish: Boolean): List<BarNode> {
        val out = mutableListOf<BarNode>()
        var p = 100.0
        var ts = 1_700_000_000_000L
        val step = if (bullish) 0.45 else -0.45
        for (i in 0 until count) {
            val o = p
            val c = max(10.0, o + step + (if (i % 7 == 0) -step * 0.4 else 0.0))
            val h = max(o, c) + 0.25
            val l = min(o, c) - 0.25
            out.add(BarNode(ts, o, h, l, c, 200.0 + (i % 5) * 20.0, closed = true))
            p = c
            ts += 900_000L
        }
        return out
    }

    private fun buildSyntheticWyckoffAccumulationBars(count: Int): List<BarNode> {
        val out = mutableListOf<BarNode>()
        var p = 150.0
        var ts = 1_700_000_000_000L
        for (i in 0 until count) {
            val o: Double
            val c: Double
            val h: Double
            val l: Double
            val v: Double
            when {
                i < 130 -> {
                    o = p; c = p - 0.35; h = o + 0.3; l = c - 0.3; v = 180.0
                }
                i == 130 -> {
                    o = p; c = p - 4.0; h = o + 0.2; l = c - 1.5; v = 650.0
                }
                i in 131..140 -> {
                    o = p; c = p + 1.0; h = c + 0.4; l = o - 0.2; v = 220.0
                }
                i == count - 4 -> {
                    o = 101.0; c = 100.6; h = 101.5; l = 98.2; v = 130.0
                }
                i == count - 3 -> {
                    o = 100.6; c = 102.5; h = 102.8; l = 100.2; v = 110.0
                }
                else -> {
                    val osc = if (i % 6 < 3) 1.5 else -1.5
                    o = p; c = (p + osc).coerceIn(100.2, 110.5)
                    h = max(o, c) + 0.6; l = min(o, c) - 0.6; v = 170.0
                }
            }
            out.add(BarNode(ts, o, h, l, c, v, closed = true))
            p = c
            ts += 900_000L
        }
        return out
    }

    private fun buildSyntheticWyckoffDistributionBars(count: Int): List<BarNode> {
        return buildSyntheticWyckoffAccumulationBars(count).map { b ->
            BarNode(b.t, 300.0 - b.o, 300.0 - b.l, 300.0 - b.h, 300.0 - b.c, b.v, closed = true)
        }
    }

    private fun buildSyntheticSweepBars(count: Int): List<BarNode> {
        val out = buildSyntheticWyckoffAccumulationBars(count).toMutableList()
        val last = out.last()
        out[out.lastIndex] = last.copy(l = last.l - 3.0, c = last.c + 1.5, h = last.h + 1.8, v = 420.0)
        return out
    }
}
