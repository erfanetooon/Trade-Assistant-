package com.ta.core.tests

import com.ta.core.prism.*
import com.tradingassistant.core.risk.MarketType
import kotlin.math.abs
import kotlin.math.sin

/**
 * Deterministic unit tests for Prism Engine:
 * - Covers RegimeDetector, all 5 StyleAnalyzer plugins (Bull / Bear / Range / Squeeze synthetic data),
 *   ConsensusEngine, AnalysisRenderer invariants, every TradeRenderer gate, snapshot logging, and calibration.
 */
object PrismEngineUnitTests {

    fun runAll() {
        testRegimeDetector_TrendRangeVolatile()
        testPriceActionStyle_BullBearAndRange()
        testClassicTaStyle_NeutralBelow220AndDirectionalAt280()
        testMomentumMeanReversionStyle_RangeBounce()
        testVolumeStyle_AbnormalVolumeThrust()
        testBreakoutVolatilityStyle_SqueezeBreakoutAndLowVolReject()
        testConsensusEngine_RegimeFitPerfWeightAndConflicts()
        testAnalysisRenderer_ScenariosSumToOneAndNoTradeFields()
        testTradeRenderer_AllGatesAndHappyPath()
        testPrismEngine_SnapshotLoggingAndCalibration()
    }

    private fun assertTrue(condition: Boolean, msg: String) {
        if (!condition) throw AssertionError("PrismTest FAILED: $msg")
    }

    // ---------- Synthetic Deterministic Candle Generators ----------

    private fun makeBullTrendCandles(count: Int = 280): List<Candle> {
        val list = mutableListOf<Candle>()
        var price = 100.0
        val startT = 1_700_000_000_000L
        for (i in 0 until count) {
            // Wave oscillation superimposed on steady uptrend so clear HH/HL swings form
            val wave = sin(i * 0.45) * 2.2
            val drift = 0.35
            val open = price
            val close = (price + drift + wave * 0.25).coerceAtLeast(10.0)
            val high = kotlin.math.max(open, close) + 0.8 + abs(wave) * 0.15
            val low = kotlin.math.min(open, close) - 0.6
            val vol = if (i == count - 1) 450.0 else 150.0 + (i % 5) * 10.0
            val takerBuy = if (close >= open) vol * 0.72 else vol * 0.30
            list += Candle(startT + i * 3_600_000L, open, high, low, close, vol, takerBuy)
            price = close
        }
        return list
    }

    private fun makeBearTrendCandles(count: Int = 280): List<Candle> {
        val list = mutableListOf<Candle>()
        var price = 300.0
        val startT = 1_700_000_000_000L
        for (i in 0 until count) {
            val wave = sin(i * 0.45) * 2.2
            val drift = -0.35
            val open = price
            val close = (price + drift + wave * 0.25).coerceAtLeast(10.0)
            val high = kotlin.math.max(open, close) + 0.6
            val low = kotlin.math.min(open, close) - 0.8 - abs(wave) * 0.15
            val vol = if (i == count - 1) 450.0 else 150.0 + (i % 5) * 10.0
            val takerBuy = if (close < open) vol * 0.25 else vol * 0.65
            list += Candle(startT + i * 3_600_000L, open, high, low, close, vol, takerBuy)
            price = close
        }
        return list
    }

    private fun makeRangeBounceCandles(count: Int = 120): List<Candle> {
        val list = mutableListOf<Candle>()
        val startT = 1_700_000_000_000L
        for (i in 0 until count) {
            val base = 100.0 + sin(i * 0.30) * 1.5
            val isDrop = i in (count - 6)..(count - 2)
            val isBounce = i == count - 1
            val open = when {
                isDrop -> 99.0 - (i - (count - 6)) * 1.2
                isBounce -> 93.2
                else -> base
            }
            val close = when {
                isDrop -> open - 1.1
                isBounce -> 96.4
                else -> base + 0.1
            }
            val high = kotlin.math.max(open, close) + 0.4
            val low = kotlin.math.min(open, close) - if (isBounce) 1.2 else 0.4
            list += Candle(startT + i * 3_600_000L, open, high, low, close, 120.0, 60.0)
        }
        return list
    }

    private fun makeSqueezeBreakoutCandles(count: Int = 120, highVolume: Boolean): List<Candle> {
        val list = mutableListOf<Candle>()
        val startT = 1_700_000_000_000L
        for (i in 0 until count) {
            val inWidePhase = i < count - 25
            val inSqueeze = i in (count - 25)..(count - 2)
            val isBreakout = i == count - 1
            val open = when {
                inWidePhase -> 100.0 + sin(i * 0.5) * 3.5
                inSqueeze -> 100.0 + sin(i * 0.4) * 0.25
                else -> 100.2
            }
            val close = when {
                inWidePhase -> open + sin(i * 0.7) * 1.8
                inSqueeze -> 100.0 + sin((i + 1) * 0.4) * 0.25
                else -> 104.5
            }
            val spread = if (inWidePhase) 2.5 else if (inSqueeze) 0.35 else 4.8
            val high = kotlin.math.max(open, close) + spread * 0.3
            val low = kotlin.math.min(open, close) - spread * 0.2
            val vol = if (isBreakout) (if (highVolume) 420.0 else 90.0) else 150.0
            list += Candle(startT + i * 3_600_000L, open, high, low, close, vol, vol * 0.75)
        }
        return list
    }

    // ---------- 1. RegimeDetector Tests ----------

    private fun testRegimeDetector_TrendRangeVolatile() {
        val detector = RegimeDetector()
        val bull = makeBullTrendCandles(280)
        val trendCtx = detector.detect(MultiTF(bull, bull))
        assertTrue(trendCtx.regime == Regime.TREND, "Expected TREND on steady bull candles, got ${trendCtx.regime}")
        assertTrue(trendCtx.htfBias == Bias.BULL, "Expected BULL htfBias, got ${trendCtx.htfBias}")

        val range = makeRangeBounceCandles(120).dropLast(8)
        val rangeCtx = detector.detect(MultiTF(range, range))
        assertTrue(rangeCtx.regime == Regime.RANGE, "Expected RANGE on flat oscillating candles, got ${rangeCtx.regime}")

        // Inject massive volatility expansion on last 5 bars -> VOLATILE
        val volatile = range.toMutableList()
        val lastT = volatile.last().t
        for (k in 1..5) {
            volatile += Candle(lastT + k * 3_600_000L, 100.0, 125.0, 75.0, 118.0, 800.0, 500.0)
        }
        val volCtx = detector.detect(MultiTF(volatile, volatile))
        assertTrue(volCtx.regime == Regime.VOLATILE, "Expected VOLATILE after ATR spike, got ${volCtx.regime}")
    }

    // ---------- 2. Plugin Unit Tests ----------

    private fun testPriceActionStyle_BullBearAndRange() {
        val plugin = PriceActionStyle()
        val bull = makeBullTrendCandles(140)
        val ctxBull = MarketContext(Regime.TREND, 0.4, Bias.BULL, MarketSession.LONDON, 1.5)
        val vBull = plugin.analyze(ctxBull, bull)
        assertTrue(vBull.bias == Bias.BULL && vBull.invalidation != null, "PriceAction should detect BULL on HH/HL")

        val bear = makeBearTrendCandles(140)
        val ctxBear = MarketContext(Regime.TREND, 0.4, Bias.BEAR, MarketSession.LONDON, 1.5)
        val vBear = plugin.analyze(ctxBear, bear)
        assertTrue(vBear.bias == Bias.BEAR && vBear.invalidation != null, "PriceAction should detect BEAR on LH/LL")

        val shortList = bull.take(30)
        val vShort = plugin.analyze(ctxBull, shortList)
        assertTrue(vShort.bias == Bias.NEUTRAL, "PriceAction must stay NEUTRAL below minCandles")
    }

    private fun testClassicTaStyle_NeutralBelow220AndDirectionalAt280() {
        val plugin = ClassicTaStyle()
        val bull = makeBullTrendCandles(280)
        val ctx = MarketContext(Regime.TREND, 0.4, Bias.BULL, MarketSession.NEW_YORK, 1.5)

        val vShort = plugin.analyze(ctx, bull.take(180))
        assertTrue(vShort.bias == Bias.NEUTRAL, "ClassicTaStyle must intentionally return NEUTRAL when < 220 candles")

        val vBull = plugin.analyze(ctx, bull)
        assertTrue(vBull.bias == Bias.BULL && vBull.confidence > 0.4, "ClassicTaStyle should return BULL on 280 bull candles")

        val vBear = plugin.analyze(ctx.copy(htfBias = Bias.BEAR), makeBearTrendCandles(280))
        assertTrue(vBear.bias == Bias.BEAR && vBear.confidence > 0.4, "ClassicTaStyle should return BEAR on 280 bear candles")
    }

    private fun testMomentumMeanReversionStyle_RangeBounce() {
        val plugin = MomentumMeanReversionStyle()
        val candles = makeRangeBounceCandles(120)
        val ctx = MarketContext(Regime.RANGE, 0.35, Bias.NEUTRAL, MarketSession.ASIA, 1.0)
        val v = plugin.analyze(ctx, candles)
        assertTrue(v.bias == Bias.BULL && v.invalidation != null, "MomentumMeanReversion should trigger BULL bounce off lower BB + oversold RSI")
        assertTrue(Regime.RANGE in v.suitableRegimes, "MomentumMeanReversion must target RANGE regime")
    }

    private fun testVolumeStyle_AbnormalVolumeThrust() {
        val plugin = VolumeStyle()
        val bull = makeBullTrendCandles(140) // last bar has RVOL ~ 2.7x and strong takerBuyVol
        val ctx = MarketContext(Regime.TREND, 0.45, Bias.BULL, MarketSession.OVERLAP_LDN_NY, 1.5)
        val v = plugin.analyze(ctx, bull)
        assertTrue(v.bias == Bias.BULL && v.confidence >= 0.4, "VolumeStyle should confirm BULL on abnormal volume thrust")
    }

    private fun testBreakoutVolatilityStyle_SqueezeBreakoutAndLowVolReject() {
        val plugin = BreakoutVolatilityStyle()
        val ctx = MarketContext(Regime.TREND, 0.5, Bias.BULL, MarketSession.LONDON, 1.2)

        val validBreak = makeSqueezeBreakoutCandles(120, highVolume = true)
        val vValid = plugin.analyze(ctx, validBreak)
        assertTrue(vValid.bias == Bias.BULL && vValid.confidence >= 0.6, "BreakoutVolatility should confirm BULL on squeeze + high RVOL")

        val fakeBreak = makeSqueezeBreakoutCandles(120, highVolume = false)
        val vFake = plugin.analyze(ctx, fakeBreak)
        assertTrue(vFake.bias == Bias.NEUTRAL, "BreakoutVolatility must reject low-volume breakout fakeout")
    }

    // ---------- 3. Consensus & AnalysisRenderer Tests ----------

    private fun testConsensusEngine_RegimeFitPerfWeightAndConflicts() {
        val engine = ConsensusEngine()
        val ctx = MarketContext(Regime.TREND, 0.4, Bias.BEAR, MarketSession.LONDON, 2.0)
        val verdicts = listOf(
            StyleVerdict("price_action", Bias.BULL, 0.8, emptyList(), emptyList(), Level(95.0, "SL"), setOf(Regime.TREND)),
            StyleVerdict("classic_ta", Bias.BULL, 0.7, emptyList(), emptyList(), Level(96.0, "SL"), setOf(Regime.TREND)),
            StyleVerdict("volume", Bias.BEAR, 0.6, emptyList(), emptyList(), Level(105.0, "SL"), setOf(Regime.TREND))
        )
        val res = engine.run(ctx, verdicts)
        assertTrue(res.conflicts.any { it.contains("اختلاف جهت") }, "Consensus must flag directional conflict")

        // Low-sample BacktestPerformanceTable must default to 1.0
        val table = BacktestPerformanceTable(
            mapOf(("price_action" to Regime.TREND) to StyleRegimePerformance("price_action", Regime.TREND, 4, 0.25, 0.4, -0.5))
        )
        assertTrue(table.weightFor("price_action", Regime.TREND) == 1.0, "Low sample size (<10) must default perfWeight to 1.0")
    }

    private fun testAnalysisRenderer_ScenariosSumToOneAndNoTradeFields() {
        val renderer = AnalysisRenderer()
        val ctx = MarketContext(Regime.TREND, 0.45, Bias.BULL, MarketSession.LONDON, 2.0)
        val cons = ConsensusResult(
            bias = Bias.BULL,
            confidence = 0.65,
            agreement = 0.80,
            conflicts = emptyList(),
            verdicts = listOf(
                StyleVerdict("price_action", Bias.BULL, 0.7, listOf(Evidence("HH+HL", 0.6)), listOf(Level(110.0, "مقاومت")), Level(95.0, "ابطال"), setOf(Regime.TREND))
            ),
            contributingStyles = listOf("price_action")
        )
        val report = renderer.render(ctx, cons, Candle(1_700_000_000_000L, 100.0, 102.0, 99.0, 101.0, 200.0))
        assertTrue(report.scenarios.size == 3, "AnalysisReport must have exactly 3 scenarios")
        val probSum = report.scenarios.sumOf { it.probability }
        assertTrue(abs(probSum - 1.0) <= 0.02, "Scenario probabilities must sum to ~1.0, got $probSum")
        assertTrue(report.whatChangesMyMind.isNotEmpty(), "AnalysisReport must populate whatChangesMyMind")
    }

    // ---------- 4. Every TradeRenderer Gate Test ----------

    private fun testTradeRenderer_AllGatesAndHappyPath() {
        val renderer = TradeRenderer(GateConfig())
        val last = Candle(1_700_000_000_000L, 99.0, 101.0, 98.5, 100.0, 300.0)
        val baseCtx = MarketContext(Regime.TREND, 0.40, Bias.BULL, MarketSession.LONDON, currentAtr = 2.0)
        val v1 = StyleVerdict(
            "price_action", Bias.BULL, 0.75, listOf(Evidence("BOS صعودی", 0.7)),
            listOf(Level(104.0, "سقف ۱"), Level(107.0, "سقف ۲"), Level(112.0, "سقف ۳")),
            Level(99.2, "ابطال سوینگ"), // intentionally < 1 ATR (0.8) to test 1-ATR floor!
            setOf(Regime.TREND)
        )
        val v2 = StyleVerdict("classic_ta", Bias.BULL, 0.70, listOf(Evidence("EMA Stack", 0.6)), listOf(Level(106.5, "EMA")), Level(97.0, "SL"), setOf(Regime.TREND))
        val v3 = StyleVerdict("volume", Bias.BULL, 0.65, listOf(Evidence("RVOL بالا", 0.6)), listOf(Level(105.0, "VAH")), Level(97.5, "SL"), setOf(Regime.TREND))
        val baseConsensus = ConsensusResult(Bias.BULL, 0.68, 0.85, emptyList(), listOf(v1, v2, v3), listOf("price_action", "classic_ta", "volume"))
        val okProfile = PrismRiskProfile(symbol = "BTCUSDT", marketType = MarketType.FUTURES, totalCapitalUsdt = 5000.0)

        // Gate 1: Neutral bias
        assertTrue(renderer.render(baseCtx, baseConsensus.copy(bias = Bias.NEUTRAL), last, okProfile) is TradeResult.NoTrade, "Gate 1 (NEUTRAL) failed")

        // Gate 2: Disallowed regime (VOLATILE)
        assertTrue(renderer.render(baseCtx.copy(regime = Regime.VOLATILE), baseConsensus, last, okProfile) is TradeResult.NoTrade, "Gate 2 (Regime) failed")

        // Gate 3: Active conflict
        assertTrue(renderer.render(baseCtx, baseConsensus.copy(conflicts = listOf("خلاف جهت تایم‌فریم بالاتر")), last, okProfile) is TradeResult.NoTrade, "Gate 3 (Conflict) failed")

        // Gate 4: Low confidence
        assertTrue(renderer.render(baseCtx, baseConsensus.copy(confidence = 0.20), last, okProfile) is TradeResult.NoTrade, "Gate 4 (Confidence) failed")

        // Gate 5: Low agreement
        assertTrue(renderer.render(baseCtx, baseConsensus.copy(agreement = 0.50), last, okProfile) is TradeResult.NoTrade, "Gate 5 (Agreement) failed")

        // Gate 6: Insufficient agreeing styles (< 3)
        assertTrue(renderer.render(baseCtx, baseConsensus.copy(verdicts = listOf(v1, v2)), last, okProfile) is TradeResult.NoTrade, "Gate 6 (MinStyles) failed")

        // Gate 7: Risk engine rejection (consecutive losses cooldown / Spot SHORT)
        val lockedProfile = okProfile.copy(consecutiveLossesCount = 5)
        assertTrue(renderer.render(baseCtx, baseConsensus, last, lockedProfile) is TradeResult.NoTrade, "Gate 7 (RiskEngine lock) failed")

        // Happy Path: Signal passes all gates, enforces >= 1 ATR stop floor, computes real RR
        val res = renderer.render(baseCtx, baseConsensus, last, okProfile)
        assertTrue(res is TradeResult.Signal, "Expected valid TradeResult.Signal on happy path, got $res")
        val sig = res as TradeResult.Signal
        assertTrue(abs(sig.entry - sig.stop) >= baseCtx.currentAtr - 1e-6, "Stop must be >= 1.0 ATR from entry")
        assertTrue(sig.tps.size == 3 && sig.tps[0] < sig.tps[1] && sig.tps[1] < sig.tps[2], "TPs must be 3 progressive real levels")
        assertTrue(sig.rr >= 1.5, "Real RR must be >= minRR (1.5)")
        assertTrue(sig.recommendedQty > 0.0, "Recommended qty from RiskAndPsychologyEngine must be > 0")
    }

    // ---------- 5. Snapshot Logging & Calibration ----------

    private fun testPrismEngine_SnapshotLoggingAndCalibration() {
        val logger = InMemoryPrismSnapshotLogger()
        val engine = PrismEngine(snapshotLogger = logger)
        val bull = makeBullTrendCandles(280)
        val out = engine.evaluate(
            symbol = "BTCUSDT",
            timeframe = "1h",
            candles = MultiTF(bull, bull),
            riskProfile = PrismRiskProfile(symbol = "BTCUSDT")
        )
        assertTrue(out.hasSufficientHistory, "280 closed candles must satisfy MIN_RECOMMENDED_CANDLES (250)")
        assertTrue(logger.loadSnapshots("BTCUSDT").size == 1, "Snapshot must be logged for replay/backtest")

        val cal = PrismBacktestCalibrator.calibrate(bull, bull)
        assertTrue(cal.buckets.size == 4, "Calibration report must emit 4 confidence buckets")
    }
}
