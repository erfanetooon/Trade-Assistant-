package com.ta.ui.shared

import com.ta.core.backtest.BacktestAndEvaluatorEngine
import com.ta.core.backtest.BacktestResult
import com.ta.core.live.AlertAndDataEngine
import com.ta.core.live.FeedHealthCode
import com.ta.core.live.JournalClosedSample
import com.ta.core.live.SmartAlertEvent
import com.ta.core.live.StrategyDriftReport
import com.ta.core.prism.*
import com.ta.core.quant.BarNode
import com.ta.core.structure.WyckoffRangeState
import com.ta.core.synthesis.AssistantModeOutput
import com.ta.core.synthesis.CompanionSignalOutput
import com.ta.core.synthesis.SelectionMode
import com.ta.core.synthesis.StrategyConfigRequest
import com.ta.core.synthesis.StyleModule
import com.tradingassistant.core.risk.HorizonMapping
import com.tradingassistant.core.risk.MarketType
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import com.tradingassistant.core.risk.TradeDirection

enum class AppOperatingMode {
    ASSISTANT_ADVISORY,
    TRADING_COMPANION
}

enum class EntitlementState {
    TRIAL_ACTIVE,
    LICENSE_VIP_ACTIVE,
    EXPIRED_LOCKED,
    MAINTENANCE_LOCKED
}

data class PersistedRiskCounters(
    val totalCapitalUsdt: Double = 10_000.0,
    val consecutiveLosses: Int = 0,
    val todayRealizedLossUsdt: Double = 0.0,
    val todayLossUtcDayIndex: Long = -1L,
    val cooldownUntilEpochSec: Long = 0L
)

interface TradingStateStore {
    fun loadRiskCounters(): PersistedRiskCounters
    fun saveRiskCounters(counters: PersistedRiskCounters)
    fun loadJournalSamples(): List<JournalClosedSample>
    fun appendJournalSample(sample: JournalClosedSample)
    fun loadEmittedAlertKeys(): Set<String>
    fun saveEmittedAlertKey(key: String)
    fun loadActiveSetupIds(): Set<String>
    fun saveActiveSetupId(setupId: String)
}

class InMemoryTradingStateStore : TradingStateStore {
    private var counters = PersistedRiskCounters()
    private val journal = mutableListOf<JournalClosedSample>()
    private val alertKeys = LinkedHashSet<String>()
    private val setupIds = LinkedHashSet<String>()

    override fun loadRiskCounters(): PersistedRiskCounters = counters
    override fun saveRiskCounters(counters: PersistedRiskCounters) { this.counters = counters }
    override fun loadJournalSamples(): List<JournalClosedSample> = journal.toList()
    override fun appendJournalSample(sample: JournalClosedSample) { journal.add(sample) }
    override fun loadEmittedAlertKeys(): Set<String> = alertKeys.toSet()
    override fun saveEmittedAlertKey(key: String) { alertKeys.add(key) }
    override fun loadActiveSetupIds(): Set<String> = setupIds.toSet()
    override fun saveActiveSetupId(setupId: String) { setupIds.add(setupId) }
}

data class ChartOverlayBox(
    val id: String,
    val labelCode: String,
    val topPrice: Double,
    val bottomPrice: Double,
    val startTimeEpochMs: Long,
    val isBullish: Boolean,
    val isMitigated: Boolean
)

data class ChartHorizontalLine(
    val id: String,
    val labelCode: String,
    val price: Double,
    val lineStyleCode: String
)

data class LightweightChartBridgePayload(
    val symbol: String,
    val timeframe: String,
    val candles: List<BarNode>,
    val overlayZones: List<ChartOverlayBox>,
    val structuralLines: List<ChartHorizontalLine>
)

data class TradingUiState(
    val statusCode: String = "IDLE",
    val entitlementState: EntitlementState = EntitlementState.TRIAL_ACTIVE,
    val activeMode: AppOperatingMode = AppOperatingMode.ASSISTANT_ADVISORY,
    val selectedSymbol: String = "BTCUSDT",
    val selectedMarketType: MarketType = MarketType.FUTURES,
    val horizonSliderValue: Int = 50,
    val horizonMapping: HorizonMapping = RiskAndPsychologyEngine.mapHorizonSlider(50),
    val selectionMode: SelectionMode = SelectionMode.SUGGESTED_COMBINATION,
    val manualModules: Set<StyleModule> = setOf(
        StyleModule.WYCKOFF_VSA,
        StyleModule.SMC_ICT,
        StyleModule.FIBONACCI_MATRIX
    ),
    val totalCapitalUsdt: Double = 10_000.0,
    val baseRiskPct: Double = 1.0,
    val requestedLeverage: Int = 5,
    val maxAllowedLeverage: Int = 10,
    val currentBlockNumber: Int = 1,
    val tradesInCurrentBlock: Int = 0,
    val consecutiveLosses: Int = 0,
    val todayRealizedLossUsdt: Double = 0.0,
    val todayLossUtcDayIndex: Long = -1L,
    val openPositionsRiskUsdt: Double = 0.0,
    val openPositionsCount: Int = 0,
    val hasCorrelatedOpenTrade: Boolean = false,
    val cooldownUntilEpochSec: Long = 0L,
    val feedHealth: FeedHealthCode = FeedHealthCode.HEALTHY_LIVE,
    val dataLagMs: Long = 0L,
    val assistantOutput: AssistantModeOutput? = null,
    val companionOutput: CompanionSignalOutput? = null,
    val chartPayload: LightweightChartBridgePayload? = null,
    val latestBacktest: BacktestResult? = null,
    val latestDriftReport: StrategyDriftReport? = null,
    val recentAlerts: List<SmartAlertEvent> = emptyList(),
    val prismContext: MarketContext? = null,
    val prismConsensus: ConsensusResult? = null,
    val prismAnalysis: AnalysisReport? = null,
    val prismTradeResult: TradeResult? = null,
    val prismHasSufficientHistory: Boolean = false
)

class SharedTradingOrchestrator(
    private val store: TradingStateStore = InMemoryTradingStateStore(),
    private val prismConfig: PrismConfig = PrismConfig(),
    private val prismSnapshotLogger: PrismSnapshotLogger = InMemoryPrismSnapshotLogger()
) {
    private var prismEngine: PrismEngine = PrismEngine(
        config = prismConfig,
        snapshotLogger = prismSnapshotLogger
    )

    private var state: TradingUiState
    private var lastWyckoffRangeState: WyckoffRangeState? = null
    private var lastBacktestedClosedBarTimestamp: Long = -1L
    private var cachedBacktest: BacktestResult? = null

    init {
        val persisted = store.loadRiskCounters()
        val samples = store.loadJournalSamples()
        state = TradingUiState(
            totalCapitalUsdt = persisted.totalCapitalUsdt,
            consecutiveLosses = persisted.consecutiveLosses,
            todayRealizedLossUsdt = persisted.todayRealizedLossUsdt,
            todayLossUtcDayIndex = persisted.todayLossUtcDayIndex,
            cooldownUntilEpochSec = persisted.cooldownUntilEpochSec,
            currentBlockNumber = (samples.size / 20) + 1,
            tradesInCurrentBlock = samples.size % 20
        )
    }

    fun currentState(): TradingUiState = state

    fun updatePrismPerformanceTable(table: BacktestPerformanceTable) {
        prismEngine = PrismEngine(
            config = prismConfig,
            perfWeightProvider = table.asWeightProvider(prismConfig.consensus),
            snapshotLogger = prismSnapshotLogger
        )
    }

    fun updateHorizonSlider(sliderValue: Int) {
        val mapped = RiskAndPsychologyEngine.mapHorizonSlider(sliderValue)
        lastWyckoffRangeState = null
        lastBacktestedClosedBarTimestamp = -1L
        state = state.copy(
            horizonSliderValue = mapped.sliderValue,
            horizonMapping = mapped
        )
    }

    fun switchOperatingMode(mode: AppOperatingMode) {
        state = state.copy(activeMode = mode)
    }

    fun updateSymbolAndMarket(symbol: String, marketType: MarketType) {
        val lev = if (marketType == MarketType.SPOT) 1 else state.requestedLeverage
        lastWyckoffRangeState = null
        lastBacktestedClosedBarTimestamp = -1L
        state = state.copy(
            selectedSymbol = symbol,
            selectedMarketType = marketType,
            requestedLeverage = lev
        )
    }

    fun updateStrategySelection(mode: SelectionMode, modules: Set<StyleModule>) {
        lastBacktestedClosedBarTimestamp = -1L
        state = state.copy(
            selectionMode = mode,
            manualModules = modules
        )
    }

    fun onLiveMarketTick(
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        currentMarkPrice: Double,
        lastPacketEpochMs: Long,
        deviceEpochMs: Long
    ): TradingUiState {
        if (state.entitlementState == EntitlementState.EXPIRED_LOCKED ||
            state.entitlementState == EntitlementState.MAINTENANCE_LOCKED
        ) {
            return state
        }

        val nowSec = deviceEpochMs / 1000L
        reconcileDailyAndCooldownResets(nowSec)

        val config = buildCurrentConfig()
        val riskInput = buildRiskTemplate(ltfBars, currentMarkPrice, nowSec)

        val tickResult = AlertAndDataEngine.processMarketSnapshot(
            symbol = state.selectedSymbol,
            ltfBars = ltfBars,
            htfBars = htfBars,
            lastPacketReceivedEpochMs = lastPacketEpochMs,
            currentDeviceEpochMs = deviceEpochMs,
            config = config,
            riskTemplate = riskInput,
            previouslyEmittedKeys = store.loadEmittedAlertKeys(),
            previousLtfWyckoff = lastWyckoffRangeState,
            activeSetupIds = store.loadActiveSetupIds()
        )

        tickResult.emittedAlerts.forEach { store.saveEmittedAlertKey(it.deduplicationKey) }
        val mergedAlerts = (tickResult.emittedAlerts + state.recentAlerts).take(50)

        val syn = tickResult.synthesis
        if (syn != null) {
            lastWyckoffRangeState = syn.assistantReport.wyckoffRangeState
            if (syn.companionSignal.isSignalActive && syn.companionSignal.setupId.isNotBlank()) {
                store.saveActiveSetupId(syn.companionSignal.setupId)
            }
        }

        val chartData = if (syn != null) {
            buildChartBridgePayload(
                symbol = state.selectedSymbol,
                timeframe = state.horizonMapping.executionTimeframe,
                bars = ltfBars.filter { it.closed }.takeLast(300),
                assistant = syn.assistantReport,
                companion = syn.companionSignal
            )
        } else state.chartPayload

        val drift = if (cachedBacktest != null && syn != null) {
            AlertAndDataEngine.evaluateExpectedVsActualDrift(
                strategyComboId = syn.companionSignal.strategyComboId,
                backtest = cachedBacktest!!,
                journalTrades = store.loadJournalSamples()
            )
        } else state.latestDriftReport

        val prismProfile = PrismRiskProfile(
            symbol = state.selectedSymbol,
            marketType = state.selectedMarketType,
            totalCapitalUsdt = state.totalCapitalUsdt,
            baseRiskPct = state.baseRiskPct,
            requestedLeverage = state.requestedLeverage,
            maxAllowedLeverage = state.maxAllowedLeverage,
            openPositionsRiskUsdt = state.openPositionsRiskUsdt,
            openPositionsCount = state.openPositionsCount,
            todayRealizedLossUsdt = state.todayRealizedLossUsdt,
            consecutiveLossesCount = state.consecutiveLosses,
            cooldownUntilEpochSec = state.cooldownUntilEpochSec
        )
        val allowTradeMode = state.activeMode == AppOperatingMode.TRADING_COMPANION &&
            state.entitlementState != EntitlementState.EXPIRED_LOCKED
        val prismOutput = prismEngine.evaluateBarNodes(
            symbol = state.selectedSymbol,
            timeframe = state.horizonMapping.executionTimeframe,
            rawLtfBars = ltfBars,
            rawHtfBars = htfBars,
            riskProfile = prismProfile,
            previouslyEmittedAlertKeys = store.loadEmittedAlertKeys(),
            emitTradeAlerts = allowTradeMode
        )
        val prismAlerts = listOfNotNull(prismOutput?.alertEvent)
        prismAlerts.forEach { store.saveEmittedAlertKey(it.deduplicationKey) }
        val finalMergedAlerts = (prismAlerts + mergedAlerts).take(50)

        state = state.copy(
            statusCode = tickResult.statusCode,
            feedHealth = tickResult.feedHealth,
            dataLagMs = tickResult.dataLagMs,
            assistantOutput = syn?.assistantReport,
            companionOutput = syn?.companionSignal,
            chartPayload = chartData,
            latestBacktest = cachedBacktest,
            latestDriftReport = drift,
            recentAlerts = finalMergedAlerts,
            prismContext = prismOutput?.context,
            prismConsensus = prismOutput?.consensus,
            prismAnalysis = prismOutput?.analysisReport,
            prismTradeResult = if (allowTradeMode) prismOutput?.tradeResult else null,
            prismHasSufficientHistory = prismOutput?.hasSufficientHistory ?: false
        )
        return state
    }

    fun runBacktestOnNewClosedBar(
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        currentMarkPrice: Double,
        deviceEpochMs: Long,
        numTrialsTested: Int = 1
    ): BacktestResult? {
        val latestClosedTs = ltfBars.lastOrNull { it.closed }?.t ?: return cachedBacktest
        if (latestClosedTs == lastBacktestedClosedBarTimestamp && cachedBacktest != null) {
            return cachedBacktest
        }
        val config = buildCurrentConfig()
        val riskInput = buildRiskTemplate(ltfBars, currentMarkPrice, deviceEpochMs / 1000L)
        val bt = BacktestAndEvaluatorEngine.runWalkForwardBacktest(
            ltfBars = ltfBars,
            htfBars = htfBars,
            config = config,
            riskTemplate = riskInput,
            numTrialsTested = numTrialsTested
        )
        lastBacktestedClosedBarTimestamp = latestClosedTs
        cachedBacktest = bt

        val drift = AlertAndDataEngine.evaluateExpectedVsActualDrift(
            strategyComboId = bt.strategyComboId,
            backtest = bt,
            journalTrades = store.loadJournalSamples(),
            numStrategiesTested = numTrialsTested
        )
        state = state.copy(latestBacktest = bt, latestDriftReport = drift)
        return bt
    }

    fun recordClosedTradeInJournal(
        tradeId: String,
        strategyComboId: String,
        realizedPnlUsdt: Double,
        realizedRMultiple: Double,
        movedStopLossWider: Boolean,
        exitedPrematurelyFear: Boolean,
        enteredOnFomo: Boolean,
        exceededPlannedRisk: Boolean,
        currentEpochSec: Long
    ): TradingUiState {
        reconcileDailyAndCooldownResets(currentEpochSec)

        val adherence = RiskAndPsychologyEngine.calculateDouglasAdherenceScore(
            movedStopLossWider = movedStopLossWider,
            exitedPrematurelyOutOfFear = exitedPrematurelyFear,
            enteredOutsideZoneOnFomo = enteredOnFomo,
            exceededPlannedRisk = exceededPlannedRisk
        )
        val isWin = realizedRMultiple > 0.0
        store.appendJournalSample(
            JournalClosedSample(
                tradeId = tradeId,
                strategyComboId = strategyComboId,
                realizedRMultiple = realizedRMultiple,
                isWin = isWin,
                adherenceScore = adherence
            )
        )

        val allSamples = store.loadJournalSamples()
        val blockNum = (allSamples.size / 20) + 1
        val inBlock = allSamples.size % 20
        val newConsecutiveLosses = if (isWin) 0 else state.consecutiveLosses + 1
        val utcDay = currentEpochSec / 86_400L
        val newTodayLoss = if (realizedPnlUsdt < 0.0) {
            state.todayRealizedLossUsdt + kotlin.math.abs(realizedPnlUsdt)
        } else state.todayRealizedLossUsdt

        val newCooldown = if (newConsecutiveLosses >= 3) {
            currentEpochSec + (4 * 3600L)
        } else state.cooldownUntilEpochSec

        val newCapital = state.totalCapitalUsdt + realizedPnlUsdt
        store.saveRiskCounters(
            PersistedRiskCounters(
                totalCapitalUsdt = newCapital,
                consecutiveLosses = newConsecutiveLosses,
                todayRealizedLossUsdt = newTodayLoss,
                todayLossUtcDayIndex = utcDay,
                cooldownUntilEpochSec = newCooldown
            )
        )

        state = state.copy(
            totalCapitalUsdt = newCapital,
            currentBlockNumber = blockNum,
            tradesInCurrentBlock = inBlock,
            consecutiveLosses = newConsecutiveLosses,
            todayRealizedLossUsdt = newTodayLoss,
            todayLossUtcDayIndex = utcDay,
            cooldownUntilEpochSec = newCooldown
        )
        return state
    }

    private fun reconcileDailyAndCooldownResets(nowSec: Long) {
        val currentUtcDay = nowSec / 86_400L
        var updatedTodayLoss = state.todayRealizedLossUsdt
        var updatedUtcDay = state.todayLossUtcDayIndex
        var updatedLosses = state.consecutiveLosses
        var updatedCooldown = state.cooldownUntilEpochSec
        var changed = false

        if (updatedUtcDay >= 0L && currentUtcDay != updatedUtcDay) {
            updatedTodayLoss = 0.0
            updatedUtcDay = currentUtcDay
            changed = true
        }
        if (updatedCooldown > 0L && nowSec >= updatedCooldown) {
            updatedCooldown = 0L
            updatedLosses = 0
            changed = true
        }

        if (changed) {
            store.saveRiskCounters(
                PersistedRiskCounters(
                    totalCapitalUsdt = state.totalCapitalUsdt,
                    consecutiveLosses = updatedLosses,
                    todayRealizedLossUsdt = updatedTodayLoss,
                    todayLossUtcDayIndex = updatedUtcDay,
                    cooldownUntilEpochSec = updatedCooldown
                )
            )
            state = state.copy(
                todayRealizedLossUsdt = updatedTodayLoss,
                todayLossUtcDayIndex = updatedUtcDay,
                consecutiveLosses = updatedLosses,
                cooldownUntilEpochSec = updatedCooldown
            )
        }
    }

    private fun buildCurrentConfig() = StrategyConfigRequest(
        symbol = state.selectedSymbol,
        marketType = state.selectedMarketType,
        executionTimeframe = state.horizonMapping.executionTimeframe,
        higherTimeframe = state.horizonMapping.higherTimeframe,
        selectionMode = state.selectionMode,
        userSelectedModules = state.manualModules
    )

    private fun buildRiskTemplate(
        ltfBars: List<BarNode>,
        currentMarkPrice: Double,
        nowSec: Long
    ): PositionSizingInput {
        val effectiveBaseRisk = state.baseRiskPct * state.horizonMapping.riskMultiplier
        val refPrice = ltfBars.lastOrNull { it.closed }?.c ?: currentMarkPrice
        return PositionSizingInput(
            symbol = state.selectedSymbol,
            marketType = state.selectedMarketType,
            direction = TradeDirection.LONG,
            totalCapitalUsdt = state.totalCapitalUsdt,
            baseRiskPct = effectiveBaseRisk,
            entryPrice = refPrice,
            currentMarkPrice = currentMarkPrice,
            stopLossPrice = refPrice * 0.98,
            takeProfit1Price = refPrice * 1.04,
            takeProfit2Price = refPrice * 1.06,
            requestedLeverage = state.requestedLeverage,
            maxAllowedLeverage = state.maxAllowedLeverage,
            openPositionsRiskUsdt = state.openPositionsRiskUsdt,
            openPositionsCount = state.openPositionsCount,
            hasSameDirectionCorrelatedTrade = state.hasCorrelatedOpenTrade,
            todayRealizedLossUsdt = state.todayRealizedLossUsdt,
            todayLossUtcDayIndex = state.todayLossUtcDayIndex,
            consecutiveLossesCount = state.consecutiveLosses,
            cooldownUntilEpochSec = state.cooldownUntilEpochSec,
            currentEpochSec = nowSec
        )
    }

    private fun buildChartBridgePayload(
        symbol: String,
        timeframe: String,
        bars: List<BarNode>,
        assistant: AssistantModeOutput,
        companion: CompanionSignalOutput
    ): LightweightChartBridgePayload {
        val boxes = mutableListOf<ChartOverlayBox>()
        assistant.keyDemandZones.forEachIndexed { idx, z ->
            boxes.add(
                ChartOverlayBox(
                    id = "DEM_$idx",
                    labelCode = "${z.kind.name} (${z.confluenceScore.toInt()}%)",
                    topPrice = z.top,
                    bottomPrice = z.bottom,
                    startTimeEpochMs = z.createdTime,
                    isBullish = true,
                    isMitigated = z.isMitigated
                )
            )
        }
        assistant.keySupplyZones.forEachIndexed { idx, z ->
            boxes.add(
                ChartOverlayBox(
                    id = "SUP_$idx",
                    labelCode = "${z.kind.name} (${z.confluenceScore.toInt()}%)",
                    topPrice = z.top,
                    bottomPrice = z.bottom,
                    startTimeEpochMs = z.createdTime,
                    isBullish = false,
                    isMitigated = z.isMitigated
                )
            )
        }

        val lines = mutableListOf<ChartHorizontalLine>()
        lines.add(ChartHorizontalLine("EQ_50", "FIB_EQ_50", assistant.equilibriumPrice, "DASHED_GRAY"))
        lines.add(ChartHorizontalLine("VWAP", "INST_VWAP", assistant.vwapLevel, "DOTTED_BLUE"))
        lines.add(ChartHorizontalLine("VPOC", "VOL_POC", assistant.pocLevel, "SOLID_GOLD"))

        assistant.magnetLiquidityPools.take(4).forEachIndexed { idx, pool ->
            lines.add(
                ChartHorizontalLine(
                    id = "LIQ_$idx",
                    labelCode = pool.kind.name,
                    price = pool.level,
                    lineStyleCode = "DASHED_MAGENTA"
                )
            )
        }

        if (companion.isSignalActive) {
            lines.add(ChartHorizontalLine("SIG_ENTRY", "OPTIMAL_ENTRY", companion.optimalEntryPrice, "SOLID_CYAN"))
            lines.add(ChartHorizontalLine("SIG_SL", "STOP_LOSS", companion.stopLossPrice, "SOLID_RED"))
            lines.add(ChartHorizontalLine("SIG_TP1", "TP1_NET", companion.takeProfit1Price, "SOLID_GREEN"))
            lines.add(ChartHorizontalLine("SIG_TP2", "TP2_NET", companion.takeProfit2Price, "DASHED_GREEN"))
        }

        return LightweightChartBridgePayload(
            symbol = symbol,
            timeframe = timeframe,
            candles = bars,
            overlayZones = boxes,
            structuralLines = lines
        )
    }
}
