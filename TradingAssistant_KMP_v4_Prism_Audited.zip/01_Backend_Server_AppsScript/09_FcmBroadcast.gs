/**
 * 09_FcmBroadcast.gs
 * ارسال پوش نوتیفیکیشن همگانی و هدفمند از Google Sheets به Android از طریق FCM HTTP v1 API
 * اصلاح‌شده: یکتاسازی UUID قبل از امضا، قفل همزمانی LockService، وضعیت میانی SENDING و امضای نامتقارن RSA-SHA256 روی کل محتوا
 */

const NOTIF_SHEET_NAME = 'Notifications';

function getFcmAccessToken_() {
  const props = PropertiesService.getScriptProperties();
  const clientEmail = props.getProperty('FCM_CLIENT_EMAIL');
  const privateKey = (props.getProperty('FCM_PRIVATE_KEY') || '').replace(/\\n/g, '\n');

  if (!clientEmail || !privateKey) {
    throw new Error('FCM_CLIENT_EMAIL or FCM_PRIVATE_KEY is missing in ScriptProperties');
  }

  const header = { alg: 'RS256', typ: 'JWT' };
  const nowSec = Math.floor(Date.now() / 1000);
  const claimSet = {
    iss: clientEmail,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: nowSec,
    exp: nowSec + 3600
  };

  const toBase64Url = (obj) =>
    Utilities.base64EncodeWebSafe(JSON.stringify(obj)).replace(/=+$/, '');

  const unsignedJwt = toBase64Url(header) + '.' + toBase64Url(claimSet);
  const signatureBytes = Utilities.computeRsaSha256Signature(unsignedJwt, privateKey);
  const signedJwt = unsignedJwt + '.' + Utilities.base64EncodeWebSafe(signatureBytes).replace(/=+$/, '');

  const tokenResp = UrlFetchApp.fetch('https://oauth2.googleapis.com/token', {
    method: 'post',
    payload: {
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: signedJwt
    },
    muteHttpExceptions: true
  });

  const tokenData = JSON.parse(tokenResp.getContentText());
  if (!tokenData.access_token) {
    throw new Error('Failed to obtain FCM OAuth2 token: ' + tokenResp.getContentText());
  }
  return tokenData.access_token;
}

function signBroadcastAsymmetricRsa_(canonicalPayload) {
  const props = PropertiesService.getScriptProperties();
  const broadcastPrivateKey = (props.getProperty('BROADCAST_RSA_PRIVATE_KEY') || props.getProperty('FCM_PRIVATE_KEY') || '').replace(/\\n/g, '\n');
  if (!broadcastPrivateKey) {
    throw new Error('BROADCAST_RSA_PRIVATE_KEY is missing in ScriptProperties');
  }
  const sigBytes = Utilities.computeRsaSha256Signature(canonicalPayload, broadcastPrivateKey);
  return Utilities.base64Encode(sigBytes);
}

function processScheduledNotifications() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) {
    return;
  }

  try {
    const sheet = getDb_().getSheetByName(NOTIF_SHEET_NAME);
    if (!sheet) return;

    const values = sheet.getDataRange().getValues();
    if (values.length <= 1) return;

    const projectId = PropertiesService.getScriptProperties().getProperty('FCM_PROJECT_ID');
    if (!projectId) throw new Error('FCM_PROJECT_ID is missing in ScriptProperties');

    const accessToken = getFcmAccessToken_();
    const nowMs = Date.now();

    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      const rowIndex = i + 1;
      const rawNotifId = String(row[0] || '').trim();
      const title = String(row[1] || '').trim();
      const body = String(row[2] || '').trim();
      const targetUrl = String(row[3] || '').trim();
      const audience = String(row[4] || 'ALL').trim().toUpperCase();
      const scheduledStr = String(row[5] || '').trim();
      const status = String(row[6] || '').trim().toUpperCase();

      if (status !== 'PENDING' || !title || !body) continue;

      if (scheduledStr) {
        const schedMs = new Date(scheduledStr).getTime();
        if (!isNaN(schedMs) && schedMs > nowMs) continue;
      }

      if (targetUrl && !targetUrl.startsWith('https://')) {
        sheet.getRange(rowIndex, 7).setValue('FAILED');
        sheet.getRange(rowIndex, 9).setValue('ERR: target_url must start with https://');
        continue;
      }

      const resolvedNotifId = rawNotifId || ('NTF-' + Utilities.getUuid());
      if (!rawNotifId) {
        sheet.getRange(rowIndex, 1).setValue(resolvedNotifId);
      }

      sheet.getRange(rowIndex, 7).setValue('SENDING');
      SpreadsheetApp.flush();

      const topicMap = {
        'ALL': 'ta_broadcast_all',
        'ASSISTANT': 'ta_broadcast_assistant',
        'COMPANION': 'ta_broadcast_companion',
        'ACTIVE_SUBSCRIBERS': 'ta_broadcast_vip'
      };
      const topic = topicMap[audience] || 'ta_broadcast_all';

      const canonicalPayload = [resolvedNotifId, title, body, targetUrl, audience].join('|');
      const rsaSignatureBase64 = signBroadcastAsymmetricRsa_(canonicalPayload);

      const fcmPayload = {
        message: {
          topic: topic,
          notification: {
            title: title,
            body: body
          },
          data: {
            notif_id: resolvedNotifId,
            title: title,
            body: body,
            target_url: targetUrl,
            audience: audience,
            sig_alg: 'RS256',
            sig: rsaSignatureBase64
          },
          android: {
            priority: 'high',
            notification: {
              channel_id: 'ta_admin_broadcasts'
            }
          }
        }
      };

      const url = 'https://fcm.googleapis.com/v1/projects/' + projectId + '/messages:send';
      const resp = UrlFetchApp.fetch(url, {
        method: 'post',
        contentType: 'application/json',
        headers: { Authorization: 'Bearer ' + accessToken },
        payload: JSON.stringify(fcmPayload),
        muteHttpExceptions: true
      });

      const code = resp.getResponseCode();
      const respText = resp.getContentText();

      if (code === 200) {
        sheet.getRange(rowIndex, 7).setValue('SENT');
        sheet.getRange(rowIndex, 8).setValue(nowUtcIso_());
        sheet.getRange(rowIndex, 9).setValue('OK: ' + respText);
        logEvent_('ADMIN_BROADCAST_SENT', 'ADMIN', '', '', '', '', 'SUCCESS', {
          notif_id: resolvedNotifId,
          topic: topic
        });
      } else {
        sheet.getRange(rowIndex, 7).setValue('FAILED');
        sheet.getRange(rowIndex, 9).setValue('ERR ' + code + ': ' + respText);
      }
    }
  } finally {
    lock.releaseLock();
  }
}
