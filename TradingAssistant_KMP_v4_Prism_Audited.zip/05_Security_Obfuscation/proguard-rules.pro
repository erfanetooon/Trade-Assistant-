-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
-repackageclasses 'o'
-allowaccessmodification

-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*

-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontnote kotlinx.serialization.**

-keep class net.sqlcipher.** { *; }
-keep class net.sqlcipher.database.** { *; }
-keep class app.cash.sqldelight.** { *; }
-keep class com.ta.core.db.** { *; }

-keepclassmembers class * {
    @kotlinx.serialization.SerialName <fields>;
}
-keep,includedescriptorclasses class com.ta.**$$serializer { *; }
-keepclassmembers class com.ta.** {
    *** Companion;
}
