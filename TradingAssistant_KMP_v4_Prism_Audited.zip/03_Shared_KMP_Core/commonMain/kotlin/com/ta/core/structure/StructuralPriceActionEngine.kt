package com.ta.core.structure

import com.ta.core.quant.BarNode
import com.ta.core.quant.CoreQuantIndicatorsEngine
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class PivotKind { HIGH, LOW }

enum class ConfirmDirection { NONE, LONG, SHORT }

data class PivotNode(
    val idx: Int,
    val t: Long,
    val price: Double,
    val kind: PivotKind,
    val vol: Double,
    val swept: Boolean = false
)

enum class StructureBreakKind {
    NONE,
    BOS_BULL,
    BOS_BEAR,
    CHOCH_BULL,
    CHOCH_BEAR,
    MSS_BULL_DISPLACEMENT,
    MSS_BEAR_DISPLACEMENT
}

data class WaveMetrics(
    val startIdx: Int,
    val endIdx: Int,
    val isBullish: Boolean,
    val priceDistance: Double,
    val barCount: Int,
    val speedAngle: Double,
    val cumulativeVolume: Double,
    val projectionRatioVsPrev: Double,
    val depthRatioVsPrev: Double,
    val effortResultHarmony: Boolean
)

enum class WyckoffPhase {
    NONE,
    PHASE_A_STOPPING,
    PHASE_B_CAUSE_BUILDING,
    PHASE_C_TESTING,
    PHASE_D_TREND_IN_RANGE,
    PHASE_E_TREND_OUT_RANGE
}

enum class WyckoffBias {
    NONE,
    ACCUMULATION,
    REACCUMULATION,
    DISTRIBUTION,
    REDISTRIBUTION
}

enum class WyckoffEventCode {
    NONE,
    PS_OR_PSY,
    SC_CLIMAX,
    SC_EXHAUSTION,
    BC_CLIMAX,
    BC_EXHAUSTION,
    AR_RALLY,
    AR_REACTION,
    ST_PHASE_A,
    UA_PHASE_B,
    UT_PHASE_B,
    ST_AS_SOW_B,
    MSOW_PHASE_B,
    SPRING_TYPE_1_TSO,
    SPRING_TYPE_2_NEEDS_TEST,
    SPRING_TYPE_3_LOW_VOL,
    SPRING_TEST_VALID,
    ORDINARY_SHAKEOUT,
    UTAD_HIGH_VOL,
    UTAD_MINOR,
    UTAD_TEST_VALID,
    ORDINARY_UPTHRUST,
    LPS_PHASE_C_SCHEME2,
    LPSY_PHASE_C_SCHEME2,
    SOS_JAC_BREAKOUT,
    MSOW_FTI_BREAKDOWN,
    BUEC_LPS_CONFIRM,
    FTI_LPSY_CONFIRM,
    SIGNIFICANT_SOS_BAR,
    SIGNIFICANT_SOW_BAR,
    NO_SUPPLY_TEST_BAR,
    NO_DEMAND_TEST_BAR
}

data class WyckoffRangeState(
    val isActive: Boolean,
    val bias: WyckoffBias,
    val phase: WyckoffPhase,
    val lastEvent: WyckoffEventCode,
    val creekResistance: Double,
    val iceSupport: Double,
    val climaxExtreme: Double,
    val shakeoutExtreme: Double?,
    val causeBarsCount: Int,
    val target1to1Projection: Double,
    val targetFib1618Projection: Double,
    val hasValidConfirmationTrigger: Boolean,
    val confirmDirection: ConfirmDirection = ConfirmDirection.NONE,
    val confirmBarIdx: Int = -1,
    val anchorClimaxTime: Long = 0L,
    val structuralStopLevel: Double
)

enum class LiquidityPoolKind {
    BUY_SIDE_EQH,
    SELL_SIDE_EQL,
    MAJOR_SWING_HIGH_BSL,
    MAJOR_SWING_LOW_SSL,
    RANGE_CREEK_BSL,
    RANGE_ICE_SSL
}

data class LiquidityPoolNode(
    val kind: LiquidityPoolKind,
    val level: Double,
    val touchCount: Int,
    val firstIdx: Int,
    val lastIdx: Int,
    val isSwept: Boolean,
    val sweepBarIdx: Int?,
    val sweepExtremePrice: Double?,
    val sweepRejectedCloseInside: Boolean
)

enum class ZoneKind {
    BULL_ORDER_BLOCK,
    BEAR_ORDER_BLOCK,
    BULL_BREAKER,
    BEAR_BREAKER,
    BULL_FVG,
    BEAR_FVG,
    RTM_DEMAND_DBR,
    RTM_DEMAND_RBR,
    RTM_SUPPLY_RBD,
    RTM_SUPPLY_DBD
}

data class SupplyDemandZone(
    val kind: ZoneKind,
    val top: Double,
    val bottom: Double,
    val midConsequentEncroachment: Double,
    val createdIdx: Int,
    val createdTime: Long,
    val touchCount: Int,
    val isMitigated: Boolean,
    val hasCleanArrivalCompression: Boolean,
    val confluenceScore: Double
)

data class FibMatrix(
    val anchorLow: Double,
    val anchorHigh: Double,
    val isBullishSwing: Boolean,
    val equilibrium50: Double,
    val ret382: Double,
    val ret618: Double,
    val ote705: Double,
    val ret786: Double,
    val ext1272: Double,
    val ext1618: Double,
    val ext2000: Double,
    val ext2618: Double,
    val isCurrentPriceInDiscount: Boolean,
    val isCurrentPriceInOteZone: Boolean
)

data class StructuralSnapshot(
    val timestamp: Long,
    val lastBarIndex: Int,
    val closePrice: Double,
    val trendDirection: Int,
    val lastBreakKind: StructureBreakKind,
    val swings: List<PivotNode>,
    val waves: List<WaveMetrics>,
    val wyckoff: WyckoffRangeState,
    val liquidityPools: List<LiquidityPoolNode>,
    val recentSweepPool: LiquidityPoolNode?,
    val activeZones: List<SupplyDemandZone>,
    val fib: FibMatrix,
    val isSignificantBullBar: Boolean,
    val isSignificantBearBar: Boolean,
    val isNoSupplyBar: Boolean,
    val isNoDemandBar: Boolean,
    val isMovementReversalBull: Boolean,
    val isMovementReversalBear: Boolean
)

data class StructuralComputeResult(
    val statusCode: String,
    val snapshot: StructuralSnapshot?
)

object StructuralPriceActionEngine {

    fun analyzeStructure(
        rawBars: List<BarNode>,
        swingSpan: Int = 3,
        eqToleranceAtrMult: Double = 0.18,
        rangeLookback: Int = 140,
        previousRangeState: WyckoffRangeState? = null
    ): StructuralSnapshot? {
        return analyzeStructureResult(
            rawBars = rawBars,
            swingSpan = swingSpan,
            eqToleranceAtrMult = eqToleranceAtrMult,
            rangeLookback = rangeLookback,
            previousRangeState = previousRangeState
        ).snapshot
    }

    fun analyzeStructureResult(
        rawBars: List<BarNode>,
        swingSpan: Int = 3,
        eqToleranceAtrMult: Double = 0.18,
        rangeLookback: Int = 140,
        previousRangeState: WyckoffRangeState? = null
    ): StructuralComputeResult {
        val bars = rawBars.filter { it.closed }
        val n = bars.size
        if (n < max(rangeLookback, 80)) {
            return StructuralComputeResult("INSUFFICIENT_HISTORY", null)
        }

        val highs = DoubleArray(n) { bars[it].h }
        val lows = DoubleArray(n) { bars[it].l }
        val closes = DoubleArray(n) { bars[it].c }
        val vols = DoubleArray(n) { bars[it].v }

        val atrSeries = CoreQuantIndicatorsEngine.calcAtrWilderSeries(highs, lows, closes, 14)
        val volSma20 = CoreQuantIndicatorsEngine.calcSmaSeries(vols, 20)
        val lastIdx = n - 1
        val lastAtr = max(1e-8, atrSeries[lastIdx])

        val pivots = extractConfirmedPivots(bars, swingSpan)
        if (pivots.size < 6) {
            return StructuralComputeResult("INSUFFICIENT_PIVOTS", null)
        }

        val waves = computeWeisAndWaveMetrics(bars, pivots)
        val (trendDir, breakKind) = evaluateMarketStructureAndMss(bars, pivots, atrSeries)
        val fib = buildFibonacciMatrix(pivots, bars[lastIdx].c)
        val pools = detectLiquidityPoolsAndSweeps(bars, pivots, lastAtr * eqToleranceAtrMult)
        val recentSweep = pools.lastOrNull { it.isSwept && it.sweepBarIdx != null && (lastIdx - it.sweepBarIdx) <= 5 }

        val wyckoffState = evaluateWyckoffStateMachine(
            bars = bars,
            atrSeries = atrSeries,
            volSma = volSma20,
            lookback = min(n - 10, rangeLookback),
            previousState = previousRangeState
        )

        val zones = extractOrderBlocksFvgAndRtmZones(
            bars = bars,
            atrSeries = atrSeries,
            volSma = volSma20,
            fib = fib,
            wyckoff = wyckoffState,
            pivots = pivots
        )

        val sigBull = isSignificantIntentBar(bars[lastIdx], atrSeries[lastIdx], volSma20[lastIdx], true, pivots)
        val sigBear = isSignificantIntentBar(bars[lastIdx], atrSeries[lastIdx], volSma20[lastIdx], false, pivots)
        val noSup = isVsaTestBar(bars, lastIdx, atrSeries[lastIdx], true)
        val noDem = isVsaTestBar(bars, lastIdx, atrSeries[lastIdx], false)
        val (revBull, revBear) = detectMovementReversalOverSignificantBar(bars, atrSeries, volSma20, pivots)

        val snap = StructuralSnapshot(
            timestamp = bars[lastIdx].t,
            lastBarIndex = lastIdx,
            closePrice = bars[lastIdx].c,
            trendDirection = trendDir,
            lastBreakKind = breakKind,
            swings = pivots.takeLast(16),
            waves = waves.takeLast(10),
            wyckoff = wyckoffState,
            liquidityPools = pools.takeLast(20),
            recentSweepPool = recentSweep,
            activeZones = zones,
            fib = fib,
            isSignificantBullBar = sigBull,
            isSignificantBearBar = sigBear,
            isNoSupplyBar = noSup,
            isNoDemandBar = noDem,
            isMovementReversalBull = revBull,
            isMovementReversalBear = revBear
        )
        return StructuralComputeResult("OK", snap)
    }

    private fun extractConfirmedPivots(bars: List<BarNode>, span: Int): List<PivotNode> {
        val n = bars.size
        val rawList = mutableListOf<PivotNode>()
        val lastConfirm = n - 1 - span
        for (i in span..lastConfirm) {
            var isH = true
            var isL = true
            val h = bars[i].h
            val l = bars[i].l
            for (k in 1..span) {
                if (h <= bars[i - k].h || h < bars[i + k].h) isH = false
                if (l >= bars[i - k].l || l > bars[i + k].l) isL = false
            }
            if (isH) rawList.add(PivotNode(i, bars[i].t, h, PivotKind.HIGH, bars[i].v))
            if (isL) rawList.add(PivotNode(i, bars[i].t, l, PivotKind.LOW, bars[i].v))
        }
        val cleaned = mutableListOf<PivotNode>()
        for (p in rawList) {
            if (cleaned.isEmpty()) {
                cleaned.add(p)
            } else {
                val prev = cleaned.last()
                if (prev.kind == p.kind) {
                    val replace = (p.kind == PivotKind.HIGH && p.price >= prev.price) ||
                        (p.kind == PivotKind.LOW && p.price <= prev.price)
                    if (replace) cleaned[cleaned.size - 1] = p
                } else {
                    cleaned.add(p)
                }
            }
        }
        return cleaned
    }

    private fun computeWeisAndWaveMetrics(bars: List<BarNode>, pivots: List<PivotNode>): List<WaveMetrics> {
        val out = mutableListOf<WaveMetrics>()
        if (pivots.size < 2) return out

        for (i in 1 until pivots.size) {
            val p0 = pivots[i - 1]
            val p1 = pivots[i]
            val isBull = p1.price > p0.price
            val dist = abs(p1.price - p0.price)
            val barCnt = max(1, p1.idx - p0.idx)
            val speed = dist / barCnt.toDouble()
            var cumVol = 0.0
            for (bIdx in p0.idx..p1.idx) {
                cumVol += bars[bIdx].v
            }

            val prevSameDir = out.lastOrNull { it.isBullish == isBull }
            val prevOpposite = out.lastOrNull { it.isBullish != isBull }

            val projRatio = if (prevSameDir != null && prevSameDir.priceDistance > 0.0) {
                dist / prevSameDir.priceDistance
            } else 1.0

            val depthRatio = if (prevOpposite != null && prevOpposite.priceDistance > 0.0) {
                dist / prevOpposite.priceDistance
            } else 0.5

            val volHarmony = if (prevSameDir != null) {
                (projRatio >= 1.0 && cumVol >= prevSameDir.cumulativeVolume * 0.85) ||
                    (projRatio < 0.8 && cumVol < prevSameDir.cumulativeVolume)
            } else true

            out.add(
                WaveMetrics(
                    startIdx = p0.idx,
                    endIdx = p1.idx,
                    isBullish = isBull,
                    priceDistance = dist,
                    barCount = barCnt,
                    speedAngle = speed,
                    cumulativeVolume = cumVol,
                    projectionRatioVsPrev = projRatio,
                    depthRatioVsPrev = depthRatio,
                    effortResultHarmony = volHarmony
                )
            )
        }
        return out
    }

    private fun evaluateMarketStructureAndMss(
        bars: List<BarNode>,
        pivots: List<PivotNode>,
        atrSeries: DoubleArray
    ): Pair<Int, StructureBreakKind> {
        val highs = pivots.filter { it.kind == PivotKind.HIGH }
        val lows = pivots.filter { it.kind == PivotKind.LOW }
        if (highs.size < 2 || lows.size < 2) return Pair(0, StructureBreakKind.NONE)

        val h2 = highs[highs.size - 1]
        val h1 = highs[highs.size - 2]
        val l2 = lows[lows.size - 1]
        val l1 = lows[lows.size - 2]

        val prevBull = h1.price > (highs.getOrNull(highs.size - 3)?.price ?: h1.price) &&
            l2.price >= l1.price
        val prevBear = l1.price < (lows.getOrNull(lows.size - 3)?.price ?: l1.price) &&
            h2.price <= h1.price

        val lastIdx = bars.size - 1
        val lastClose = bars[lastIdx].c
        val recentSlice = bars.subList(max(0, lastIdx - 4), lastIdx + 1)
        val hasDisplacement = recentSlice.any { b ->
            abs(b.c - b.o) >= atrSeries[lastIdx] * 1.35 &&
                abs(b.c - b.o) >= (b.h - b.l) * 0.65
        }

        if (lastClose > h2.price) {
            val kind = when {
                prevBear && hasDisplacement -> StructureBreakKind.MSS_BULL_DISPLACEMENT
                prevBear -> StructureBreakKind.CHOCH_BULL
                else -> StructureBreakKind.BOS_BULL
            }
            return Pair(1, kind)
        }
        if (lastClose < l2.price) {
            val kind = when {
                prevBull && hasDisplacement -> StructureBreakKind.MSS_BEAR_DISPLACEMENT
                prevBull -> StructureBreakKind.CHOCH_BEAR
                else -> StructureBreakKind.BOS_BEAR
            }
            return Pair(-1, kind)
        }

        val currentBias = when {
            h2.price > h1.price && l2.price > l1.price -> 1
            h2.price < h1.price && l2.price < l1.price -> -1
            else -> 0
        }
        return Pair(currentBias, StructureBreakKind.NONE)
    }

    private fun buildFibonacciMatrix(pivots: List<PivotNode>, currentClose: Double): FibMatrix {
        val recent = pivots.takeLast(6)
        val maxP = recent.maxByOrNull { it.price } ?: pivots.last()
        val minP = recent.minByOrNull { it.price } ?: pivots.first()
        val isBullSwing = minP.idx < maxP.idx
        val low = minP.price
        val high = max(low + 1e-8, maxP.price)
        val span = high - low
        val eq = low + span * 0.50

        val r382 = if (isBullSwing) high - span * 0.382 else low + span * 0.382
        val r618 = if (isBullSwing) high - span * 0.618 else low + span * 0.618
        val r705 = if (isBullSwing) high - span * 0.705 else low + span * 0.705
        val r786 = if (isBullSwing) high - span * 0.786 else low + span * 0.786

        val e1272 = if (isBullSwing) low + span * 1.272 else high - span * 1.272
        val e1618 = if (isBullSwing) low + span * 1.618 else high - span * 1.618
        val e2000 = if (isBullSwing) low + span * 2.000 else high - span * 2.000
        val e2618 = if (isBullSwing) low + span * 2.618 else high - span * 2.618

        val inDiscount = currentClose < eq
        val oteTop = max(r618, r786)
        val oteBot = min(r618, r786)
        val inOte = currentClose in oteBot..oteTop

        return FibMatrix(
            anchorLow = low,
            anchorHigh = high,
            isBullishSwing = isBullSwing,
            equilibrium50 = eq,
            ret382 = r382,
            ret618 = r618,
            ote705 = r705,
            ret786 = r786,
            ext1272 = e1272,
            ext1618 = e1618,
            ext2000 = e2000,
            ext2618 = e2618,
            isCurrentPriceInDiscount = inDiscount,
            isCurrentPriceInOteZone = inOte
        )
    }

    private fun detectLiquidityPoolsAndSweeps(
        bars: List<BarNode>,
        pivots: List<PivotNode>,
        tolerance: Double
    ): List<LiquidityPoolNode> {
        val pools = mutableListOf<LiquidityPoolNode>()
        val usedIdxs = mutableSetOf<Int>()

        for (i in pivots.indices) {
            if (i in usedIdxs) continue
            val pA = pivots[i]
            val cluster = mutableListOf(pA)
            for (j in (i + 1) until pivots.size) {
                val pB = pivots[j]
                if (pB.kind == pA.kind && abs(pB.price - pA.price) <= tolerance) {
                    cluster.add(pB)
                    usedIdxs.add(j)
                }
            }
            val avgLevel = cluster.map { it.price }.average()
            val lastClusterIdx = cluster.last().idx
            var swept = false
            var sweepIdx: Int? = null
            var sweepExtreme: Double? = null
            var rejectedInside = false

            for (k in (lastClusterIdx + 1) until bars.size) {
                val b = bars[k]
                if (pA.kind == PivotKind.HIGH && b.h > avgLevel) {
                    swept = true
                    sweepIdx = k
                    sweepExtreme = b.h
                    rejectedInside = b.c < avgLevel
                    break
                } else if (pA.kind == PivotKind.LOW && b.l < avgLevel) {
                    swept = true
                    sweepIdx = k
                    sweepExtreme = b.l
                    rejectedInside = b.c > avgLevel
                    break
                }
            }

            val poolKind = when {
                pA.kind == PivotKind.HIGH && cluster.size >= 2 -> LiquidityPoolKind.BUY_SIDE_EQH
                pA.kind == PivotKind.LOW && cluster.size >= 2 -> LiquidityPoolKind.SELL_SIDE_EQL
                pA.kind == PivotKind.HIGH -> LiquidityPoolKind.MAJOR_SWING_HIGH_BSL
                else -> LiquidityPoolKind.MAJOR_SWING_LOW_SSL
            }

            pools.add(
                LiquidityPoolNode(
                    kind = poolKind,
                    level = avgLevel,
                    touchCount = cluster.size,
                    firstIdx = cluster.first().idx,
                    lastIdx = lastClusterIdx,
                    isSwept = swept,
                    sweepBarIdx = sweepIdx,
                    sweepExtremePrice = sweepExtreme,
                    sweepRejectedCloseInside = rejectedInside
                )
            )
        }
        return pools
    }

    private fun inactiveWyckoff(closePrice: Double): WyckoffRangeState = WyckoffRangeState(
        isActive = false,
        bias = WyckoffBias.NONE,
        phase = WyckoffPhase.NONE,
        lastEvent = WyckoffEventCode.NONE,
        creekResistance = closePrice,
        iceSupport = closePrice,
        climaxExtreme = closePrice,
        shakeoutExtreme = null,
        causeBarsCount = 0,
        target1to1Projection = closePrice,
        targetFib1618Projection = closePrice,
        hasValidConfirmationTrigger = false,
        confirmDirection = ConfirmDirection.NONE,
        confirmBarIdx = -1,
        anchorClimaxTime = 0L,
        structuralStopLevel = closePrice
    )

    private fun evaluateWyckoffStateMachine(
        bars: List<BarNode>,
        atrSeries: DoubleArray,
        volSma: DoubleArray,
        lookback: Int,
        previousState: WyckoffRangeState?
    ): WyckoffRangeState {
        val n = bars.size
        val lastIdx = n - 1
        val lastClose = bars[lastIdx].c
        val recentAtr = max(1e-8, atrSeries[lastIdx])

        var climaxIdx = -1
        var isSellingClimax = true
        var creekLevel = 0.0
        var iceLevel = 0.0
        var arExtremeIdx = -1

        if (previousState != null && previousState.isActive && previousState.anchorClimaxTime > 0L) {
            val anchored = bars.indexOfFirst { it.t == previousState.anchorClimaxTime }
            if (anchored in 15..(n - 16)) {
                climaxIdx = anchored
                isSellingClimax = previousState.bias == WyckoffBias.ACCUMULATION ||
                    previousState.bias == WyckoffBias.REACCUMULATION ||
                    abs(bars[anchored].l - previousState.climaxExtreme) <= recentAtr * 0.2
                creekLevel = previousState.creekResistance
                iceLevel = previousState.iceSupport
                arExtremeIdx = min(lastIdx - 1, climaxIdx + 12)
            }
        }

        if (climaxIdx < 0) {
            val searchStart = max(20, n - lookback)
            val searchEnd = n - 16
            if (searchEnd <= searchStart) return inactiveWyckoff(lastClose)

            var bestClimaxScore = 0.0
            for (i in searchStart..searchEnd) {
                val b = bars[i]
                val atr = max(1e-8, atrSeries[i])
                val vAvg = max(1e-8, volSma[i])
                val spreadRatio = (b.h - b.l) / atr
                val volRatio = b.v / vAvg
                if (volRatio < 1.5 || spreadRatio < 1.35) continue

                val priorDelta = bars[i].c - bars[max(0, i - 20)].c
                val isScCandidate = priorDelta < -atr * 1.5 && b.l <= bars.subList(max(0, i - 10), i + 1).minOf { it.l }
                val isBcCandidate = priorDelta > atr * 1.5 && b.h >= bars.subList(max(0, i - 10), i + 1).maxOf { it.h }
                if (!isScCandidate && !isBcCandidate) continue

                val score = volRatio * spreadRatio
                if (score > bestClimaxScore) {
                    bestClimaxScore = score
                    climaxIdx = i
                    isSellingClimax = isScCandidate
                }
            }

            if (climaxIdx < 0 || climaxIdx >= lastIdx - 15) return inactiveWyckoff(lastClose)

            val arEnd = min(lastIdx - 1, climaxIdx + 18)
            arExtremeIdx = climaxIdx + 1
            for (i in (climaxIdx + 1)..arEnd) {
                if (isSellingClimax && bars[i].h > bars[arExtremeIdx].h) arExtremeIdx = i
                if (!isSellingClimax && bars[i].l < bars[arExtremeIdx].l) arExtremeIdx = i
            }
            creekLevel = if (isSellingClimax) bars[arExtremeIdx].h else bars[climaxIdx].h
            iceLevel = if (isSellingClimax) bars[climaxIdx].l else bars[arExtremeIdx].l
        }

        val rangeHeight = creekLevel - iceLevel
        if (rangeHeight < recentAtr * 1.5 || rangeHeight > recentAtr * 12.0) {
            return inactiveWyckoff(lastClose)
        }

        val causeBars = lastIdx - climaxIdx
        if (causeBars < 15) return inactiveWyckoff(lastClose)

        val touchTol = recentAtr * 0.25
        var insideCount = 0
        var totalRangeBars = 0
        var creekTouches = 0
        var iceTouches = 0
        var lastCreekTouchIdx = -10
        var lastIceTouchIdx = -10

        for (i in climaxIdx..lastIdx) {
            val b = bars[i]
            totalRangeBars++
            if (b.c in (iceLevel - touchTol)..(creekLevel + touchTol)) {
                insideCount++
            }
            if (b.h >= creekLevel - touchTol && i - lastCreekTouchIdx >= 3) {
                creekTouches++
                lastCreekTouchIdx = i
            }
            if (b.l <= iceLevel + touchTol && i - lastIceTouchIdx >= 3) {
                iceTouches++
                lastIceTouchIdx = i
            }
        }

        val insideRatio = insideCount.toDouble() / max(1, totalRangeBars).toDouble()
        if (insideRatio < 0.70 || creekTouches < 2 || iceTouches < 2) {
            return inactiveWyckoff(lastClose)
        }

        val preStartIdx = max(0, climaxIdx - 25)
        val cameFromDowntrend = bars[climaxIdx].c < bars[preStartIdx].c

        var activePathDir = ConfirmDirection.NONE
        var phase = WyckoffPhase.PHASE_B_CAUSE_BUILDING
        var lastEvent = if (isSellingClimax) WyckoffEventCode.SC_CLIMAX else WyckoffEventCode.BC_CLIMAX
        var shakeExtreme: Double? = null
        var springIdx: Int? = null
        var springType = WyckoffEventCode.NONE
        var utadIdx: Int? = null
        var utadType = WyckoffEventCode.NONE
        var jacIdx: Int? = null
        var msowIdx: Int? = null
        var confirmDir = ConfirmDirection.NONE
        var confirmBarIdx = -1
        var stopLvl = if (isSellingClimax) iceLevel - recentAtr * 0.5 else creekLevel + recentAtr * 0.5

        val scanStart = min(lastIdx, arExtremeIdx + 3)
        for (i in scanStart..lastIdx) {
            val b = bars[i]
            val atr = max(1e-8, atrSeries[i])
            val vAvg = max(1e-8, volSma[i])
            val vRatio = b.v / vAvg
            val spreadRatio = (b.h - b.l) / atr

            if (springIdx != null && activePathDir == ConfirmDirection.LONG) {
                val spLow = bars[springIdx].l
                if (b.c < spLow || b.c < iceLevel - (atr * 0.35)) {
                    springIdx = null
                    springType = WyckoffEventCode.NONE
                    shakeExtreme = null
                    confirmDir = ConfirmDirection.NONE
                    confirmBarIdx = -1
                    activePathDir = ConfirmDirection.NONE
                    phase = WyckoffPhase.PHASE_B_CAUSE_BUILDING
                }
            }

            if (utadIdx != null && activePathDir == ConfirmDirection.SHORT) {
                val utHigh = bars[utadIdx].h
                if (b.c > utHigh || b.c > creekLevel + (atr * 0.35)) {
                    utadIdx = null
                    utadType = WyckoffEventCode.NONE
                    shakeExtreme = null
                    confirmDir = ConfirmDirection.NONE
                    confirmBarIdx = -1
                    activePathDir = ConfirmDirection.NONE
                    phase = WyckoffPhase.PHASE_B_CAUSE_BUILDING
                }
            }

            if (activePathDir != ConfirmDirection.SHORT) {
                if (springIdx == null && b.l < iceLevel && b.c >= iceLevel - (atr * 0.25)) {
                    val penetrationAtr = (iceLevel - b.l) / atr
                    springIdx = i
                    activePathDir = ConfirmDirection.LONG
                    phase = WyckoffPhase.PHASE_C_TESTING
                    shakeExtreme = b.l
                    stopLvl = b.l - (atr * 0.30)
                    springType = when {
                        penetrationAtr >= 1.2 && vRatio >= 1.6 -> WyckoffEventCode.SPRING_TYPE_1_TSO
                        vRatio <= 0.85 && spreadRatio <= 0.95 -> WyckoffEventCode.SPRING_TYPE_3_LOW_VOL
                        else -> WyckoffEventCode.SPRING_TYPE_2_NEEDS_TEST
                    }
                    lastEvent = springType
                } else if (springIdx != null && i > springIdx && jacIdx == null) {
                    val spBar = bars[springIdx]
                    if (springType == WyckoffEventCode.SPRING_TYPE_3_LOW_VOL && confirmBarIdx < 0) {
                        if (b.c > iceLevel && b.l > spBar.l) {
                            lastEvent = WyckoffEventCode.SPRING_TEST_VALID
                            confirmDir = ConfirmDirection.LONG
                            confirmBarIdx = i
                        }
                    } else if (b.l > spBar.l && b.l <= iceLevel + atr * 0.35 &&
                        b.c > iceLevel && b.v < spBar.v && (b.h - b.l) < (spBar.h - spBar.l)
                    ) {
                        lastEvent = WyckoffEventCode.SPRING_TEST_VALID
                        confirmDir = ConfirmDirection.LONG
                        confirmBarIdx = i
                        stopLvl = min(spBar.l, b.l) - (atr * 0.30)
                    }
                }

                if (jacIdx == null &&
                    b.c > creekLevel + (atr * 0.35) &&
                    b.c > b.o &&
                    spreadRatio >= 1.2 &&
                    vRatio >= 1.3
                ) {
                    jacIdx = i
                    activePathDir = ConfirmDirection.LONG
                    phase = WyckoffPhase.PHASE_D_TREND_IN_RANGE
                    lastEvent = WyckoffEventCode.SOS_JAC_BREAKOUT
                    confirmDir = ConfirmDirection.LONG
                    confirmBarIdx = i
                    stopLvl = min(b.l, creekLevel) - (atr * 0.35)
                } else if (jacIdx != null && i > jacIdx) {
                    val jacBar = bars[jacIdx]
                    if (b.l <= creekLevel + (atr * 0.30) &&
                        b.c >= creekLevel - (atr * 0.15) &&
                        b.v < jacBar.v &&
                        vRatio <= 1.0
                    ) {
                        phase = WyckoffPhase.PHASE_E_TREND_OUT_RANGE
                        lastEvent = WyckoffEventCode.BUEC_LPS_CONFIRM
                        confirmDir = ConfirmDirection.LONG
                        confirmBarIdx = i
                        stopLvl = min(b.l, creekLevel) - (atr * 0.30)
                    }
                }
            }

            if (activePathDir != ConfirmDirection.LONG) {
                if (utadIdx == null && b.h > creekLevel && b.c <= creekLevel + (atr * 0.25)) {
                    utadIdx = i
                    activePathDir = ConfirmDirection.SHORT
                    phase = WyckoffPhase.PHASE_C_TESTING
                    shakeExtreme = b.h
                    stopLvl = b.h + (atr * 0.30)
                    utadType = if (vRatio >= 1.3) WyckoffEventCode.UTAD_HIGH_VOL else WyckoffEventCode.UTAD_MINOR
                    lastEvent = utadType
                } else if (utadIdx != null && i > utadIdx && msowIdx == null) {
                    val utBar = bars[utadIdx]
                    if (b.h < utBar.h && b.h >= creekLevel - atr * 0.35 &&
                        b.c < creekLevel && b.v < utBar.v && (b.h - b.l) < (utBar.h - utBar.l)
                    ) {
                        lastEvent = WyckoffEventCode.UTAD_TEST_VALID
                        confirmDir = ConfirmDirection.SHORT
                        confirmBarIdx = i
                        stopLvl = max(utBar.h, b.h) + (atr * 0.30)
                    }
                }

                if (msowIdx == null &&
                    b.c < iceLevel - (atr * 0.35) &&
                    b.c < b.o &&
                    spreadRatio >= 1.2 &&
                    vRatio >= 1.3
                ) {
                    msowIdx = i
                    activePathDir = ConfirmDirection.SHORT
                    phase = WyckoffPhase.PHASE_D_TREND_IN_RANGE
                    lastEvent = WyckoffEventCode.MSOW_FTI_BREAKDOWN
                    confirmDir = ConfirmDirection.SHORT
                    confirmBarIdx = i
                    stopLvl = max(b.h, iceLevel) + (atr * 0.35)
                } else if (msowIdx != null && i > msowIdx) {
                    val msowBar = bars[msowIdx]
                    if (b.h >= iceLevel - (atr * 0.30) &&
                        b.c <= iceLevel + (atr * 0.15) &&
                        b.v < msowBar.v &&
                        vRatio <= 1.0
                    ) {
                        phase = WyckoffPhase.PHASE_E_TREND_OUT_RANGE
                        lastEvent = WyckoffEventCode.FTI_LPSY_CONFIRM
                        confirmDir = ConfirmDirection.SHORT
                        confirmBarIdx = i
                        stopLvl = max(b.h, iceLevel) + (atr * 0.30)
                    }
                }
            }
        }

        val bias = when (activePathDir) {
            ConfirmDirection.LONG -> if (cameFromDowntrend) WyckoffBias.ACCUMULATION else WyckoffBias.REACCUMULATION
            ConfirmDirection.SHORT -> if (!cameFromDowntrend) WyckoffBias.DISTRIBUTION else WyckoffBias.REDISTRIBUTION
            ConfirmDirection.NONE -> WyckoffBias.NONE
        }

        val isFreshConfirmation = confirmDir != ConfirmDirection.NONE &&
            confirmBarIdx >= 0 &&
            (lastIdx - confirmBarIdx) <= 3 &&
            ((confirmDir == ConfirmDirection.LONG && lastClose > stopLvl) ||
                (confirmDir == ConfirmDirection.SHORT && lastClose < stopLvl))

        val target1to1 = when (activePathDir) {
            ConfirmDirection.LONG -> creekLevel + rangeHeight
            ConfirmDirection.SHORT -> iceLevel - rangeHeight
            ConfirmDirection.NONE -> lastClose
        }
        val targetFib1618 = when (activePathDir) {
            ConfirmDirection.LONG -> creekLevel + (rangeHeight * 1.618)
            ConfirmDirection.SHORT -> iceLevel - (rangeHeight * 1.618)
            ConfirmDirection.NONE -> lastClose
        }

        return WyckoffRangeState(
            isActive = true,
            bias = bias,
            phase = phase,
            lastEvent = lastEvent,
            creekResistance = creekLevel,
            iceSupport = iceLevel,
            climaxExtreme = if (isSellingClimax) iceLevel else creekLevel,
            shakeoutExtreme = shakeExtreme,
            causeBarsCount = causeBars,
            target1to1Projection = target1to1,
            targetFib1618Projection = targetFib1618,
            hasValidConfirmationTrigger = isFreshConfirmation,
            confirmDirection = if (isFreshConfirmation) confirmDir else ConfirmDirection.NONE,
            confirmBarIdx = if (isFreshConfirmation) confirmBarIdx else -1,
            anchorClimaxTime = bars[climaxIdx].t,
            structuralStopLevel = stopLvl
        )
    }

    private fun extractOrderBlocksFvgAndRtmZones(
        bars: List<BarNode>,
        atrSeries: DoubleArray,
        volSma: DoubleArray,
        fib: FibMatrix,
        wyckoff: WyckoffRangeState,
        pivots: List<PivotNode>
    ): List<SupplyDemandZone> {
        val n = bars.size
        val start = max(2, n - 90)
        val rawZones = mutableListOf<SupplyDemandZone>()
        val lastClose = bars.last().c
        val lastAtr = max(1e-8, atrSeries[n - 1])

        for (i in start until (n - 2)) {
            val bPrev = bars[i - 1]
            val bCur = bars[i]
            val bNext = bars[i + 1]
            val atr = max(1e-8, atrSeries[i])
            val curBody = abs(bCur.c - bCur.o)
            val nextBody = abs(bNext.c - bNext.o)

            val curDisplacementBull = (bCur.c - bCur.o) >= atr * 1.2 && bCur.v >= volSma[i] * 1.1
            val curDisplacementBear = (bCur.o - bCur.c) >= atr * 1.2 && bCur.v >= volSma[i] * 1.1

            if (bNext.l > bPrev.h && (bNext.l - bPrev.h) >= atr * 0.35 && curDisplacementBull) {
                rawZones.add(
                    buildEvaluatedZone(
                        bars = bars,
                        kind = ZoneKind.BULL_FVG,
                        top = bNext.l,
                        bottom = bPrev.h,
                        createdIdx = i,
                        atr = atr,
                        fib = fib,
                        wyckoff = wyckoff
                    )
                )
            }

            if (bNext.h < bPrev.l && (bPrev.l - bNext.h) >= atr * 0.35 && curDisplacementBear) {
                rawZones.add(
                    buildEvaluatedZone(
                        bars = bars,
                        kind = ZoneKind.BEAR_FVG,
                        top = bPrev.l,
                        bottom = bNext.h,
                        createdIdx = i,
                        atr = atr,
                        fib = fib,
                        wyckoff = wyckoff
                    )
                )
            }

            val nextDisplacementBull = (bNext.c - bNext.o) >= atr * 1.3 && bNext.v >= volSma[i + 1] * 1.15
            if (nextDisplacementBull) {
                val isBaseCandle = curBody <= atr * 0.65
                val zKind = when {
                    bPrev.c > bPrev.o && isBaseCandle -> ZoneKind.RTM_DEMAND_RBR
                    bCur.c < bCur.o && bPrev.c < bPrev.o -> ZoneKind.RTM_DEMAND_DBR
                    bCur.c < bCur.o -> ZoneKind.BULL_ORDER_BLOCK
                    else -> null
                }
                if (zKind != null) {
                    rawZones.add(
                        buildEvaluatedZone(
                            bars = bars,
                            kind = zKind,
                            top = max(bCur.o, bCur.c),
                            bottom = bCur.l,
                            createdIdx = i,
                            atr = atr,
                            fib = fib,
                            wyckoff = wyckoff
                        )
                    )
                }
            }

            val nextDisplacementBear = (bNext.o - bNext.c) >= atr * 1.3 && bNext.v >= volSma[i + 1] * 1.15
            if (nextDisplacementBear) {
                val isBaseCandle = curBody <= atr * 0.65
                val zKind = when {
                    bPrev.c < bPrev.o && isBaseCandle -> ZoneKind.RTM_SUPPLY_DBD
                    bCur.c > bCur.o && bPrev.c > bPrev.o -> ZoneKind.RTM_SUPPLY_RBD
                    bCur.c > bCur.o -> ZoneKind.BEAR_ORDER_BLOCK
                    else -> null
                }
                if (zKind != null) {
                    rawZones.add(
                        buildEvaluatedZone(
                            bars = bars,
                            kind = zKind,
                            top = bCur.h,
                            bottom = min(bCur.o, bCur.c),
                            createdIdx = i,
                            atr = atr,
                            fib = fib,
                            wyckoff = wyckoff
                        )
                    )
                }
            }
        }

        val valid = rawZones.filter { !it.isMitigated && it.touchCount <= 2 }
        val bullZones = valid.filter { isBullishZone(it.kind) && it.bottom <= lastClose + lastAtr * 0.5 }
            .sortedByDescending { it.confluenceScore - (abs(lastClose - it.midConsequentEncroachment) / lastAtr) * 4.0 }
            .take(3)
        val bearZones = valid.filter { !isBullishZone(it.kind) && it.top >= lastClose - lastAtr * 0.5 }
            .sortedByDescending { it.confluenceScore - (abs(it.midConsequentEncroachment - lastClose) / lastAtr) * 4.0 }
            .take(3)

        return bullZones + bearZones
    }

    private fun isBullishZone(kind: ZoneKind): Boolean =
        kind == ZoneKind.BULL_FVG || kind == ZoneKind.BULL_ORDER_BLOCK ||
            kind == ZoneKind.RTM_DEMAND_DBR || kind == ZoneKind.RTM_DEMAND_RBR

    private fun buildEvaluatedZone(
        bars: List<BarNode>,
        kind: ZoneKind,
        top: Double,
        bottom: Double,
        createdIdx: Int,
        atr: Double,
        fib: FibMatrix,
        wyckoff: WyckoffRangeState
    ): SupplyDemandZone {
        val mid = (top + bottom) * 0.5
        var touches = 0
        var mitigated = false
        var lastTouchIdx = -1
        val isBullZone = isBullishZone(kind)

        for (k in (createdIdx + 2) until bars.size) {
            val b = bars[k]
            if (isBullZone) {
                if (b.l <= top && b.h >= bottom) {
                    touches++
                    lastTouchIdx = k
                }
                if (b.c < bottom) {
                    mitigated = true
                    break
                }
            } else {
                if (b.h >= bottom && b.l <= top) {
                    touches++
                    lastTouchIdx = k
                }
                if (b.c > top) {
                    mitigated = true
                    break
                }
            }
        }

        val arrivalEndIdx = when {
            lastTouchIdx >= createdIdx + 5 -> lastTouchIdx
            abs(bars.last().c - mid) <= atr * 1.5 && bars.size - 1 >= createdIdx + 5 -> bars.size - 1
            else -> -1
        }
        val hasCompression = if (arrivalEndIdx >= 5) {
            val slice = bars.subList(arrivalEndIdx - 5, arrivalEndIdx)
            val movingTowardZone = if (isBullZone) slice.last().c < slice.first().c else slice.last().c > slice.first().c
            val shrinkingRanges = slice.zipWithNext().all { (a, b) -> (b.h - b.l) <= (a.h - a.l) * 1.25 }
            movingTowardZone && shrinkingRanges
        } else false

        var score = 50.0
        if (touches == 0) score += 20.0
        if (hasCompression) score += 15.0
        if (isBullZone && mid < fib.equilibrium50) score += 10.0
        if (!isBullZone && mid > fib.equilibrium50) score += 10.0
        if (wyckoff.isActive) {
            if (isBullZone && abs(mid - wyckoff.creekResistance) / max(1e-8, wyckoff.creekResistance) <= 0.012) score += 15.0
            if (!isBullZone && abs(mid - wyckoff.iceSupport) / max(1e-8, wyckoff.iceSupport) <= 0.012) score += 15.0
        }

        return SupplyDemandZone(
            kind = kind,
            top = top,
            bottom = bottom,
            midConsequentEncroachment = mid,
            createdIdx = createdIdx,
            createdTime = bars[createdIdx].t,
            touchCount = touches,
            isMitigated = mitigated,
            hasCleanArrivalCompression = hasCompression,
            confluenceScore = min(100.0, score)
        )
    }

    private fun isSignificantIntentBar(
        b: BarNode,
        atr: Double,
        volAvg: Double,
        bullish: Boolean,
        pivots: List<PivotNode>
    ): Boolean {
        val range = b.h - b.l
        if (range < atr * 1.15 || b.v < volAvg * 1.15) return false
        val mid = b.l + range * 0.5
        if (bullish) {
            if (b.c <= b.o || b.c <= mid) return false
            val recentRes = pivots.lastOrNull { it.kind == PivotKind.HIGH }?.price ?: return true
            return b.c >= recentRes * 0.998
        } else {
            if (b.c >= b.o || b.c >= mid) return false
            val recentSup = pivots.lastOrNull { it.kind == PivotKind.LOW }?.price ?: return true
            return b.c <= recentSup * 1.002
        }
    }

    private fun isVsaTestBar(
        bars: List<BarNode>,
        idx: Int,
        atr: Double,
        isNoSupply: Boolean
    ): Boolean {
        if (idx < 2) return false
        val b = bars[idx]
        val b1 = bars[idx - 1]
        val b2 = bars[idx - 2]
        val range = b.h - b.l
        val smallerVolThanPrevTwo = b.v < b1.v && b.v < b2.v
        val narrowRange = range <= atr * 0.85
        if (!smallerVolThanPrevTwo || !narrowRange) return false
        return if (isNoSupply) b.c < b.o else b.c > b.o
    }

    private fun detectMovementReversalOverSignificantBar(
        bars: List<BarNode>,
        atrSeries: DoubleArray,
        volSma: DoubleArray,
        pivots: List<PivotNode>
    ): Pair<Boolean, Boolean> {
        val n = bars.size
        if (n < 15) return Pair(false, false)
        val lastIdx = n - 1
        val lastBar = bars[lastIdx]

        var lastBullSigBar: BarNode? = null
        var lastBearSigBar: BarNode? = null

        for (i in (lastIdx - 1) downTo max(0, lastIdx - 12)) {
            if (lastBullSigBar == null && isSignificantIntentBar(bars[i], atrSeries[i], volSma[i], true, pivots)) {
                lastBullSigBar = bars[i]
            }
            if (lastBearSigBar == null && isSignificantIntentBar(bars[i], atrSeries[i], volSma[i], false, pivots)) {
                lastBearSigBar = bars[i]
            }
        }

        val revBull = lastBearSigBar != null &&
            isSignificantIntentBar(lastBar, atrSeries[lastIdx], volSma[lastIdx], true, pivots) &&
            lastBar.c > lastBearSigBar.h

        val revBear = lastBullSigBar != null &&
            isSignificantIntentBar(lastBar, atrSeries[lastIdx], volSma[lastIdx], false, pivots) &&
            lastBar.c < lastBullSigBar.l

        return Pair(revBull, revBear)
    }
}
