package com.ta.core.synthesis

import com.ta.core.quant.BarNode
import com.ta.core.quant.CoreQuantIndicatorsEngine
import com.ta.core.quant.DivCode
import com.ta.core.quant.QuantSnapshot
import com.ta.core.quant.RegimeCode
import com.ta.core.quant.RegimeThresholds
import com.ta.core.quant.VwapAnchorMode
import com.ta.core.structure.ConfirmDirection
import com.ta.core.structure.LiquidityPoolKind
import com.ta.core.structure.LiquidityPoolNode
import com.ta.core.structure.StructuralPriceActionEngine
import com.ta.core.structure.StructuralSnapshot
import com.ta.core.structure.StructureBreakKind
import com.ta.core.structure.SupplyDemandZone
import com.ta.core.structure.WyckoffBias
import com.ta.core.structure.WyckoffEventCode
import com.ta.core.structure.WyckoffPhase
import com.ta.core.structure.WyckoffRangeState
import com.ta.core.structure.ZoneKind
import com.ta.core.volume.AmtState
import com.ta.core.volume.CvdAbsorptionCode
import com.ta.core.volume.VolumeTradingEngine
import com.ta.core.volume.VolumeTradingSnapshot
import com.tradingassistant.core.risk.MarketType
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.PositionSizingResult
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import com.tradingassistant.core.risk.TradeDirection
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class StyleModule {
    CLASSIC_PA,
    SMC_ICT,
    RTM_SUPPLY_DEMAND,
    WYCKOFF_VSA,
    FIBONACCI_MATRIX,
    VOLUME_PROFILE_VWAP,
    VOLUME_TRADING_ORDERFLOW,
    TREND_EMA_ADX,
    OSCILLATOR_DIVERGENCE
}

enum class SelectionMode {
    USER_MANUAL,
    SUGGESTED_COMBINATION
}

data class StrategyConfigRequest(
    val symbol: String,
    val marketType: MarketType,
    val executionTimeframe: String,
    val higherTimeframe: String,
    val selectionMode: SelectionMode,
    val userSelectedModules: Set<StyleModule>,
    val minConfluenceScoreForSignal: Double = 72.0,
    val minScoreMargin: Double = 18.0,
    val minNetRrRatio: Double = 1.6,
    val maxStopAtrMultiple: Double = 3.0,
    val maxEntryDistanceAtr: Double = 0.5,
    val signalValidityBars: Int = 5,
    val vwapAnchorMode: VwapAnchorMode = VwapAnchorMode.UTC_DAILY,
    val regimeThresholds: RegimeThresholds = RegimeThresholds()
)

data class ScenarioPath(
    val direction: TradeDirection,
    val relativeScenarioScore: Double,
    val triggerConditionCode: String,
    val targetZoneTop: Double,
    val targetZoneBottom: Double,
    val invalidationLevel: Double
)

data class AssistantModeOutput(
    val timestamp: Long,
    val symbol: String,
    val regime: RegimeCode,
    val activeModulesUsed: Set<StyleModule>,
    val discardedModules: Set<StyleModule>,
    val selectionRationaleCodes: List<String>,
    val htfBiasDirection: Int,
    val ltfStructureDirection: Int,
    val wyckoffPhase: WyckoffPhase,
    val wyckoffBias: WyckoffBias,
    val wyckoffLastEvent: WyckoffEventCode,
    val wyckoffRangeState: WyckoffRangeState,
    val volumeSnapshot: VolumeTradingSnapshot?,
    val relativeBullScore: Double,
    val relativeBearScore: Double,
    val keyDemandZones: List<SupplyDemandZone>,
    val keySupplyZones: List<SupplyDemandZone>,
    val magnetLiquidityPools: List<LiquidityPoolNode>,
    val equilibriumPrice: Double,
    val vwapLevel: Double,
    val pocLevel: Double,
    val bullishScenario: ScenarioPath,
    val bearishScenario: ScenarioPath
)

data class CompanionSignalOutput(
    val isSignalActive: Boolean,
    val noSignalReasonCode: String?,
    val setupId: String,
    val validUntilBarIndex: Int,
    val isLimitOrderRetest: Boolean,
    val suggestedLimitEntryPrice: Double?,
    val symbol: String,
    val marketType: MarketType,
    val direction: TradeDirection?,
    val timeframe: String,
    val strategyComboId: String,
    val activeModules: Set<StyleModule>,
    val confluenceScore: Double,
    val entryZoneTop: Double,
    val entryZoneBottom: Double,
    val optimalEntryPrice: Double,
    val stopLossPrice: Double,
    val takeProfit1Price: Double,
    val takeProfit2Price: Double,
    val takeProfit3RunnerPrice: Double?,
    val invalidationConditionCode: String,
    val reasonCodes: List<String>,
    val riskPositionSizing: PositionSizingResult?
)

data class FullSynthesisReport(
    val assistantReport: AssistantModeOutput,
    val companionSignal: CompanionSignalOutput
)

data class SynthesisExecutionResult(
    val statusCode: String,
    val report: FullSynthesisReport?
)

object StrategySynthesizerEngine {

    fun executeSynthesis(
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        config: StrategyConfigRequest,
        riskTemplate: PositionSizingInput,
        previousLtfWyckoff: WyckoffRangeState? = null,
        activeSetupIds: Set<String> = emptySet()
    ): FullSynthesisReport? {
        return executeSynthesisResult(
            ltfBars = ltfBars,
            htfBars = htfBars,
            config = config,
            riskTemplate = riskTemplate,
            previousLtfWyckoff = previousLtfWyckoff,
            activeSetupIds = activeSetupIds
        ).report
    }

    fun executeSynthesisResult(
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        config: StrategyConfigRequest,
        riskTemplate: PositionSizingInput,
        previousLtfWyckoff: WyckoffRangeState? = null,
        activeSetupIds: Set<String> = emptySet()
    ): SynthesisExecutionResult {
        val ltfQuantRes = CoreQuantIndicatorsEngine.computeSnapshotResult(
            rawBars = ltfBars,
            vwapAnchorMode = config.vwapAnchorMode,
            regimeThresholds = config.regimeThresholds
        )
        val htfQuantRes = CoreQuantIndicatorsEngine.computeSnapshotResult(
            rawBars = htfBars,
            vwapAnchorMode = config.vwapAnchorMode,
            regimeThresholds = config.regimeThresholds
        )
        val ltfStructRes = StructuralPriceActionEngine.analyzeStructureResult(
            rawBars = ltfBars,
            previousRangeState = previousLtfWyckoff
        )
        val htfStructRes = StructuralPriceActionEngine.analyzeStructureResult(rawBars = htfBars)

        val ltfQuant = ltfQuantRes.snapshot ?: return SynthesisExecutionResult("INSUFFICIENT_HISTORY", null)
        val htfQuant = htfQuantRes.snapshot ?: return SynthesisExecutionResult("INSUFFICIENT_HISTORY", null)
        val ltfStruct = ltfStructRes.snapshot ?: return SynthesisExecutionResult("INSUFFICIENT_HISTORY", null)
        val htfStruct = htfStructRes.snapshot ?: return SynthesisExecutionResult("INSUFFICIENT_HISTORY", null)
        val ltfVolume = VolumeTradingEngine.analyzeVolumeOrderflow(ltfBars)

        val (activeModules, discardedModules, rationaleCodes) = resolveOrthogonalModules(
            mode = config.selectionMode,
            requested = config.userSelectedModules,
            ltfRegime = ltfQuant.regime,
            wyckoff = ltfStruct.wyckoff
        )

        val htfBias = resolveMacroBias(htfQuant, htfStruct)
        val (bullScore, bearScore, bullReasons, bearReasons) = computeOrthogonalConfluence(
            ltfQuant = ltfQuant,
            ltfStruct = ltfStruct,
            ltfVolume = ltfVolume,
            htfBias = htfBias,
            activeModules = activeModules
        )

        val totalPower = max(1.0, bullScore + bearScore)
        val relBull = (bullScore / totalPower) * 100.0
        val relBear = (bearScore / totalPower) * 100.0

        val demandZones = ltfStruct.activeZones.filter {
            it.kind == ZoneKind.BULL_ORDER_BLOCK || it.kind == ZoneKind.BULL_FVG ||
                it.kind == ZoneKind.RTM_DEMAND_DBR || it.kind == ZoneKind.RTM_DEMAND_RBR
        }
        val supplyZones = ltfStruct.activeZones.filter {
            it.kind == ZoneKind.BEAR_ORDER_BLOCK || it.kind == ZoneKind.BEAR_FVG ||
                it.kind == ZoneKind.RTM_SUPPLY_RBD || it.kind == ZoneKind.RTM_SUPPLY_DBD
        }
        val unSweptMagnets = ltfStruct.liquidityPools.filter { !it.isSwept }

        val (bullScenario, bearScenario) = buildScenarios(
            ltfQuant = ltfQuant,
            ltfStruct = ltfStruct,
            ltfVolume = ltfVolume,
            demandZones = demandZones,
            supplyZones = supplyZones,
            magnets = unSweptMagnets,
            bullScore = bullScore,
            bearScore = bearScore
        )

        val assistantOutput = AssistantModeOutput(
            timestamp = ltfQuant.timestamp,
            symbol = config.symbol,
            regime = ltfQuant.regime,
            activeModulesUsed = activeModules,
            discardedModules = discardedModules,
            selectionRationaleCodes = rationaleCodes,
            htfBiasDirection = htfBias,
            ltfStructureDirection = ltfStruct.trendDirection,
            wyckoffPhase = ltfStruct.wyckoff.phase,
            wyckoffBias = ltfStruct.wyckoff.bias,
            wyckoffLastEvent = ltfStruct.wyckoff.lastEvent,
            wyckoffRangeState = ltfStruct.wyckoff,
            volumeSnapshot = ltfVolume,
            relativeBullScore = round1(relBull),
            relativeBearScore = round1(relBear),
            keyDemandZones = demandZones,
            keySupplyZones = supplyZones,
            magnetLiquidityPools = unSweptMagnets,
            equilibriumPrice = ltfStruct.fib.equilibrium50,
            vwapLevel = ltfQuant.vwap.vwap,
            pocLevel = ltfQuant.volProfile.poc,
            bullishScenario = bullScenario,
            bearishScenario = bearScenario
        )

        val companionOutput = evaluateCompanionSignal(
            config = config,
            ltfQuant = ltfQuant,
            ltfStruct = ltfStruct,
            ltfVolume = ltfVolume,
            htfBias = htfBias,
            activeModules = activeModules,
            bullScore = bullScore,
            bearScore = bearScore,
            bullReasons = bullReasons,
            bearReasons = bearReasons,
            demandZones = demandZones,
            supplyZones = supplyZones,
            magnets = unSweptMagnets,
            riskTemplate = riskTemplate,
            activeSetupIds = activeSetupIds
        )

        return SynthesisExecutionResult(
            statusCode = "OK",
            report = FullSynthesisReport(
                assistantReport = assistantOutput,
                companionSignal = companionOutput
            )
        )
    }

    private fun resolveOrthogonalModules(
        mode: SelectionMode,
        requested: Set<StyleModule>,
        ltfRegime: RegimeCode,
        wyckoff: WyckoffRangeState
    ): Triple<Set<StyleModule>, Set<StyleModule>, List<String>> {
        val reasons = mutableListOf<String>()
        if (mode == SelectionMode.SUGGESTED_COMBINATION) {
            val selected = mutableSetOf<StyleModule>()
            when (ltfRegime) {
                RegimeCode.TREND_BULL_STRONG, RegimeCode.TREND_BEAR_STRONG -> {
                    selected.add(StyleModule.SMC_ICT)
                    selected.add(StyleModule.RTM_SUPPLY_DEMAND)
                    selected.add(StyleModule.FIBONACCI_MATRIX)
                    selected.add(StyleModule.TREND_EMA_ADX)
                    selected.add(StyleModule.VOLUME_PROFILE_VWAP)
                    selected.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
                    reasons.add("REGIME_STRONG_TREND_PULLBACK_WITH_VOLUME_CONFIRM")
                    reasons.add("QUARANTINED_COUNTER_TREND_OSCILLATORS")
                }
                RegimeCode.RANGE_MEAN_REVERT -> {
                    selected.add(StyleModule.WYCKOFF_VSA)
                    selected.add(StyleModule.SMC_ICT)
                    selected.add(StyleModule.VOLUME_PROFILE_VWAP)
                    selected.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
                    selected.add(StyleModule.OSCILLATOR_DIVERGENCE)
                    selected.add(StyleModule.FIBONACCI_MATRIX)
                    reasons.add("REGIME_RANGE_WYCKOFF_AMT_ABSORPTION_SYNTHESIS")
                    reasons.add("QUARANTINED_LAGGING_EMA_CROSSOVERS")
                }
                RegimeCode.VOL_SQUEEZE_BREAKOUT_PREP -> {
                    selected.add(StyleModule.WYCKOFF_VSA)
                    selected.add(StyleModule.CLASSIC_PA)
                    selected.add(StyleModule.VOLUME_PROFILE_VWAP)
                    selected.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
                    selected.add(StyleModule.FIBONACCI_MATRIX)
                    reasons.add("REGIME_VOL_SQUEEZE_PHASE_D_RVOL_BREAKOUT_PREP")
                }
                RegimeCode.VOL_EXTREME_EXPANSION -> {
                    selected.add(StyleModule.WYCKOFF_VSA)
                    selected.add(StyleModule.VOLUME_PROFILE_VWAP)
                    selected.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
                    selected.add(StyleModule.FIBONACCI_MATRIX)
                    reasons.add("REGIME_CLIMAX_EXTREME_VOL_CAUTION")
                }
                else -> {
                    selected.add(StyleModule.WYCKOFF_VSA)
                    selected.add(StyleModule.SMC_ICT)
                    selected.add(StyleModule.FIBONACCI_MATRIX)
                    selected.add(StyleModule.VOLUME_PROFILE_VWAP)
                    selected.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
                    reasons.add("REGIME_TRANSITIONAL_CONSERVATIVE_STACK")
                }
            }
            val discarded = StyleModule.entries.toSet() - selected
            return Triple(selected, discarded, reasons)
        }

        val active = requested.toMutableSet()
        val discarded = mutableSetOf<StyleModule>()

        if ((ltfRegime == RegimeCode.TREND_BULL_STRONG || ltfRegime == RegimeCode.TREND_BEAR_STRONG) &&
            active.contains(StyleModule.OSCILLATOR_DIVERGENCE) && active.size > 1
        ) {
            active.remove(StyleModule.OSCILLATOR_DIVERGENCE)
            discarded.add(StyleModule.OSCILLATOR_DIVERGENCE)
            reasons.add("REMOVED_COUNTER_TREND_OSCILLATOR_IN_STRONG_TREND")
        }

        if (ltfRegime == RegimeCode.RANGE_MEAN_REVERT &&
            active.contains(StyleModule.TREND_EMA_ADX) &&
            !(wyckoff.isActive && (wyckoff.phase == WyckoffPhase.PHASE_D_TREND_IN_RANGE || wyckoff.phase == WyckoffPhase.PHASE_E_TREND_OUT_RANGE))
        ) {
            active.remove(StyleModule.TREND_EMA_ADX)
            discarded.add(StyleModule.TREND_EMA_ADX)
            reasons.add("REMOVED_TREND_EMA_IN_EQUILIBRIUM_RANGE")
        }

        if (active.isEmpty()) {
            active.add(StyleModule.WYCKOFF_VSA)
            active.add(StyleModule.SMC_ICT)
            active.add(StyleModule.VOLUME_TRADING_ORDERFLOW)
            active.add(StyleModule.FIBONACCI_MATRIX)
        }

        return Triple(active, discarded, reasons)
    }

    private fun resolveMacroBias(htfQuant: QuantSnapshot, htfStruct: StructuralSnapshot): Int {
        var score = 0
        if (htfStruct.trendDirection == 1) score += 2
        if (htfStruct.trendDirection == -1) score -= 2

        if (htfStruct.wyckoff.isActive) {
            when (htfStruct.wyckoff.bias) {
                WyckoffBias.ACCUMULATION, WyckoffBias.REACCUMULATION -> score += 2
                WyckoffBias.DISTRIBUTION, WyckoffBias.REDISTRIBUTION -> score -= 2
                else -> {}
            }
        }

        if (htfQuant.closePrice > htfQuant.emaMid && htfQuant.emaMid > htfQuant.emaSlow) score += 1
        if (htfQuant.closePrice < htfQuant.emaMid && htfQuant.emaMid < htfQuant.emaSlow) score -= 1

        return when {
            score >= 2 -> 1
            score <= -2 -> -1
            else -> 0
        }
    }

    private fun computeOrthogonalConfluence(
        ltfQuant: QuantSnapshot,
        ltfStruct: StructuralSnapshot,
        ltfVolume: VolumeTradingSnapshot?,
        htfBias: Int,
        activeModules: Set<StyleModule>
    ): OrthogonalScoreResult {
        val bullReasons = mutableListOf<String>()
        val bearReasons = mutableListOf<String>()
        val strongBull = ltfQuant.regime == RegimeCode.TREND_BULL_STRONG
        val strongBear = ltfQuant.regime == RegimeCode.TREND_BEAR_STRONG

        var dim1Bull = 0.0
        var dim1Bear = 0.0
        if (htfBias == 1) {
            dim1Bull += 12.0
            bullReasons.add("HTF_BULLISH_CONTEXT")
        } else if (htfBias == -1) {
            dim1Bear += 12.0
            bearReasons.add("HTF_BEARISH_CONTEXT")
        }

        if (activeModules.contains(StyleModule.WYCKOFF_VSA) && ltfStruct.wyckoff.isActive) {
            val w = ltfStruct.wyckoff
            if (w.bias == WyckoffBias.ACCUMULATION || w.bias == WyckoffBias.REACCUMULATION) {
                if (w.phase == WyckoffPhase.PHASE_C_TESTING || w.phase == WyckoffPhase.PHASE_D_TREND_IN_RANGE || w.phase == WyckoffPhase.PHASE_E_TREND_OUT_RANGE) {
                    dim1Bull = max(dim1Bull, 20.0)
                    bullReasons.add("WYCKOFF_${w.bias.name}_${w.phase.name}")
                }
            } else if (w.bias == WyckoffBias.DISTRIBUTION || w.bias == WyckoffBias.REDISTRIBUTION) {
                if (w.phase == WyckoffPhase.PHASE_C_TESTING || w.phase == WyckoffPhase.PHASE_D_TREND_IN_RANGE || w.phase == WyckoffPhase.PHASE_E_TREND_OUT_RANGE) {
                    dim1Bear = max(dim1Bear, 20.0)
                    bearReasons.add("WYCKOFF_${w.bias.name}_${w.phase.name}")
                }
            }
        }

        if (activeModules.contains(StyleModule.TREND_EMA_ADX)) {
            if (strongBull) {
                dim1Bull = max(dim1Bull, 16.0)
                bullReasons.add("STRONG_BULL_TREND_EMA_ADX")
            } else if (strongBear) {
                dim1Bear = max(dim1Bear, 16.0)
                bearReasons.add("STRONG_BEAR_TREND_EMA_ADX")
            }
        }

        var dim2Bull = 0.0
        var dim2Bear = 0.0
        val c = ltfQuant.closePrice
        val atr = max(1e-8, ltfQuant.atr14)
        val fibSpan = max(1e-8, ltfStruct.fib.anchorHigh - ltfStruct.fib.anchorLow)
        val distFromEqRatio = abs(c - ltfStruct.fib.equilibrium50) / fibSpan

        if (activeModules.contains(StyleModule.FIBONACCI_MATRIX) && distFromEqRatio >= 0.08) {
            if (ltfStruct.fib.isCurrentPriceInDiscount && !strongBear) {
                dim2Bull = max(dim2Bull, 12.0)
                bullReasons.add("FIB_DISCOUNT_VALUATION")
                if (ltfStruct.fib.isBullishSwing && ltfStruct.fib.isCurrentPriceInOteZone) {
                    dim2Bull = max(dim2Bull, 18.0)
                    bullReasons.add("FIB_BULLISH_OTE_618_786")
                }
            } else if (!ltfStruct.fib.isCurrentPriceInDiscount && !strongBull) {
                dim2Bear = max(dim2Bear, 12.0)
                bearReasons.add("FIB_PREMIUM_VALUATION")
                if (!ltfStruct.fib.isBullishSwing && ltfStruct.fib.isCurrentPriceInOteZone) {
                    dim2Bear = max(dim2Bear, 18.0)
                    bearReasons.add("FIB_BEARISH_OTE_618_786")
                }
            }
        }

        if (activeModules.contains(StyleModule.VOLUME_PROFILE_VWAP) || activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW)) {
            val vp = ltfQuant.volProfile
            val vw = ltfQuant.vwap
            if (!strongBear && (c <= vp.valPrice * 1.004 || vw.zScore <= -1.2)) {
                dim2Bull = max(dim2Bull, 16.0)
                bullReasons.add("INSTITUTIONAL_VALUE_LOW_VWAP_VAL")
            }
            if (!strongBull && (c >= vp.vah * 0.996 || vw.zScore >= 1.2)) {
                dim2Bear = max(dim2Bear, 16.0)
                bearReasons.add("INSTITUTIONAL_VALUE_HIGH_VWAP_VAH")
            }
            if (ltfVolume != null && activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW)) {
                if (ltfVolume.amtState == AmtState.AMT_FAILED_AUCTION_BULL && !strongBear) {
                    dim2Bull = max(dim2Bull, 18.0)
                    bullReasons.add("AMT_FAILED_AUCTION_RETURN_INSIDE_VAL")
                } else if (ltfVolume.amtState == AmtState.AMT_FAILED_AUCTION_BEAR && !strongBull) {
                    dim2Bear = max(dim2Bear, 18.0)
                    bearReasons.add("AMT_FAILED_AUCTION_RETURN_INSIDE_VAH")
                } else if (ltfVolume.amtState == AmtState.AMT_IMBALANCE_BULL_ACCEPTANCE) {
                    dim2Bull = max(dim2Bull, 17.0)
                    bullReasons.add("AMT_IMBALANCE_BULL_ACCEPTANCE")
                } else if (ltfVolume.amtState == AmtState.AMT_IMBALANCE_BEAR_ACCEPTANCE) {
                    dim2Bear = max(dim2Bear, 17.0)
                    bearReasons.add("AMT_IMBALANCE_BEAR_ACCEPTANCE")
                }
            }
        }

        var dim3Bull = 0.0
        var dim3Bear = 0.0

        if (activeModules.contains(StyleModule.SMC_ICT) || activeModules.contains(StyleModule.RTM_SUPPLY_DEMAND) || activeModules.contains(StyleModule.CLASSIC_PA)) {
            val matchingBullZone = ltfStruct.activeZones.firstOrNull { z ->
                (z.kind == ZoneKind.BULL_ORDER_BLOCK || z.kind == ZoneKind.BULL_FVG || z.kind == ZoneKind.RTM_DEMAND_DBR || z.kind == ZoneKind.RTM_DEMAND_RBR) &&
                    c >= (z.bottom - atr * 0.35) && c <= (z.top + atr * 0.45)
            }
            if (matchingBullZone != null) {
                dim3Bull = max(dim3Bull, if (matchingBullZone.hasCleanArrivalCompression) 22.0 else 17.0)
                bullReasons.add("AT_UNMITIGATED_${matchingBullZone.kind.name}")
                if (matchingBullZone.hasCleanArrivalCompression) bullReasons.add("CLEAN_COMPRESSION_ARRIVAL")
            }

            val matchingBearZone = ltfStruct.activeZones.firstOrNull { z ->
                (z.kind == ZoneKind.BEAR_ORDER_BLOCK || z.kind == ZoneKind.BEAR_FVG || z.kind == ZoneKind.RTM_SUPPLY_RBD || z.kind == ZoneKind.RTM_SUPPLY_DBD) &&
                    c <= (z.top + atr * 0.35) && c >= (z.bottom - atr * 0.45)
            }
            if (matchingBearZone != null) {
                dim3Bear = max(dim3Bear, if (matchingBearZone.hasCleanArrivalCompression) 22.0 else 17.0)
                bearReasons.add("AT_UNMITIGATED_${matchingBearZone.kind.name}")
                if (matchingBearZone.hasCleanArrivalCompression) bearReasons.add("CLEAN_COMPRESSION_ARRIVAL")
            }
        }

        if (activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW) && ltfVolume != null) {
            val bullVi = ltfVolume.activeVolumeImbalances.firstOrNull { it.isBullish && c in (it.bottom - atr * 0.3)..(it.top + atr * 0.3) }
            if (bullVi != null) {
                dim3Bull = max(dim3Bull, 18.0)
                bullReasons.add("AT_VOLUME_IMBALANCE_GAP")
            }
            val bearVi = ltfVolume.activeVolumeImbalances.firstOrNull { !it.isBullish && c in (it.bottom - atr * 0.3)..(it.top + atr * 0.3) }
            if (bearVi != null) {
                dim3Bear = max(dim3Bear, 18.0)
                bearReasons.add("AT_VOLUME_IMBALANCE_GAP")
            }
        }

        var dim4Bull = 0.0
        var dim4Bear = 0.0
        val allowSweep = activeModules.contains(StyleModule.SMC_ICT) || activeModules.contains(StyleModule.WYCKOFF_VSA)
        val sweep = ltfStruct.recentSweepPool
        if (allowSweep && sweep != null && sweep.sweepRejectedCloseInside) {
            if (sweep.kind == LiquidityPoolKind.SELL_SIDE_EQL || sweep.kind == LiquidityPoolKind.MAJOR_SWING_LOW_SSL) {
                dim4Bull = max(dim4Bull, 22.0)
                bullReasons.add("SELL_SIDE_LIQUIDITY_SWEEP_REJECTED")
            } else if (sweep.kind == LiquidityPoolKind.BUY_SIDE_EQH || sweep.kind == LiquidityPoolKind.MAJOR_SWING_HIGH_BSL) {
                dim4Bear = max(dim4Bear, 22.0)
                bearReasons.add("BUY_SIDE_LIQUIDITY_SWEEP_REJECTED")
            }
        }

        if (activeModules.contains(StyleModule.WYCKOFF_VSA) && ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.hasValidConfirmationTrigger) {
            if (ltfStruct.wyckoff.confirmDirection == ConfirmDirection.LONG) {
                dim4Bull = max(dim4Bull, 24.0)
                bullReasons.add("WYCKOFF_CONFIRMED_${ltfStruct.wyckoff.lastEvent.name}")
            } else if (ltfStruct.wyckoff.confirmDirection == ConfirmDirection.SHORT) {
                dim4Bear = max(dim4Bear, 24.0)
                bearReasons.add("WYCKOFF_CONFIRMED_${ltfStruct.wyckoff.lastEvent.name}")
            }
        }

        if (activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW) && ltfVolume != null) {
            if (ltfVolume.cvdAbsorption == CvdAbsorptionCode.BULL_ABSORPTION_DIVERGENCE && !strongBear) {
                dim4Bull = max(dim4Bull, 20.0)
                bullReasons.add("CVD_BULL_ABSORPTION_DIVERGENCE")
            } else if (ltfVolume.cvdAbsorption == CvdAbsorptionCode.BEAR_ABSORPTION_DIVERGENCE && !strongBull) {
                dim4Bear = max(dim4Bear, 20.0)
                bearReasons.add("CVD_BEAR_ABSORPTION_DIVERGENCE")
            }
        }

        var dim5Bull = 0.0
        var dim5Bear = 0.0
        val allowStructureTrigger = activeModules.contains(StyleModule.SMC_ICT) || activeModules.contains(StyleModule.CLASSIC_PA)
        val allowVsaTrigger = activeModules.contains(StyleModule.WYCKOFF_VSA) || activeModules.contains(StyleModule.CLASSIC_PA)

        if (allowStructureTrigger) {
            if (ltfStruct.lastBreakKind == StructureBreakKind.MSS_BULL_DISPLACEMENT || ltfStruct.lastBreakKind == StructureBreakKind.CHOCH_BULL) {
                dim5Bull = max(dim5Bull, 16.0)
                bullReasons.add("STRUCTURAL_${ltfStruct.lastBreakKind.name}")
            } else if (ltfStruct.lastBreakKind == StructureBreakKind.MSS_BEAR_DISPLACEMENT || ltfStruct.lastBreakKind == StructureBreakKind.CHOCH_BEAR) {
                dim5Bear = max(dim5Bear, 16.0)
                bearReasons.add("STRUCTURAL_${ltfStruct.lastBreakKind.name}")
            }
        }

        if (allowVsaTrigger) {
            if (ltfStruct.isSignificantBullBar || ltfStruct.isMovementReversalBull) {
                dim5Bull = max(dim5Bull, 18.0)
                bullReasons.add(if (ltfStruct.isMovementReversalBull) "WYCKOFF_BULL_MOVEMENT_REVERSAL_BAR" else "SIGNIFICANT_SOS_INTENT_BAR")
            }
            if (ltfStruct.isSignificantBearBar || ltfStruct.isMovementReversalBear) {
                dim5Bear = max(dim5Bear, 18.0)
                bearReasons.add(if (ltfStruct.isMovementReversalBear) "WYCKOFF_BEAR_MOVEMENT_REVERSAL_BAR" else "SIGNIFICANT_SOW_INTENT_BAR")
            }

            if (ltfStruct.isNoSupplyBar && (dim1Bull > 0 || dim3Bull > 0 || dim4Bull > 0)) {
                dim5Bull = max(dim5Bull, 15.0)
                bullReasons.add("VSA_NO_SUPPLY_TEST_BAR")
            }
            if (ltfStruct.isNoDemandBar && (dim1Bear > 0 || dim3Bear > 0 || dim4Bear > 0)) {
                dim5Bear = max(dim5Bear, 15.0)
                bearReasons.add("VSA_NO_DEMAND_TEST_BAR")
            }

            val lastWave = ltfStruct.waves.lastOrNull()
            if (lastWave != null && lastWave.effortResultHarmony) {
                if (lastWave.isBullish && dim5Bull > 0) {
                    dim5Bull = min(20.0, dim5Bull + 3.0)
                    bullReasons.add("WEIS_WAVE_EFFORT_RESULT_HARMONY")
                } else if (!lastWave.isBullish && dim5Bear > 0) {
                    dim5Bear = min(20.0, dim5Bear + 3.0)
                    bearReasons.add("WEIS_WAVE_EFFORT_RESULT_HARMONY")
                }
            }
        }

        if (activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW) && ltfVolume != null) {
            if (ltfVolume.isHighRvolBullBreakout) {
                dim5Bull = max(dim5Bull, 18.0)
                bullReasons.add("HIGH_RVOL_POSITIVE_DELTA_EXPANSION")
            }
            if (ltfVolume.isHighRvolBearBreakout) {
                dim5Bear = max(dim5Bear, 18.0)
                bearReasons.add("HIGH_RVOL_NEGATIVE_DELTA_EXPANSION")
            }
        }

        if (activeModules.contains(StyleModule.OSCILLATOR_DIVERGENCE)) {
            if (ltfQuant.rsiDiv == DivCode.BULL_REGULAR || ltfQuant.macdDiv == DivCode.BULL_REGULAR) {
                if (!strongBear) {
                    dim5Bull = max(dim5Bull, 14.0)
                    bullReasons.add("REGULAR_BULLISH_DIVERGENCE")
                }
            } else if (ltfQuant.rsiDiv == DivCode.BULL_HIDDEN && strongBull) {
                dim5Bull = max(dim5Bull, 15.0)
                bullReasons.add("HIDDEN_BULLISH_CONTINUATION_DIVERGENCE")
            }

            if (ltfQuant.rsiDiv == DivCode.BEAR_REGULAR || ltfQuant.macdDiv == DivCode.BEAR_REGULAR) {
                if (!strongBull) {
                    dim5Bear = max(dim5Bear, 14.0)
                    bearReasons.add("REGULAR_BEARISH_DIVERGENCE")
                }
            } else if (ltfQuant.rsiDiv == DivCode.BEAR_HIDDEN && strongBear) {
                dim5Bear = max(dim5Bear, 15.0)
                bearReasons.add("HIDDEN_BEARISH_CONTINUATION_DIVERGENCE")
            }
        }

        val totalBull = (dim1Bull + dim2Bull + dim3Bull + dim4Bull + dim5Bull).coerceIn(0.0, 100.0)
        val totalBear = (dim1Bear + dim2Bear + dim3Bear + dim4Bear + dim5Bear).coerceIn(0.0, 100.0)

        return OrthogonalScoreResult(
            bullScore = totalBull,
            bearScore = totalBear,
            bullReasons = bullReasons,
            bearReasons = bearReasons
        )
    }

    private fun buildScenarios(
        ltfQuant: QuantSnapshot,
        ltfStruct: StructuralSnapshot,
        ltfVolume: VolumeTradingSnapshot?,
        demandZones: List<SupplyDemandZone>,
        supplyZones: List<SupplyDemandZone>,
        magnets: List<LiquidityPoolNode>,
        bullScore: Double,
        bearScore: Double
    ): Pair<ScenarioPath, ScenarioPath> {
        val c = ltfQuant.closePrice
        val atr = ltfQuant.atr14

        val upperNpoc = ltfVolume?.nakedPocs?.filter { it.pocPrice > c }?.minByOrNull { it.pocPrice }?.pocPrice
        val lowerNpoc = ltfVolume?.nakedPocs?.filter { it.pocPrice < c }?.maxByOrNull { it.pocPrice }?.pocPrice

        val upperMagnet = listOfNotNull(
            magnets.filter { it.level > c }.minByOrNull { it.level }?.level,
            supplyZones.filter { it.bottom > c }.minByOrNull { it.bottom }?.bottom,
            upperNpoc
        ).minOrNull() ?: max(ltfStruct.fib.anchorHigh, c + atr * 3.0)

        val lowerMagnet = listOfNotNull(
            magnets.filter { it.level < c }.maxByOrNull { it.level }?.level,
            demandZones.filter { it.top < c }.maxByOrNull { it.top }?.top,
            lowerNpoc
        ).maxOrNull() ?: min(ltfStruct.fib.anchorLow, c - atr * 3.0)

        val bullInvalidation = demandZones.filter { it.bottom < c }.maxByOrNull { it.bottom }?.bottom
            ?: (if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.structuralStopLevel < c) ltfStruct.wyckoff.structuralStopLevel else ltfStruct.fib.anchorLow - atr * 0.5)

        val bearInvalidation = supplyZones.filter { it.top > c }.minByOrNull { it.top }?.top
            ?: (if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.structuralStopLevel > c) ltfStruct.wyckoff.structuralStopLevel else ltfStruct.fib.anchorHigh + atr * 0.5)

        val total = max(1.0, bullScore + bearScore)
        val bullRel = round1((bullScore / total) * 100.0)
        val bearRel = round1((bearScore / total) * 100.0)

        val bullPath = ScenarioPath(
            direction = TradeDirection.LONG,
            relativeScenarioScore = bullRel,
            triggerConditionCode = "HOLD_ABOVE_DEMAND_AND_PRINT_SOS_OR_MSS",
            targetZoneTop = upperMagnet + atr * 0.25,
            targetZoneBottom = upperMagnet - atr * 0.25,
            invalidationLevel = bullInvalidation
        )

        val bearPath = ScenarioPath(
            direction = TradeDirection.SHORT,
            relativeScenarioScore = bearRel,
            triggerConditionCode = "REJECT_SUPPLY_AND_PRINT_SOW_OR_MSS",
            targetZoneTop = lowerMagnet + atr * 0.25,
            targetZoneBottom = lowerMagnet - atr * 0.25,
            invalidationLevel = bearInvalidation
        )

        return Pair(bullPath, bearPath)
    }

    private fun evaluateCompanionSignal(
        config: StrategyConfigRequest,
        ltfQuant: QuantSnapshot,
        ltfStruct: StructuralSnapshot,
        ltfVolume: VolumeTradingSnapshot?,
        htfBias: Int,
        activeModules: Set<StyleModule>,
        bullScore: Double,
        bearScore: Double,
        bullReasons: List<String>,
        bearReasons: List<String>,
        demandZones: List<SupplyDemandZone>,
        supplyZones: List<SupplyDemandZone>,
        magnets: List<LiquidityPoolNode>,
        riskTemplate: PositionSizingInput,
        activeSetupIds: Set<String>
    ): CompanionSignalOutput {
        val comboId = activeModules.map { it.name }.sorted().joinToString("+")

        if (abs(bullScore - bearScore) < config.minScoreMargin) {
            return rejectedCompanion(config, comboId, activeModules, max(bullScore, bearScore), "CONFLICTING_FORCES_EQUILIBRIUM")
        }

        val isLong = bullScore > bearScore
        val winningScore = if (isLong) bullScore else bearScore
        val winningReasons = if (isLong) bullReasons else bearReasons

        if (winningScore < config.minConfluenceScoreForSignal) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "CONFLUENCE_BELOW_THRESHOLD")
        }

        if (!isLong && config.marketType == MarketType.SPOT) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "SHORT_NOT_SUPPORTED_IN_SPOT")
        }

        val sweep = ltfStruct.recentSweepPool
        val hasBullSweep = sweep != null && sweep.sweepRejectedCloseInside &&
            (sweep.kind == LiquidityPoolKind.SELL_SIDE_EQL || sweep.kind == LiquidityPoolKind.MAJOR_SWING_LOW_SSL)
        val hasBearSweep = sweep != null && sweep.sweepRejectedCloseInside &&
            (sweep.kind == LiquidityPoolKind.BUY_SIDE_EQH || sweep.kind == LiquidityPoolKind.MAJOR_SWING_HIGH_BSL)

        if (isLong && ltfQuant.regime == RegimeCode.TREND_BEAR_STRONG) {
            val allowedReversal = ltfStruct.lastBreakKind == StructureBreakKind.MSS_BULL_DISPLACEMENT && hasBullSweep
            if (!allowedReversal) {
                return rejectedCompanion(config, comboId, activeModules, winningScore, "COUNTER_TO_LTF_STRONG_BEAR_TREND")
            }
        }
        if (!isLong && ltfQuant.regime == RegimeCode.TREND_BULL_STRONG) {
            val allowedReversal = ltfStruct.lastBreakKind == StructureBreakKind.MSS_BEAR_DISPLACEMENT && hasBearSweep
            if (!allowedReversal) {
                return rejectedCompanion(config, comboId, activeModules, winningScore, "COUNTER_TO_LTF_STRONG_BULL_TREND")
            }
        }

        val validWyckoffPhaseD = ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.phase == WyckoffPhase.PHASE_D_TREND_IN_RANGE
        if (isLong && htfBias == -1 && !(validWyckoffPhaseD && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.LONG)) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "COUNTER_TO_HTF_BEARISH_BIAS")
        }
        if (!isLong && htfBias == 1 && !(validWyckoffPhaseD && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.SHORT)) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "COUNTER_TO_HTF_BULLISH_BIAS")
        }

        val directionalWyckoffConfirm = ltfStruct.wyckoff.hasValidConfirmationTrigger &&
            ((isLong && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.LONG) ||
                (!isLong && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.SHORT))

        val volumeTrigger = activeModules.contains(StyleModule.VOLUME_TRADING_ORDERFLOW) && ltfVolume != null &&
            ((isLong && (ltfVolume.isHighRvolBullBreakout || ltfVolume.amtState == AmtState.AMT_FAILED_AUCTION_BULL)) ||
                (!isLong && (ltfVolume.isHighRvolBearBreakout || ltfVolume.amtState == AmtState.AMT_FAILED_AUCTION_BEAR)))

        val hasExecutionTrigger = if (isLong) {
            ltfStruct.isSignificantBullBar || ltfStruct.isMovementReversalBull ||
                ltfStruct.isNoSupplyBar || directionalWyckoffConfirm || volumeTrigger ||
                ltfStruct.lastBreakKind == StructureBreakKind.MSS_BULL_DISPLACEMENT
        } else {
            ltfStruct.isSignificantBearBar || ltfStruct.isMovementReversalBear ||
                ltfStruct.isNoDemandBar || directionalWyckoffConfirm || volumeTrigger ||
                ltfStruct.lastBreakKind == StructureBreakKind.MSS_BEAR_DISPLACEMENT
        }

        if (!hasExecutionTrigger) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "AWAITING_CONFIRMED_CANDLE_TRIGGER")
        }

        val c = ltfQuant.closePrice
        val atr = max(1e-8, ltfQuant.atr14)
        val dir = if (isLong) TradeDirection.LONG else TradeDirection.SHORT

        val activeZone = if (isLong) {
            demandZones.minByOrNull { abs(c - it.midConsequentEncroachment) }
        } else {
            supplyZones.minByOrNull { abs(c - it.midConsequentEncroachment) }
        }

        val entryTop: Double = activeZone?.top ?: (c + atr * 0.15)
        val entryBottom: Double = activeZone?.bottom ?: (c - atr * 0.15)
        val zoneMid = (entryTop + entryBottom) * 0.5

        val setupAnchor = activeZone?.createdTime
            ?: sweep?.sweepBarIdx?.toLong()
            ?: ltfStruct.wyckoff.anchorClimaxTime
        val setupId = "${config.symbol}_${config.executionTimeframe}_${dir.name}_$setupAnchor"
        val validUntilBar = ltfStruct.lastBarIndex + config.signalValidityBars

        if (setupId in activeSetupIds) {
            return rejectedCompanion(config, comboId, activeModules, winningScore, "DUPLICATE_SETUP_ALREADY_ACTIVE", setupId)
        }

        val distFromEntryZone = when {
            c > entryTop -> c - entryTop
            c < entryBottom -> entryBottom - c
            else -> 0.0
        }

        if (activeZone != null && distFromEntryZone > atr * config.maxEntryDistanceAtr) {
            val suggestedLimit = if (ltfStruct.fib.ote705 in entryBottom..entryTop) ltfStruct.fib.ote705 else zoneMid
            return rejectedCompanion(
                config = config,
                comboId = comboId,
                modules = activeModules,
                score = winningScore,
                reason = "MISSED_ENTRY_WAIT_RETEST",
                setupId = setupId,
                isLimitRetest = true,
                suggestedLimit = round2(suggestedLimit),
                validUntilBar = validUntilBar
            )
        }

        val stopLoss: Double
        val tp1: Double
        val tp2: Double
        val tp3: Double
        val invalidationCode: String

        if (isLong) {
            val rawStop = when {
                hasBullSweep && sweep?.sweepExtremePrice != null ->
                    sweep.sweepExtremePrice - (atr * 0.30)
                ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.LONG && ltfStruct.wyckoff.structuralStopLevel < c ->
                    ltfStruct.wyckoff.structuralStopLevel
                activeZone != null -> activeZone.bottom - (atr * 0.30)
                else -> c - (atr * 1.5)
            }
            stopLoss = min(rawStop, c - atr * 0.6)
            val riskDist = c - stopLoss
            if (riskDist > atr * config.maxStopAtrMultiple) {
                return rejectedCompanion(config, comboId, activeModules, winningScore, "STOP_TOO_WIDE", setupId)
            }

            val npocTargets = ltfVolume?.nakedPocs?.filter { it.pocPrice > c + riskDist * 1.2 }?.map { it.pocPrice } ?: emptyList()
            val structuralTargets = (magnets.filter { it.level > c + riskDist * 1.2 }.map { it.level } +
                supplyZones.filter { it.bottom > c + riskDist * 1.2 }.map { it.bottom } +
                npocTargets)
                .sorted()

            tp1 = structuralTargets.firstOrNull { it <= c + riskDist * 3.5 }
                ?: (c + riskDist * 1.8)
            tp2 = structuralTargets.firstOrNull { it > tp1 + atr * 0.8 && it <= c + riskDist * 5.0 }
                ?: if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.target1to1Projection > tp1) {
                    ltfStruct.wyckoff.target1to1Projection
                } else {
                    c + riskDist * 3.0
                }
            tp3 = if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.targetFib1618Projection > tp2) {
                ltfStruct.wyckoff.targetFib1618Projection
            } else {
                max(tp2 + riskDist, ltfStruct.fib.ext1618)
            }
            invalidationCode = "CANDLE_CLOSE_BELOW_${round2(stopLoss)}_INVALIDATES_SETUP"
        } else {
            val rawStop = when {
                hasBearSweep && sweep?.sweepExtremePrice != null ->
                    sweep.sweepExtremePrice + (atr * 0.30)
                ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.confirmDirection == ConfirmDirection.SHORT && ltfStruct.wyckoff.structuralStopLevel > c ->
                    ltfStruct.wyckoff.structuralStopLevel
                activeZone != null -> activeZone.top + (atr * 0.30)
                else -> c + (atr * 1.5)
            }
            stopLoss = max(rawStop, c + atr * 0.6)
            val riskDist = stopLoss - c
            if (riskDist > atr * config.maxStopAtrMultiple) {
                return rejectedCompanion(config, comboId, activeModules, winningScore, "STOP_TOO_WIDE", setupId)
            }

            val npocTargets = ltfVolume?.nakedPocs?.filter { it.pocPrice < c - riskDist * 1.2 }?.map { it.pocPrice } ?: emptyList()
            val structuralTargets = (magnets.filter { it.level < c - riskDist * 1.2 }.map { it.level } +
                demandZones.filter { it.top < c - riskDist * 1.2 }.map { it.top } +
                npocTargets)
                .sortedDescending()

            tp1 = structuralTargets.firstOrNull { it >= c - riskDist * 3.5 }
                ?: (c - riskDist * 1.8)
            tp2 = structuralTargets.firstOrNull { it < tp1 - atr * 0.8 && it >= c - riskDist * 5.0 }
                ?: if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.target1to1Projection < tp1) {
                    ltfStruct.wyckoff.target1to1Projection
                } else {
                    c - riskDist * 3.0
                }
            tp3 = if (ltfStruct.wyckoff.isActive && ltfStruct.wyckoff.targetFib1618Projection < tp2) {
                ltfStruct.wyckoff.targetFib1618Projection
            } else {
                min(tp2 - riskDist, ltfStruct.fib.ext1618)
            }
            invalidationCode = "CANDLE_CLOSE_ABOVE_${round2(stopLoss)}_INVALIDATES_SETUP"
        }

        val dynamicBaselineAtrRatio = if (ltfQuant.baselineAtrPct > 0.0) {
            ltfQuant.baselineAtrPct / 100.0
        } else {
            riskTemplate.currentBaselineAtrPct
        }

        val sizingInput = riskTemplate.copy(
            symbol = config.symbol,
            marketType = config.marketType,
            direction = dir,
            entryPrice = c,
            stopLossPrice = stopLoss,
            takeProfit1Price = tp1,
            takeProfit2Price = tp2,
            currentBaselineAtrPct = dynamicBaselineAtrRatio,
            currentRealizedAtrPct = ltfQuant.atrPct / 100.0
        )

        val sizingResult = RiskAndPsychologyEngine.calculatePositionSize(sizingInput)
        if (!sizingResult.isAllowed) {
            return rejectedCompanion(
                config,
                comboId,
                activeModules,
                winningScore,
                "RISK_ENGINE_BLOCKED: ${sizingResult.rejectionReason}",
                setupId
            )
        }

        if (sizingResult.netRewardToRiskTp1 < config.minNetRrRatio) {
            return rejectedCompanion(
                config,
                comboId,
                activeModules,
                winningScore,
                "INSUFFICIENT_NET_RR_AFTER_FEES_${sizingResult.netRewardToRiskTp1}",
                setupId
            )
        }

        return CompanionSignalOutput(
            isSignalActive = true,
            noSignalReasonCode = null,
            setupId = setupId,
            validUntilBarIndex = validUntilBar,
            isLimitOrderRetest = false,
            suggestedLimitEntryPrice = round2(zoneMid),
            symbol = config.symbol,
            marketType = config.marketType,
            direction = dir,
            timeframe = config.executionTimeframe,
            strategyComboId = comboId,
            activeModules = activeModules,
            confluenceScore = round1(winningScore),
            entryZoneTop = round2(entryTop),
            entryZoneBottom = round2(entryBottom),
            optimalEntryPrice = round2(c),
            stopLossPrice = round2(stopLoss),
            takeProfit1Price = round2(tp1),
            takeProfit2Price = round2(tp2),
            takeProfit3RunnerPrice = round2(tp3),
            invalidationConditionCode = invalidationCode,
            reasonCodes = winningReasons,
            riskPositionSizing = sizingResult
        )
    }

    private fun rejectedCompanion(
        config: StrategyConfigRequest,
        comboId: String,
        modules: Set<StyleModule>,
        score: Double,
        reason: String,
        setupId: String = "",
        isLimitRetest: Boolean = false,
        suggestedLimit: Double? = null,
        validUntilBar: Int = 0
    ) = CompanionSignalOutput(
        isSignalActive = false,
        noSignalReasonCode = reason,
        setupId = setupId,
        validUntilBarIndex = validUntilBar,
        isLimitOrderRetest = isLimitRetest,
        suggestedLimitEntryPrice = suggestedLimit,
        symbol = config.symbol,
        marketType = config.marketType,
        direction = null,
        timeframe = config.executionTimeframe,
        strategyComboId = comboId,
        activeModules = modules,
        confluenceScore = round1(score),
        entryZoneTop = 0.0,
        entryZoneBottom = 0.0,
        optimalEntryPrice = 0.0,
        stopLossPrice = 0.0,
        takeProfit1Price = 0.0,
        takeProfit2Price = 0.0,
        takeProfit3RunnerPrice = null,
        invalidationConditionCode = "",
        reasonCodes = emptyList(),
        riskPositionSizing = null
    )

    private data class OrthogonalScoreResult(
        val bullScore: Double,
        val bearScore: Double,
        val bullReasons: List<String>,
        val bearReasons: List<String>
    )

    private fun round1(v: Double): Double = kotlin.math.round(v * 10.0) / 10.0
    private fun round2(v: Double): Double = kotlin.math.round(v * 100.0) / 100.0
}
