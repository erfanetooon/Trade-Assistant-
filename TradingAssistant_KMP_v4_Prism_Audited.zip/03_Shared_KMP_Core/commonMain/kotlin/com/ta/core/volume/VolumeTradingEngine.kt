package com.ta.core.volume

import com.ta.core.quant.BarNode
import com.ta.core.quant.CoreQuantIndicatorsEngine
import com.ta.core.quant.VolProfileTuple
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class AmtState {
    AMT_BALANCE_INSIDE_VA,
    AMT_IMBALANCE_BULL_ACCEPTANCE,
    AMT_IMBALANCE_BEAR_ACCEPTANCE,
    AMT_FAILED_AUCTION_BULL,
    AMT_FAILED_AUCTION_BEAR
}

enum class CvdAbsorptionCode {
    NONE,
    BULL_ABSORPTION_DIVERGENCE,
    BEAR_ABSORPTION_DIVERGENCE
}

data class NakedPocLevel(
    val sessionBucket: Long,
    val pocPrice: Double,
    val isMitigated: Boolean
)

data class VolumeImbalanceZone(
    val top: Double,
    val bottom: Double,
    val isBullish: Boolean,
    val createdTime: Long,
    val rvolAtCreation: Double,
    val isMitigated: Boolean
)

data class VolumeTradingSnapshot(
    val timestamp: Long,
    val rvol: Double,
    val barDelta: Double,
    val cumulativeDelta: Double,
    val deltaRatio: Double,
    val cvdAbsorption: CvdAbsorptionCode,
    val amtState: AmtState,
    val volProfile: VolProfileTuple,
    val nakedPocs: List<NakedPocLevel>,
    val activeVolumeImbalances: List<VolumeImbalanceZone>,
    val isHighRvolBullBreakout: Boolean,
    val isHighRvolBearBreakout: Boolean
)

object VolumeTradingEngine {

    fun analyzeVolumeOrderflow(
        rawBars: List<BarNode>,
        rvolPeriod: Int = 20,
        vpLookback: Int = 120,
        vpBins: Int = 48
    ): VolumeTradingSnapshot? {
        val bars = rawBars.filter { it.closed }
        val n = bars.size
        if (n < max(vpLookback, 60)) return null

        val vols = DoubleArray(n) { bars[it].v }
        val volSma = CoreQuantIndicatorsEngine.calcSmaSeries(vols, rvolPeriod)
        val lastIdx = n - 1
        val lastBar = bars[lastIdx]
        val avgVol = max(1e-8, volSma[lastIdx])
        val rvol = lastBar.v / avgVol

        val deltas = DoubleArray(n)
        val cvd = DoubleArray(n)
        for (i in 0 until n) {
            val b = bars[i]
            val range = b.h - b.l
            val d = if (range > 1e-12) {
                val buyVol = b.v * ((b.c - b.l) / range)
                val sellVol = b.v * ((b.h - b.c) / range)
                buyVol - sellVol
            } else {
                if (i > 0 && b.c >= bars[i - 1].c) b.v * 0.5 else -b.v * 0.5
            }
            deltas[i] = d
            cvd[i] = if (i == 0) d else cvd[i - 1] + d
        }

        val lastDelta = deltas[lastIdx]
        val deltaRatio = if (lastBar.v > 0.0) (lastDelta / lastBar.v).coerceIn(-1.0, 1.0) else 0.0
        val absorption = detectCvdAbsorption(bars, cvd, 4, 45)

        val vp = CoreQuantIndicatorsEngine.calcVolumeProfile(bars.takeLast(vpLookback), vpBins, 0.70)
        val amtState = classifyAuctionMarketState(bars, vp, rvol, deltaRatio)
        val nPocs = extractNakedPocs(bars, 24, 36)
        val imbalances = extractVolumeImbalances(bars, volSma)

        val isBullBo = rvol >= 1.45 && deltaRatio >= 0.25 && lastBar.c > lastBar.o
        val isBearBo = rvol >= 1.45 && deltaRatio <= -0.25 && lastBar.c < lastBar.o

        return VolumeTradingSnapshot(
            timestamp = lastBar.t,
            rvol = rvol,
            barDelta = lastDelta,
            cumulativeDelta = cvd[lastIdx],
            deltaRatio = deltaRatio,
            cvdAbsorption = absorption,
            amtState = amtState,
            volProfile = vp,
            nakedPocs = nPocs,
            activeVolumeImbalances = imbalances,
            isHighRvolBullBreakout = isBullBo,
            isHighRvolBearBreakout = isBearBo
        )
    }

    private fun detectCvdAbsorption(
        bars: List<BarNode>,
        cvd: DoubleArray,
        pivotSpan: Int,
        maxLookback: Int
    ): CvdAbsorptionCode {
        val n = bars.size
        if (n < maxLookback + pivotSpan * 2) return CvdAbsorptionCode.NONE

        val pivotHighs = mutableListOf<Int>()
        val pivotLows = mutableListOf<Int>()
        val latestConfirm = n - 1 - pivotSpan
        val earliest = max(pivotSpan, n - maxLookback)

        for (i in latestConfirm downTo earliest) {
            var isH = true
            var isL = true
            for (k in 1..pivotSpan) {
                if (bars[i].h <= bars[i - k].h || bars[i].h < bars[i + k].h) isH = false
                if (bars[i].l >= bars[i - k].l || bars[i].l > bars[i + k].l) isL = false
            }
            if (isH && pivotHighs.size < 2) pivotHighs.add(i)
            if (isL && pivotLows.size < 2) pivotLows.add(i)
            if (pivotHighs.size >= 2 && pivotLows.size >= 2) break
        }

        if (pivotLows.size >= 2) {
            val p2 = pivotLows[0]
            val p1 = pivotLows[1]
            if (n - 1 - p2 <= pivotSpan + 3) {
                if (bars[p2].l < bars[p1].l && cvd[p2] > cvd[p1]) {
                    return CvdAbsorptionCode.BULL_ABSORPTION_DIVERGENCE
                }
            }
        }

        if (pivotHighs.size >= 2) {
            val p2 = pivotHighs[0]
            val p1 = pivotHighs[1]
            if (n - 1 - p2 <= pivotSpan + 3) {
                if (bars[p2].h > bars[p1].h && cvd[p2] < cvd[p1]) {
                    return CvdAbsorptionCode.BEAR_ABSORPTION_DIVERGENCE
                }
            }
        }

        return CvdAbsorptionCode.NONE
    }

    private fun classifyAuctionMarketState(
        bars: List<BarNode>,
        vp: VolProfileTuple,
        rvol: Double,
        deltaRatio: Double
    ): AmtState {
        val last = bars.last()
        val prev = bars[bars.size - 2]

        if (prev.l < vp.valPrice && last.c > vp.valPrice && last.c > last.o && deltaRatio > 0.1) {
            return AmtState.AMT_FAILED_AUCTION_BULL
        }
        if (prev.h > vp.vah && last.c < vp.vah && last.c < last.o && deltaRatio < -0.1) {
            return AmtState.AMT_FAILED_AUCTION_BEAR
        }
        if (last.c > vp.vah && rvol >= 1.15 && deltaRatio > 0.1) {
            return AmtState.AMT_IMBALANCE_BULL_ACCEPTANCE
        }
        if (last.c < vp.valPrice && rvol >= 1.15 && deltaRatio < -0.1) {
            return AmtState.AMT_IMBALANCE_BEAR_ACCEPTANCE
        }
        return AmtState.AMT_BALANCE_INSIDE_VA
    }

    private fun extractNakedPocs(
        bars: List<BarNode>,
        sessionBars: Int,
        bins: Int
    ): List<NakedPocLevel> {
        val n = bars.size
        val out = mutableListOf<NakedPocLevel>()
        var start = max(0, n - sessionBars * 6)
        var bucketIdx = 0L
        while (start + sessionBars < n - sessionBars) {
            val end = start + sessionBars
            val slice = bars.subList(start, end)
            val vp = CoreQuantIndicatorsEngine.calcVolumeProfile(slice, bins, 0.70)
            var mitigated = false
            for (k in end until n) {
                if (bars[k].l <= vp.poc && bars[k].h >= vp.poc) {
                    mitigated = true
                    break
                }
            }
            if (!mitigated) {
                out.add(NakedPocLevel(bucketIdx, vp.poc, false))
            }
            start = end
            bucketIdx++
        }
        return out
    }

    private fun extractVolumeImbalances(
        bars: List<BarNode>,
        volSma: DoubleArray
    ): List<VolumeImbalanceZone> {
        val n = bars.size
        val out = mutableListOf<VolumeImbalanceZone>()
        val start = max(1, n - 60)

        for (i in start until (n - 1)) {
            val prev = bars[i - 1]
            val cur = bars[i]
            val rvol = cur.v / max(1e-8, volSma[i])
            if (rvol < 1.25) continue

            val prevTop = max(prev.o, prev.c)
            val prevBot = min(prev.o, prev.c)
            val curTop = max(cur.o, cur.c)
            val curBot = min(cur.o, cur.c)

            if (curBot > prevTop && cur.c > cur.o) {
                var mitigated = false
                for (k in (i + 1) until n) {
                    if (bars[k].l <= prevTop) {
                        mitigated = true
                        break
                    }
                }
                if (!mitigated) {
                    out.add(VolumeImbalanceZone(curBot, prevTop, true, cur.t, rvol, false))
                }
            } else if (curTop < prevBot && cur.c < cur.o) {
                var mitigated = false
                for (k in (i + 1) until n) {
                    if (bars[k].h >= prevBot) {
                        mitigated = true
                        break
                    }
                }
                if (!mitigated) {
                    out.add(VolumeImbalanceZone(prevBot, curTop, false, cur.t, rvol, false))
                }
            }
        }
        return out.takeLast(6)
    }
}
