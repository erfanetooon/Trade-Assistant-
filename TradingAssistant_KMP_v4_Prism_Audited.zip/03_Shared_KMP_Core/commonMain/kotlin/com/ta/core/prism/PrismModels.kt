package com.ta.core.prism

import com.ta.core.quant.BarNode

enum class Bias(val sign: Int) { BULL(1), BEAR(-1), NEUTRAL(0) }

enum class Regime { TREND, RANGE, VOLATILE }

enum class MarketSession { ASIA, LONDON, NEW_YORK, OVERLAP_LDN_NY }

data class Candle(
    val t: Long,
    val o: Double,
    val h: Double,
    val l: Double,
    val c: Double,
    val v: Double,
    val takerBuyVol: Double = v * 0.5
) {
    fun toBarNode(closed: Boolean = true): BarNode = BarNode(
        t = t,
        o = o,
        h = h,
        l = l,
        c = c,
        v = v,
        closed = closed
    )

    companion object {
        fun fromBarNode(bar: BarNode, takerBuyVol: Double = bar.v * 0.5): Candle = Candle(
            t = bar.t,
            o = bar.o,
            h = bar.h,
            l = bar.l,
            c = bar.c,
            v = bar.v,
            takerBuyVol = takerBuyVol
        )
    }
}

data class MultiTF(
    val ltf: List<Candle>,
    val htf: List<Candle> = emptyList()
)

data class Level(val price: Double, val label: String)

data class Evidence(val text: String, val weight: Double)

data class MarketContext(
    val regime: Regime,
    val volPercentile: Double,
    val htfBias: Bias,
    val session: MarketSession,
    val currentAtr: Double
)

data class StyleVerdict(
    val styleId: String,
    val bias: Bias,
    val confidence: Double, // 0.0 .. 1.0
    val evidence: List<Evidence>,
    val keyLevels: List<Level>,
    val invalidation: Level?,
    val suitableRegimes: Set<Regime>
)

interface StyleAnalyzer {
    val id: String
    fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict
}

data class ConsensusResult(
    val bias: Bias,
    val confidence: Double,
    val agreement: Double,
    val conflicts: List<String>,
    val verdicts: List<StyleVerdict>,
    val contributingStyles: List<String>
)

// ---------- Analysis Mode ----------
data class Scenario(
    val name: String,
    val probability: Double,
    val description: String
)

data class AnalysisReport(
    val summary: String,
    val scenarios: List<Scenario>,
    val levels: List<Level>,
    val whatChangesMyMind: List<String>
)

// ---------- Trade Mode ----------
sealed interface TradeResult {
    data class Signal(
        val bias: Bias,
        val entryZoneLow: Double,
        val entryZoneHigh: Double,
        val entry: Double,
        val stop: Double,
        val tps: List<Double>,
        val rr: Double,
        val recommendedQty: Double,
        val confidence: Double,
        val reasons: List<String>,
        val expiresAt: Long
    ) : TradeResult

    data class NoTrade(val reason: String) : TradeResult
}

// ---------- Externalized Config (Thresholds & Weights) ----------
data class RegimeConfig(
    val atrPeriod: Int = 14,
    val atrPercentileLookback: Int = 100,
    val volatileAtrPercentile: Double = 0.85,
    val trendEmaPeriod: Int = 50,
    val trendSlopeLookback: Int = 10,
    val trendSlopeAtrThreshold: Double = 1.0,
    val minClosedCandles: Int = 110
)

data class ConsensusConfig(
    val biasThreshold: Double = 0.25,
    val nonSuitableRegimeWeight: Double = 0.40,
    val minPerformanceSamples: Int = 10,
    val minPerfMultiplier: Double = 0.50,
    val maxPerfMultiplier: Double = 1.50
)

data class GateConfig(
    val minConfidence: Double = 0.35,
    val minAgreement: Double = 0.65,
    val minStyles: Int = 3,
    val minStylesRange: Int = 2,
    val minRR: Double = 1.5,
    val minStopAtrMultiple: Double = 1.0,
    val signalTtlMs: Long = 4 * 3_600_000L,
    val allowedRegimes: Set<Regime> = setOf(Regime.TREND, Regime.RANGE),
    val vetoOnConflicts: Boolean = true
)

data class PrismConfig(
    val regime: RegimeConfig = RegimeConfig(),
    val consensus: ConsensusConfig = ConsensusConfig(),
    val gate: GateConfig = GateConfig()
)
