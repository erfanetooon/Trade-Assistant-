package com.ta.core.prism

import kotlin.math.max
import kotlin.math.min

/**
 * Plugin 3: Momentum / Mean Reversion (designed primarily for Regime.RANGE)
 *
 * Entry / Bias Rules:
 * - Uses Bollinger Bands (20, 2.0) and Wilder RSI(14) on closed candles.
 * - BULL mean reversion: previous or current candle pierced/touched lower band (<= lowBand)
 *   AND RSI <= 35 (or turning up from oversold) AND current closed candle shows rejection/reclaim
 *   (close > open or close back above lower band) to avoid catching falling knives.
 * - BEAR mean reversion: previous or current candle pierced/touched upper band (>= upBand)
 *   AND RSI >= 65 (or turning down from overbought) AND current closed candle shows rejection/reclaim.
 *
 * Invalidation Rules:
 * - BULL invalidation: min(last.l, prev.l) - 1.2 * ATR.
 * - BEAR invalidation: max(last.h, prev.h) + 1.2 * ATR.
 */
class MomentumMeanReversionStyle(
    private val minCandles: Int = 50,
    private val rsiOversold: Double = 35.0,
    private val rsiOverbought: Double = 65.0,
    private val stopAtrMult: Double = 1.2
) : StyleAnalyzer {

    override val id: String = "momentum_mean_reversion"
    private val regimes: Set<Regime> = setOf(Regime.RANGE)

    private fun neutral(levels: List<Level> = emptyList()) =
        StyleVerdict(id, Bias.NEUTRAL, 0.0, emptyList(), levels, null, regimes)

    override fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict {
        if (candles.size < minCandles) return neutral()

        val closes = DoubleArray(candles.size) { candles[it].c }
        val rsiArr = Ind.rsi(closes, 14)
        val bbArr = Ind.bollinger(closes, 20, 2.0, 100)
        val atrArr = Ind.atr(candles, 14)

        val i = candles.lastIndex
        val last = candles[i]
        val prev = candles[i - 1]
        val bb = bbArr[i]
        val prevBb = bbArr[i - 1]
        val rsi = rsiArr[i]
        val prevRsi = rsiArr[i - 1]
        val atr = atrArr[i]

        if (listOf(bb.mid, bb.up, bb.low, rsi, prevRsi, atr).any { it.isNaN() } || atr <= 0.0) {
            return neutral()
        }

        val levels = listOf(
            Level(bb.up, "باند بالای بولینگر"),
            Level(bb.mid, "میانگین بولینگر (SMA20)"),
            Level(bb.low, "باند پایین بولینگر")
        )

        val bullTouch = prev.l <= prevBb.low || last.l <= bb.low
        val bullRsi = prevRsi <= rsiOversold || rsi <= rsiOversold
        val bullConfirm = last.c >= bb.low && (last.c > last.o || rsi > prevRsi)

        val bearTouch = prev.h >= prevBb.up || last.h >= bb.up
        val bearRsi = prevRsi >= rsiOverbought || rsi >= rsiOverbought
        val bearConfirm = last.c <= bb.up && (last.c < last.o || rsi < prevRsi)

        val ev = mutableListOf<Evidence>()
        if (bullTouch && bullRsi && bullConfirm) {
            var conf = 0.50
            ev += Evidence("برخورد به باند پایین بولینگر و بازگشت به داخل", 0.65)
            ev += Evidence("RSI در ناحیه اشباع فروش (${rsi.toInt()})", 0.55)
            if (rsi > prevRsi) {
                conf += 0.15
                ev += Evidence("چرخش صعودی مومنتوم RSI", 0.60)
            }
            if (last.c > last.o) {
                conf += 0.10
                ev += Evidence("کندل تایید صعودی در کف باند", 0.50)
            }
            if (ctx.regime == Regime.RANGE) {
                conf += 0.10
                ev += Evidence("هم‌راستایی با رژیم رنج بازار", 0.50)
            }
            val inv = min(last.l, prev.l) - stopAtrMult * atr
            return StyleVerdict(
                styleId = id,
                bias = Bias.BULL,
                confidence = conf.coerceIn(0.0, 0.90),
                evidence = ev,
                keyLevels = levels,
                invalidation = Level(inv, "ابطال بازگشت به میانگین (۱.۲ ATR)"),
                suitableRegimes = regimes
            )
        }

        if (bearTouch && bearRsi && bearConfirm) {
            var conf = 0.50
            ev += Evidence("برخورد به باند بالای بولینگر و بازگشت به داخل", 0.65)
            ev += Evidence("RSI در ناحیه اشباع خرید (${rsi.toInt()})", 0.55)
            if (rsi < prevRsi) {
                conf += 0.15
                ev += Evidence("چرخش نزولی مومنتوم RSI", 0.60)
            }
            if (last.c < last.o) {
                conf += 0.10
                ev += Evidence("کندل تایید نزولی در سقف باند", 0.50)
            }
            if (ctx.regime == Regime.RANGE) {
                conf += 0.10
                ev += Evidence("هم‌راستایی با رژیم رنج بازار", 0.50)
            }
            val inv = max(last.h, prev.h) + stopAtrMult * atr
            return StyleVerdict(
                styleId = id,
                bias = Bias.BEAR,
                confidence = conf.coerceIn(0.0, 0.90),
                evidence = ev,
                keyLevels = levels,
                invalidation = Level(inv, "ابطال بازگشت به میانگین (۱.۲ ATR)"),
                suitableRegimes = regimes
            )
        }

        return neutral(levels)
    }
}
