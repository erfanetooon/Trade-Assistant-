package com.ta.core.prism

import kotlin.math.abs
import kotlin.math.round

/**
 * Mode Renderer 1: AnalysisMode (Strict Analyst Output)
 *
 * Invariant: NEVER outputs entry price, stop loss, take profit, or executable trade signal.
 * Produces a Persian narrative summary, 3 calibrated scenarios (Bull/Base/Bear summing to 1.0),
 * deduplicated key structural/indicator levels, and concrete invalidation triggers ("what changes my mind").
 */
class AnalysisRenderer {

    fun render(ctx: MarketContext, r: ConsensusResult, last: Candle): AnalysisReport {
        val regimeFa = when (ctx.regime) {
            Regime.TREND -> "رونددار"
            Regime.RANGE -> "رنج و متعادل"
            Regime.VOLATILE -> "پرنوسان"
        }
        val htfFa = when (ctx.htfBias) {
            Bias.BULL -> "صعودی"
            Bias.BEAR -> "نزولی"
            Bias.NEUTRAL -> "خنثی"
        }
        val biasFa = when (r.bias) {
            Bias.BULL -> "صعودی"
            Bias.BEAR -> "نزولی"
            Bias.NEUTRAL -> "خنثی (بدون برتری قطعی)"
        }

        val confPct = (r.confidence * 100.0).toInt()
        val agreePct = (r.agreement * 100.0).toInt()
        val conflictNote = if (r.conflicts.isNotEmpty()) {
            " هشدار تضاد فعال: ${r.conflicts.joinToString("، ")}."
        } else {
            " تضاد ساختاری فعالی بین سبک‌ها دیده نمی‌شود."
        }

        val stylesText = if (r.contributingStyles.isNotEmpty()) {
            "سبک‌های همسو: ${r.contributingStyles.joinToString("، ")}."
        } else {
            "هیچ اجماع جهت‌داری بین سبک‌ها شکل نگرفته است."
        }

        val summary = buildString {
            append("رژیم فعلی بازار «$regimeFa» (پرسنتایل نوسان ${(ctx.volPercentile * 100.0).toInt()}٪) ")
            append("و بایاس تایم‌فریم بالاتر «$htfFa» است. ")
            append("برآیند اجماع سبک‌ها «$biasFa» با قدرت $confPct٪ و همنظری $agreePct٪ ارزیابی می‌شود. ")
            append(stylesText)
            append(conflictNote)
        }

        val scenarios = buildScenarios(ctx, r)
        val levels = deduplicateLevels(r.verdicts.flatMap { it.keyLevels }, last.c, ctx.currentAtr)
        val whatChanges = buildWhatChangesMyMind(ctx, r)

        return AnalysisReport(
            summary = summary,
            scenarios = scenarios,
            levels = levels,
            whatChangesMyMind = whatChanges
        )
    }

    private fun buildScenarios(ctx: MarketContext, r: ConsensusResult): List<Scenario> {
        val conflictPenalty = if (r.conflicts.isNotEmpty()) 0.12 else 0.0
        val strength = ((r.confidence * 0.65 + r.agreement * 0.35) - conflictPenalty).coerceIn(0.0, 0.70)

        var pBull: Double
        var pBase: Double
        var pBear: Double

        when (r.bias) {
            Bias.BULL -> {
                pBull = (0.42 + strength * 0.45).coerceIn(0.35, 0.75)
                pBase = (0.36 - strength * 0.25).coerceIn(0.15, 0.40)
                pBear = (1.0 - pBull - pBase).coerceAtLeast(0.08)
            }
            Bias.BEAR -> {
                pBear = (0.42 + strength * 0.45).coerceIn(0.35, 0.75)
                pBase = (0.36 - strength * 0.25).coerceIn(0.15, 0.40)
                pBull = (1.0 - pBear - pBase).coerceAtLeast(0.08)
            }
            Bias.NEUTRAL -> {
                pBase = if (ctx.regime == Regime.RANGE) 0.52 else 0.44
                val htfTilt = ctx.htfBias.sign * 0.06
                pBull = ((1.0 - pBase) * 0.5 + htfTilt).coerceAtLeast(0.10)
                pBear = (1.0 - pBase - pBull).coerceAtLeast(0.10)
            }
        }

        // Normalize cleanly to sum == 1.00
        val sum = pBull + pBase + pBear
        pBull = round((pBull / sum) * 100.0) / 100.0
        pBear = round((pBear / sum) * 100.0) / 100.0
        pBase = round((1.0 - pBull - pBear) * 100.0) / 100.0

        val bullDesc = if (r.bias == Bias.BULL) {
            "حفظ ساختار فعلی و ادامه حرکت به سمت مقاومت‌های کلیدی بالاتر با همراهی حجم."
        } else {
            "بازپس‌گیری سطوح کلیدی بالاتر و شکست مقاومت‌های کوتاه‌مدت در صورت افزایش تقاضا."
        }

        val baseDesc = if (ctx.regime == Regime.RANGE) {
            "تداوم نوسان خنثی بین کف و سقف محدوده فعلی تا خروج قطعی از تعادل."
        } else {
            "توقف موقت مومنتوم و ورود بازار به فاز استراحت یا اصلاح زمانی بدون شکست ساختار."
        }

        val bearDesc = if (r.bias == Bias.BEAR) {
            "ادامه فشار عرضه و حرکت به سمت حمایت‌های ساختاری پایین‌تر."
        } else {
            "از دست رفتن حمایت‌های نزدیک و تغییر کاراکتر بازار به فاز اصلاحی یا نزولی."
        }

        return listOf(
            Scenario("سناریوی صعودی", pBull, bullDesc),
            Scenario("سناریوی پایه (خنثی/تثبیت)", pBase, baseDesc),
            Scenario("سناریوی نزولی", pBear, bearDesc)
        )
    }

    private fun deduplicateLevels(rawLevels: List<Level>, refPrice: Double, atr: Double): List<Level> {
        val minGap = (atr * 0.15).coerceAtLeast(1e-6)
        val sorted = rawLevels
            .filter { !it.price.isNaN() && it.price > 0.0 }
            .sortedBy { abs(it.price - refPrice) }

        val unique = mutableListOf<Level>()
        for (lvl in sorted) {
            if (unique.none { abs(it.price - lvl.price) < minGap }) {
                unique += lvl
            }
            if (unique.size >= 6) break
        }
        return unique.sortedByDescending { it.price }
    }

    private fun buildWhatChangesMyMind(ctx: MarketContext, r: ConsensusResult): List<String> {
        val items = mutableListOf<String>()

        val agreeingInvs = r.verdicts
            .filter { it.bias == r.bias && r.bias != Bias.NEUTRAL && it.invalidation != null }
            .mapNotNull { it.invalidation }

        if (r.bias == Bias.BULL && agreeingInvs.isNotEmpty()) {
            val keyInv = agreeingInvs.maxBy { it.price }
            items += "بسته شدن کندل زیر سطح ابطال ساختاری (${formatPrice(keyInv.price)} - ${keyInv.label}) دیدگاه صعودی را باطل می‌کند."
        } else if (r.bias == Bias.BEAR && agreeingInvs.isNotEmpty()) {
            val keyInv = agreeingInvs.minBy { it.price }
            items += "بسته شدن کندل بالای سطح ابطال ساختاری (${formatPrice(keyInv.price)} - ${keyInv.label}) دیدگاه نزولی را باطل می‌کند."
        } else {
            items += "خروج قطعی قیمت از محدوده فعلی همراه با کندل جابه‌جایی و حجم بالا (RVOL > 1.4) وضعیت خنثی را تغییر می‌دهد."
        }

        if (ctx.htfBias != Bias.NEUTRAL) {
            items += "چرخش بایاس تایم‌فریم بالاتر از حالت فعلی، اولویت جهت بازار را بازتعریف می‌کند."
        }
        if (ctx.regime != Regime.VOLATILE) {
            items += "جهش ناگهانی نوسان (عبور پرسنتایل ATR از ۸۵٪) سناریوی فعلی را نیازمند بازبینی می‌کند."
        }
        if (r.conflicts.isNotEmpty()) {
            items += "رفع تضادهای فعلی (${r.conflicts.joinToString("، ")}) پیش‌شرط اعتبارسنجی جهت بعدی است."
        }

        return items
    }

    private fun formatPrice(p: Double): String {
        val rounded = round(p * 100.0) / 100.0
        return rounded.toString()
    }
}
