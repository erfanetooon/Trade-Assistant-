package com.ta.core.prism

import kotlin.math.abs

/**
 * Plugin 1: Price Action / Market Structure
 *
 * Entry / Bias Rules:
 * - Confirmed fractal swings only (n closed candles on both sides -> zero look-ahead).
 * - BULL: HH + HL and last close >= last confirmed swing low (l2).
 * - BEAR: LH + LL and last close <= last confirmed swing high (h2).
 * - Confidence boosts: BOS close beyond h2/l2 (+0.20), displacement candle |body| > 1.2*ATR (+0.10),
 *   HTF alignment (+0.10 / -0.15).
 *
 * Invalidation Rules:
 * - BULL invalidation: last confirmed swing low (l2) - 0.25 * ATR.
 * - BEAR invalidation: last confirmed swing high (h2) + 0.25 * ATR.
 */
class PriceActionStyle(
    private val n: Int = 3,
    private val minCandles: Int = 60
) : StyleAnalyzer {

    override val id: String = "price_action"
    private val regimes: Set<Regime> = setOf(Regime.TREND, Regime.VOLATILE)

    private data class Swing(val i: Int, val price: Double)

    private fun neutral(levels: List<Level> = emptyList()) =
        StyleVerdict(id, Bias.NEUTRAL, 0.0, emptyList(), levels, null, regimes)

    override fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict {
        if (candles.size < minCandles) return neutral()

        val highs = mutableListOf<Swing>()
        val lows = mutableListOf<Swing>()
        for (i in n until candles.size - n) {
            val c = candles[i]
            if ((1..n).all { c.h > candles[i - it].h && c.h > candles[i + it].h }) highs += Swing(i, c.h)
            if ((1..n).all { c.l < candles[i - it].l && c.l < candles[i + it].l }) lows += Swing(i, c.l)
        }
        if (highs.size < 2 || lows.size < 2) return neutral()

        val h1 = highs[highs.lastIndex - 1]
        val h2 = highs[highs.lastIndex]
        val l1 = lows[lows.lastIndex - 1]
        val l2 = lows[lows.lastIndex]
        val levels = listOf(
            Level(h2.price, "آخرین سقف ساختاری"),
            Level(l2.price, "آخرین کف ساختاری"),
            Level(h1.price, "سقف ساختاری قبلی"),
            Level(l1.price, "کف ساختاری قبلی")
        )

        val atr = Ind.atr(candles).lastOrNull() ?: Double.NaN
        if (atr.isNaN() || atr <= 0.0) return neutral(levels)

        val last = candles.last()
        val bias = when {
            h2.price > h1.price && l2.price > l1.price -> Bias.BULL
            h2.price < h1.price && l2.price < l1.price -> Bias.BEAR
            else -> Bias.NEUTRAL
        }
        if (bias == Bias.NEUTRAL) return neutral(levels)

        // Broken structure invalidates current directional bias
        if (bias == Bias.BULL && last.c < l2.price) return neutral(levels)
        if (bias == Bias.BEAR && last.c > h2.price) return neutral(levels)

        val ev = mutableListOf<Evidence>()
        var conf = 0.50
        ev += Evidence(if (bias == Bias.BULL) "ساختار صعودی HH + HL" else "ساختار نزولی LH + LL", 0.50)

        val bos = if (bias == Bias.BULL) last.c > h2.price else last.c < l2.price
        if (bos) {
            conf += 0.20
            ev += Evidence("شکست ساختار (BOS) در جهت روند", 0.70)
        }

        val body = last.c - last.o
        val displacement = abs(body) > 1.2 * atr && (body > 0.0) == (bias == Bias.BULL)
        if (displacement) {
            conf += 0.10
            ev += Evidence("کندل جابه‌جایی قوی (بدنه > ۱.۲ ATR)", 0.60)
        }

        when {
            ctx.htfBias == bias -> {
                conf += 0.10
                ev += Evidence("هم‌جهت با تایم‌فریم بالاتر", 0.60)
            }
            ctx.htfBias != Bias.NEUTRAL -> {
                conf -= 0.15
                ev += Evidence("خلاف جهت تایم‌فریم بالاتر", 0.60)
            }
        }

        val inv = if (bias == Bias.BULL) l2.price - 0.25 * atr else h2.price + 0.25 * atr
        return StyleVerdict(
            styleId = id,
            bias = bias,
            confidence = conf.coerceIn(0.0, 0.90),
            evidence = ev,
            keyLevels = levels,
            invalidation = Level(inv, "ابطال ساختار سوینگ"),
            suitableRegimes = regimes
        )
    }
}
