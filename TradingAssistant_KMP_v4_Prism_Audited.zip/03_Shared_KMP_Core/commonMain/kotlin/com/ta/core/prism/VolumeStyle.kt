package com.ta.core.prism

import com.ta.core.volume.AmtState
import com.ta.core.volume.CvdAbsorptionCode
import com.ta.core.volume.VolumeTradingEngine
import kotlin.math.abs

/**
 * Plugin 4: Volume & Order Flow
 *
 * Reuses VolumeTradingEngine (POC/VAH/VAL, AMT state, CVD absorption) when sufficient bars exist,
 * combined with causal prior-20-bar RVOL, 5-vs-20 volume trend, and candle volume thrust/delta.
 *
 * Entry / Bias Rules:
 * - Evaluates abnormal volume (RVOL >= 1.4 vs prior 20 closed bars), short-term volume trend (SMA5 > SMA20),
 *   directional close + taker delta (2*takerBuyVol - v), and VolumeTradingEngine AMT/absorption signals.
 * - Requires net directional volume score >= 0.40 to emit BULL/BEAR (otherwise NEUTRAL).
 *
 * Invalidation Rules:
 * - BULL invalidation: last candle low - 1.0 * ATR (or below active POC/VAL buffer if close).
 * - BEAR invalidation: last candle high + 1.0 * ATR.
 */
class VolumeStyle(
    private val minCandles: Int = 40,
    private val rvolLookback: Int = 20,
    private val abnormalRvolThreshold: Double = 1.4
) : StyleAnalyzer {

    override val id: String = "volume"
    private val regimes: Set<Regime> = setOf(Regime.TREND, Regime.VOLATILE, Regime.RANGE)

    private fun neutral(levels: List<Level> = emptyList()) =
        StyleVerdict(id, Bias.NEUTRAL, 0.0, emptyList(), levels, null, regimes)

    override fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict {
        if (candles.size < minCandles) return neutral()

        val atr = Ind.atr(candles, 14).lastOrNull() ?: Double.NaN
        if (atr.isNaN() || atr <= 0.0) return neutral()

        val last = candles.last()
        val rvol = Ind.rvolPrior(candles, rvolLookback)

        val vols = DoubleArray(candles.size) { candles[it].v }
        val volSma5 = Ind.sma(vols, 5).last()
        val volSma20 = Ind.sma(vols, rvolLookback).last()
        val volTrendRising = !volSma5.isNaN() && !volSma20.isNaN() && volSma20 > 0.0 && volSma5 > volSma20 * 1.10

        val barDir = when {
            last.c > last.o -> 1
            last.c < last.o -> -1
            else -> 0
        }
        val delta = 2.0 * last.takerBuyVol - last.v
        val deltaRatio = if (last.v > 1e-9) delta / last.v else 0.0

        val levels = mutableListOf<Level>()
        val ev = mutableListOf<Evidence>()
        var score = 0.0

        // Abnormal volume thrust on directional candle
        if (rvol >= abnormalRvolThreshold && barDir != 0) {
            score += barDir * 0.40
            ev += Evidence(
                "حجم غیرعادی (${(rvol * 10).toInt() / 10.0}x میانگین ۲۰ کندل) هم‌جهت کندل",
                0.75
            )
        }

        // Rising volume trend supporting recent 3-bar price impulse
        val net3 = last.c - candles[candles.lastIndex - 3].c
        if (volTrendRising && abs(net3) > 0.5 * atr) {
            val impulseDir = if (net3 > 0.0) 1 else -1
            score += impulseDir * 0.20
            ev += Evidence("روند حجم صعودی (SMA5 > SMA20) پشت حرکت قیمت", 0.55)
        }

        // Taker aggressor delta confirmation (when real takerBuyVol is provided)
        if (abs(deltaRatio) >= 0.15) {
            val dDir = if (deltaRatio > 0.0) 1 else -1
            score += dDir * 0.15
            ev += Evidence(
                if (dDir > 0) "برتری خریداران تیکر (Delta مثبت)" else "برتری فروشندگان تیکر (Delta منفی)",
                0.60
            )
        }

        // Reuse existing VolumeTradingEngine (Volume Profile + AMT + CVD Absorption)
        if (candles.size >= 120) {
            val barNodes = candles.map { it.toBarNode(closed = true) }
            val vSnap = VolumeTradingEngine.analyzeVolumeOrderflow(barNodes, rvolLookback, 120, 48)
            if (vSnap != null) {
                levels += Level(vSnap.volProfile.poc, "نقطه کنترل حجم (POC)")
                levels += Level(vSnap.volProfile.vah, "سقف ناحیه ارزش (VAH)")
                levels += Level(vSnap.volProfile.valPrice, "کف ناحیه ارزش (VAL)")

                when (vSnap.amtState) {
                    AmtState.AMT_IMBALANCE_BULL_ACCEPTANCE, AmtState.AMT_FAILED_AUCTION_BULL -> {
                        score += 0.20
                        ev += Evidence("تایید پروفایل حجم و تئوری حراج (صعودی)", 0.65)
                    }
                    AmtState.AMT_IMBALANCE_BEAR_ACCEPTANCE, AmtState.AMT_FAILED_AUCTION_BEAR -> {
                        score -= 0.20
                        ev += Evidence("تایید پروفایل حجم و تئوری حراج (نزولی)", 0.65)
                    }
                    else -> Unit
                }

                when (vSnap.cvdAbsorption) {
                    CvdAbsorptionCode.BULL_ABSORPTION_DIVERGENCE -> {
                        score += 0.15
                        ev += Evidence("جذب فروش در کف (Bullish Absorption)", 0.65)
                    }
                    CvdAbsorptionCode.BEAR_ABSORPTION_DIVERGENCE -> {
                        score -= 0.15
                        ev += Evidence("جذب خرید در سقف (Bearish Absorption)", 0.65)
                    }
                    CvdAbsorptionCode.NONE -> Unit
                }
            }
        }

        val bias = when {
            score >= 0.40 -> Bias.BULL
            score <= -0.40 -> Bias.BEAR
            else -> Bias.NEUTRAL
        }
        if (bias == Bias.NEUTRAL) return neutral(levels)

        val inv = if (bias == Bias.BULL) last.l - 1.0 * atr else last.h + 1.0 * atr
        return StyleVerdict(
            styleId = id,
            bias = bias,
            confidence = abs(score).coerceIn(0.0, 0.90),
            evidence = ev,
            keyLevels = levels,
            invalidation = Level(inv, "ابطال کندل حجم (۱ ATR)"),
            suitableRegimes = regimes
        )
    }
}
