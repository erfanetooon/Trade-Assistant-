package com.ta.core.prism

import kotlin.math.abs

/**
 * Plugin 2: Classic Technical Analysis (Trend + Indicators)
 *
 * Entry / Bias Rules:
 * - Requires at least 220 closed candles so EMA200 is warmed up (otherwise intentionally NEUTRAL).
 * - Scores EMA20/EMA50/EMA200 alignment (±0.40), price vs EMA50 (±0.20), MACD(12,26,9) histogram sign (±0.20),
 *   and RSI(14) momentum band (±0.15) with extreme overbought/oversold dampening (±0.20).
 * - Bias triggers when |score| >= 0.40.
 *
 * Invalidation Rules:
 * - BULL invalidation: last close - 1.5 * ATR.
 * - BEAR invalidation: last close + 1.5 * ATR.
 */
class ClassicTaStyle(
    private val minCandles: Int = 220
) : StyleAnalyzer {

    override val id: String = "classic_ta"
    private val regimes: Set<Regime> = setOf(Regime.TREND)

    private fun neutral() =
        StyleVerdict(id, Bias.NEUTRAL, 0.0, emptyList(), emptyList(), null, regimes)

    override fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict {
        if (candles.size < minCandles) return neutral()

        val close = DoubleArray(candles.size) { candles[it].c }
        val e20 = Ind.ema(close, 20).last()
        val e50 = Ind.ema(close, 50).last()
        val e200 = Ind.ema(close, 200).last()
        val rsi = Ind.rsi(close, 14).last()
        val atr = Ind.atr(candles, 14).last()
        val macdLast = Ind.macd(close, 12, 26, 9).last()

        if (listOf(e20, e50, e200, rsi, atr, macdLast.hist).any { it.isNaN() } || atr <= 0.0) {
            return neutral()
        }

        val last = close.last()
        var score = 0.0
        val ev = mutableListOf<Evidence>()

        if (e20 > e50 && e50 > e200) {
            score += 0.40
            ev += Evidence("چیدمان صعودی EMA20 > EMA50 > EMA200", 0.70)
        } else if (e20 < e50 && e50 < e200) {
            score -= 0.40
            ev += Evidence("چیدمان نزولی EMA20 < EMA50 < EMA200", 0.70)
        }

        if (last > e50) {
            score += 0.20
            ev += Evidence("قیمت بالای EMA50", 0.40)
        } else {
            score -= 0.20
            ev += Evidence("قیمت زیر EMA50", 0.40)
        }

        if (macdLast.hist > 0.0) {
            score += 0.20
            ev += Evidence("هیستوگرام MACD مثبت", 0.40)
        } else {
            score -= 0.20
            ev += Evidence("هیستوگرام MACD منفی", 0.40)
        }

        if (rsi in 50.0..68.0) score += 0.15
        else if (rsi in 32.0..49.999) score -= 0.15

        if (rsi > 75.0) {
            score -= 0.20
            ev += Evidence("RSI در اشباع خرید (>۷۵)", 0.50)
        } else if (rsi < 25.0) {
            score += 0.20
            ev += Evidence("RSI در اشباع فروش (<۲۵)", 0.50)
        }

        val bias = when {
            score >= 0.40 -> Bias.BULL
            score <= -0.40 -> Bias.BEAR
            else -> Bias.NEUTRAL
        }
        if (bias == Bias.NEUTRAL) return neutral()

        val inv = if (bias == Bias.BULL) last - 1.5 * atr else last + 1.5 * atr
        return StyleVerdict(
            styleId = id,
            bias = bias,
            confidence = abs(score).coerceAtMost(0.90),
            evidence = ev,
            keyLevels = listOf(
                Level(e20, "EMA20"),
                Level(e50, "EMA50"),
                Level(e200, "EMA200")
            ),
            invalidation = Level(inv, "ابطال ۱.۵ ATR"),
            suitableRegimes = regimes
        )
    }
}
