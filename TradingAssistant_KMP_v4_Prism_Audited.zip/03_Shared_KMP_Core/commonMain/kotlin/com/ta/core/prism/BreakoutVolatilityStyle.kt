package com.ta.core.prism

import kotlin.math.abs

/**
 * Plugin 5: Breakout & Volatility Compression (Squeeze + Range Breakout with Volume Confirmation)
 *
 * Entry / Bias Rules:
 * - Measures prior N-bar Donchian range (strictly excluding current candle -> zero look-ahead).
 * - Checks volatility compression/squeeze in recent 5 bars (Bollinger bandwidth percentile <= 0.30
 *   or ATR percentile <= 0.35) followed by an expansion close outside the prior range.
 * - Requires volume confirmation (causal RVOL >= 1.30 vs prior 20 closed bars) to reject fakeouts.
 *
 * Invalidation Rules:
 * - BULL invalidation: max(rangeMid, last.c - 1.5 * ATR) capped at least 1.0 * ATR below close.
 * - BEAR invalidation: min(rangeMid, last.c + 1.5 * ATR) capped at least 1.0 * ATR above close.
 */
class BreakoutVolatilityStyle(
    private val rangeLookback: Int = 20,
    private val minCandles: Int = 60,
    private val minBreakoutRvol: Double = 1.30
) : StyleAnalyzer {

    override val id: String = "breakout_volatility"
    private val regimes: Set<Regime> = setOf(Regime.VOLATILE, Regime.TREND)

    private fun neutral(levels: List<Level> = emptyList()) =
        StyleVerdict(id, Bias.NEUTRAL, 0.0, emptyList(), levels, null, regimes)

    override fun analyze(ctx: MarketContext, candles: List<Candle>): StyleVerdict {
        if (candles.size < minCandles) return neutral()

        val closes = DoubleArray(candles.size) { candles[it].c }
        val atrArr = Ind.atr(candles, 14)
        val bbArr = Ind.bollinger(closes, 20, 2.0, 100)

        val lastIdx = candles.lastIndex
        val last = candles[lastIdx]
        val atr = atrArr[lastIdx]
        if (atr.isNaN() || atr <= 0.0) return neutral()

        // Prior range strictly excluding current candle (i - rangeLookback .. i - 1)
        var priorHigh = Double.NEGATIVE_INFINITY
        var priorLow = Double.POSITIVE_INFINITY
        for (k in (lastIdx - rangeLookback) until lastIdx) {
            if (candles[k].h > priorHigh) priorHigh = candles[k].h
            if (candles[k].l < priorLow) priorLow = candles[k].l
        }
        val rangeMid = (priorHigh + priorLow) * 0.5
        val levels = listOf(
            Level(priorHigh, "سقف رنج ۲۰ کندلی"),
            Level(rangeMid, "میانه رنج"),
            Level(priorLow, "کف رنج ۲۰ کندلی")
        )

        // Check if volatility was compressed (squeeze) within the last 5 prior closed bars
        var recentSqueeze = false
        for (k in (lastIdx - 5) until lastIdx) {
            if (k >= 0 && !bbArr[k].bwPercentile.isNaN() && bbArr[k].bwPercentile <= 30.0) {
                recentSqueeze = true
                break
            }
        }

        val rvol = Ind.rvolPrior(candles, 20)
        val bullBreak = last.c > priorHigh && last.c > last.o
        val bearBreak = last.c < priorLow && last.c < last.o

        if (!bullBreak && !bearBreak) return neutral(levels)
        if (rvol < minBreakoutRvol) return neutral(levels) // Reject low-volume fakeouts

        val bias = if (bullBreak) Bias.BULL else Bias.BEAR
        val ev = mutableListOf<Evidence>()
        var conf = 0.50

        ev += Evidence(
            if (bias == Bias.BULL) "شکست سقف رنج ۲۰ کندلی با کلوز کندل" else "شکست کف رنج ۲۰ کندلی با کلوز کندل",
            0.70
        )
        ev += Evidence("تایید حجم شکست (RVOL = ${(rvol * 10).toInt() / 10.0}x)", 0.65)

        if (recentSqueeze) {
            conf += 0.20
            ev += Evidence("خروج از فشردگی نوسان (Volatility Squeeze)", 0.75)
        }
        if (abs(last.c - last.o) >= 1.0 * atr) {
            conf += 0.10
            ev += Evidence("بدنه قدرتمند شکست (>= ۱ ATR)", 0.55)
        }
        if (ctx.htfBias == bias) {
            conf += 0.10
            ev += Evidence("هم‌جهت با تایم‌فریم بالاتر", 0.55)
        }

        val rawInv = if (bias == Bias.BULL) {
            kotlin.math.min(rangeMid, last.c - 1.5 * atr)
        } else {
            kotlin.math.max(rangeMid, last.c + 1.5 * atr)
        }

        return StyleVerdict(
            styleId = id,
            bias = bias,
            confidence = conf.coerceIn(0.0, 0.90),
            evidence = ev,
            keyLevels = levels,
            invalidation = Level(rawInv, "ابطال شکست رنج"),
            suitableRegimes = regimes
        )
    }
}
