package com.ta.core.prism

import com.ta.core.quant.BollTuple
import com.ta.core.quant.CoreQuantIndicatorsEngine
import com.ta.core.quant.MacdTuple

/**
 * Reuse facade over existing CoreQuantIndicatorsEngine so no indicator math is duplicated.
 */
object Ind {

    fun ema(x: DoubleArray, p: Int): DoubleArray =
        CoreQuantIndicatorsEngine.calcEmaSeries(x, p)

    fun sma(x: DoubleArray, p: Int): DoubleArray =
        CoreQuantIndicatorsEngine.calcSmaSeries(x, p)

    fun atr(c: List<Candle>, p: Int = 14): DoubleArray {
        val highs = DoubleArray(c.size) { c[it].h }
        val lows = DoubleArray(c.size) { c[it].l }
        val closes = DoubleArray(c.size) { c[it].c }
        return CoreQuantIndicatorsEngine.calcAtrWilderSeries(highs, lows, closes, p)
    }

    fun rsi(x: DoubleArray, p: Int = 14): DoubleArray =
        CoreQuantIndicatorsEngine.calcRsiWilderSeries(x, p)

    fun macd(x: DoubleArray, fast: Int = 12, slow: Int = 26, signal: Int = 9): Array<MacdTuple> =
        CoreQuantIndicatorsEngine.calcMacdSeries(x, fast, slow, signal)

    fun bollinger(
        x: DoubleArray,
        p: Int = 20,
        mult: Double = 2.0,
        percentileLookback: Int = 100
    ): Array<BollTuple> =
        CoreQuantIndicatorsEngine.calcBollingerSeries(x, p, mult, percentileLookback)

    /**
     * Causal Relative Volume: compares current candle volume against SMA of strictly prior N bars.
     */
    fun rvolPrior(c: List<Candle>, lookback: Int = 20): Double {
        if (c.size <= lookback) return 1.0
        val lastIdx = c.lastIndex
        var sum = 0.0
        for (i in (lastIdx - lookback) until lastIdx) sum += c[i].v
        val avg = sum / lookback.toDouble()
        return if (avg > 1e-9) c[lastIdx].v / avg else 1.0
    }

    fun atrPercentile(atrSeries: DoubleArray, lookback: Int = 100): Double {
        val lastIdx = atrSeries.lastIndex
        if (lastIdx < 0 || atrSeries[lastIdx].isNaN()) return 0.5
        val current = atrSeries[lastIdx]
        val start = kotlin.math.max(0, lastIdx - lookback + 1)
        val window = mutableListOf<Double>()
        for (i in start..lastIdx) {
            if (!atrSeries[i].isNaN()) window += atrSeries[i]
        }
        if (window.size < 2) return 0.5
        val strictlyLess = window.count { it < current }
        val equalCount = window.count { it == current }
        return (strictlyLess + 0.5 * equalCount) / window.size.toDouble()
    }
}
