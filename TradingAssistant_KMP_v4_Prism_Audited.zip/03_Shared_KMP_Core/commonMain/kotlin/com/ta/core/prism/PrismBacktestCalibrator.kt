package com.ta.core.prism

import kotlin.math.abs

data class ConfidenceCalibrationBucket(
    val label: String,
    val minConf: Double,
    val maxConf: Double,
    val tradeCount: Int,
    val avgDeclaredConfidence: Double,
    val actualWinRate: Double,
    val calibrationGap: Double // avgDeclaredConfidence - actualWinRate (+ means overconfident)
)

data class PrismCalibrationReport(
    val totalSignalsEvaluated: Int,
    val overallWinRate: Double,
    val profitFactor: Double,
    val expectancyR: Double,
    val expectedCalibrationError: Double,
    val isOverconfidentWarning: Boolean,
    val buckets: List<ConfidenceCalibrationBucket>,
    val performanceTable: BacktestPerformanceTable
)

/**
 * Pure, causal walk-forward backtester & confidence calibrator for Prism Engine:
 * 1. Evaluates each StyleAnalyzer per Regime to build BacktestPerformanceTable (feeding ConsensusEngine.perfWeight).
 * 2. Evaluates full PrismEngine signals and compares declared confidence vs realized win rate across buckets.
 * Strictly zero look-ahead: only closed bars up to index i and HTF bars with t <= ltf[i].t are visible.
 */
object PrismBacktestCalibrator {

    fun calibrate(
        ltfClosed: List<Candle>,
        htfClosed: List<Candle>,
        config: PrismConfig = PrismConfig(),
        analyzers: List<StyleAnalyzer> = PrismEngine.defaultAnalyzers(),
        riskProfile: PrismRiskProfile = PrismRiskProfile(symbol = "CALIBRATION"),
        warmupBars: Int = PrismEngine.MIN_RECOMMENDED_CANDLES,
        maxHoldBars: Int = 24,
        feeRoundTripR: Double = 0.05
    ): PrismCalibrationReport {
        if (ltfClosed.size <= warmupBars + 5) {
            return emptyReport()
        }

        val detector = RegimeDetector(config.regime)

        // 1) Per-style x per-regime accumulators
        val styleStats = mutableMapOf<Pair<String, Regime>, MutableList<Double>>()

        // 2) Full PrismEngine signal calibration samples: (declaredConfidence, rMultiple, isWin)
        val signalSamples = mutableListOf<Triple<Double, Double, Boolean>>()
        val engine = PrismEngine(config = config, analyzers = analyzers, snapshotLogger = NoOpPrismSnapshotLogger)

        var htfCursor = 0
        var activeTradeExitIdx = -1

        for (i in warmupBars until ltfClosed.lastIndex) {
            val curBar = ltfClosed[i]
            while (htfCursor + 1 < htfClosed.size && htfClosed[htfCursor + 1].t <= curBar.t) {
                htfCursor++
            }

            val ltfSlice = ltfClosed.subList(0, i + 1)
            val htfSlice = if (htfClosed.isNotEmpty() && htfClosed[0].t <= curBar.t) {
                htfClosed.subList(0, htfCursor + 1)
            } else {
                emptyList()
            }

            val ctx = detector.detect(MultiTF(ltfSlice, htfSlice))

            // A) Evaluate individual style verdicts for perfWeight calibration
            for (analyzer in analyzers) {
                val verdict = analyzer.analyze(ctx, ltfSlice)
                if (verdict.bias == Bias.NEUTRAL || verdict.invalidation == null) continue

                val entry = curBar.c
                val rawStop = verdict.invalidation.price
                val validSide = if (verdict.bias == Bias.BULL) rawStop < entry else rawStop > entry
                if (!validSide) continue

                val minStopDist = config.gate.minStopAtrMultiple * ctx.currentAtr
                val stop = if (verdict.bias == Bias.BULL) {
                    kotlin.math.min(rawStop, entry - minStopDist)
                } else {
                    kotlin.math.max(rawStop, entry + minStopDist)
                }
                val risk = abs(entry - stop)
                if (risk <= 1e-9) continue

                val tp = entry + verdict.bias.sign * risk * 2.0
                val outcomeR = simulateConservativeTrade(
                    candles = ltfClosed,
                    startIdx = i + 1,
                    maxHoldBars = maxHoldBars,
                    bias = verdict.bias,
                    entry = entry,
                    stop = stop,
                    tp = tp,
                    feeRoundTripR = feeRoundTripR
                )
                styleStats.getOrPut(analyzer.id to ctx.regime) { mutableListOf() }.add(outcomeR)
            }

            // B) Evaluate full PrismEngine signals (non-overlapping trades)
            if (i <= activeTradeExitIdx) continue
            val eval = engine.evaluate(
                symbol = riskProfile.symbol,
                timeframe = "CAL",
                candles = MultiTF(ltfSlice, htfSlice),
                riskProfile = riskProfile,
                emitTradeAlerts = false
            )
            val sig = eval.tradeResult as? TradeResult.Signal ?: continue
            val targetTp = sig.tps.getOrNull(1) ?: sig.tps.first()
            val (outcomeR, exitIdx) = simulateConservativeTradeWithExit(
                candles = ltfClosed,
                startIdx = i + 1,
                maxHoldBars = maxHoldBars,
                bias = sig.bias,
                entry = sig.entry,
                stop = sig.stop,
                tp = targetTp,
                feeRoundTripR = feeRoundTripR
            )
            activeTradeExitIdx = exitIdx
            signalSamples += Triple(sig.confidence, outcomeR, outcomeR > 0.0)
        }

        // Build BacktestPerformanceTable
        val perfRecords = styleStats.mapValues { (key, rs) ->
            val wins = rs.count { it > 0.0 }
            val grossWin = rs.filter { it > 0.0 }.sum()
            val grossLoss = abs(rs.filter { it < 0.0 }.sum())
            val pf = when {
                grossLoss > 1e-9 -> grossWin / grossLoss
                grossWin > 0.0 -> 3.0
                else -> 1.0
            }
            StyleRegimePerformance(
                styleId = key.first,
                regime = key.second,
                sampleCount = rs.size,
                winRate = if (rs.isNotEmpty()) wins.toDouble() / rs.size else 0.0,
                profitFactor = pf,
                expectancyR = if (rs.isNotEmpty()) rs.average() else 0.0
            )
        }
        val perfTable = BacktestPerformanceTable(perfRecords)

        // Build Confidence Calibration Buckets
        val bucketRanges = listOf(
            Triple("0.35 - 0.50", 0.35, 0.50),
            Triple("0.50 - 0.65", 0.50, 0.65),
            Triple("0.65 - 0.80", 0.65, 0.80),
            Triple("0.80 - 1.00", 0.80, 1.01)
        )
        val total = signalSamples.size
        var weightedEce = 0.0
        val buckets = bucketRanges.map { (label, lo, hi) ->
            val inBucket = signalSamples.filter { it.first >= lo && it.first < hi }
            if (inBucket.isEmpty()) {
                ConfidenceCalibrationBucket(label, lo, hi, 0, 0.0, 0.0, 0.0)
            } else {
                val avgConf = inBucket.map { it.first }.average()
                val winRate = inBucket.count { it.third }.toDouble() / inBucket.size
                val gap = avgConf - winRate
                if (total > 0) weightedEce += (inBucket.size.toDouble() / total) * abs(gap)
                ConfidenceCalibrationBucket(label, lo, hi, inBucket.size, avgConf, winRate, gap)
            }
        }

        val overallWins = signalSamples.count { it.third }
        val overallWinRate = if (total > 0) overallWins.toDouble() / total else 0.0
        val grossWin = signalSamples.filter { it.second > 0.0 }.sumOf { it.second }
        val grossLoss = abs(signalSamples.filter { it.second < 0.0 }.sumOf { it.second })
        val overallPf = when {
            grossLoss > 1e-9 -> grossWin / grossLoss
            grossWin > 0.0 -> 3.0
            else -> 0.0
        }
        val overallExpR = if (total > 0) signalSamples.map { it.second }.average() else 0.0
        val avgDeclaredAll = if (total > 0) signalSamples.map { it.first }.average() else 0.0
        val overconfident = total >= 10 && (avgDeclaredAll - overallWinRate) > 0.15

        return PrismCalibrationReport(
            totalSignalsEvaluated = total,
            overallWinRate = overallWinRate,
            profitFactor = overallPf,
            expectancyR = overallExpR,
            expectedCalibrationError = weightedEce,
            isOverconfidentWarning = overconfident,
            buckets = buckets,
            performanceTable = perfTable
        )
    }

    private fun simulateConservativeTrade(
        candles: List<Candle>,
        startIdx: Int,
        maxHoldBars: Int,
        bias: Bias,
        entry: Double,
        stop: Double,
        tp: Double,
        feeRoundTripR: Double
    ): Double = simulateConservativeTradeWithExit(
        candles, startIdx, maxHoldBars, bias, entry, stop, tp, feeRoundTripR
    ).first

    private fun simulateConservativeTradeWithExit(
        candles: List<Candle>,
        startIdx: Int,
        maxHoldBars: Int,
        bias: Bias,
        entry: Double,
        stop: Double,
        tp: Double,
        feeRoundTripR: Double
    ): Pair<Double, Int> {
        val risk = abs(entry - stop).coerceAtLeast(1e-9)
        val endIdx = kotlin.math.min(candles.lastIndex, startIdx + maxHoldBars - 1)
        for (j in startIdx..endIdx) {
            val bar = candles[j]
            if (bias == Bias.BULL) {
                // Conservative: check Stop Loss before Take Profit on same bar
                if (bar.l <= stop) return (-1.0 - feeRoundTripR) to j
                if (bar.h >= tp) return ((tp - entry) / risk - feeRoundTripR) to j
            } else {
                if (bar.h >= stop) return (-1.0 - feeRoundTripR) to j
                if (bar.l <= tp) return ((entry - tp) / risk - feeRoundTripR) to j
            }
        }
        val exitClose = candles[endIdx].c
        val rawR = ((exitClose - entry) * bias.sign) / risk
        return (rawR - feeRoundTripR) to endIdx
    }

    private fun emptyReport() = PrismCalibrationReport(
        totalSignalsEvaluated = 0,
        overallWinRate = 0.0,
        profitFactor = 0.0,
        expectancyR = 0.0,
        expectedCalibrationError = 0.0,
        isOverconfidentWarning = false,
        buckets = emptyList(),
        performanceTable = BacktestPerformanceTable()
    )
}
