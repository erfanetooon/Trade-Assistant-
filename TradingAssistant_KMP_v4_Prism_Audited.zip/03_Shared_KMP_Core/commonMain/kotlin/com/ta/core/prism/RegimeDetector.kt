package com.ta.core.prism

import kotlin.math.abs

/**
 * Deterministic RegimeDetector operating strictly on closed candles (no look-ahead).
 */
class RegimeDetector(private val cfg: RegimeConfig = RegimeConfig()) {

    fun detect(candles: MultiTF): MarketContext {
        val ltf = candles.ltf
        require(ltf.isNotEmpty()) { "LTF closed candles must not be empty" }

        val atrArr = Ind.atr(ltf, cfg.atrPeriod)
        val lastAtr = atrArr.lastOrNull()?.takeIf { !it.isNaN() && it > 0.0 }
            ?: (ltf.last().h - ltf.last().l).coerceAtLeast(1e-9)

        val volPercentile = Ind.atrPercentile(atrArr, cfg.atrPercentileLookback)

        val closes = DoubleArray(ltf.size) { ltf[it].c }
        val ema50 = Ind.ema(closes, cfg.trendEmaPeriod)
        val lastIdx = ltf.lastIndex
        val prevIdx = (lastIdx - cfg.trendSlopeLookback).coerceAtLeast(0)

        val emaSlopeAtrRatio = if (
            !ema50[lastIdx].isNaN() &&
            !ema50[prevIdx].isNaN() &&
            lastAtr > 0.0
        ) {
            abs(ema50[lastIdx] - ema50[prevIdx]) / lastAtr
        } else {
            0.0
        }

        val regime = when {
            volPercentile > cfg.volatileAtrPercentile -> Regime.VOLATILE
            emaSlopeAtrRatio > cfg.trendSlopeAtrThreshold -> Regime.TREND
            else -> Regime.RANGE
        }

        val htfBias = computeHtfBias(candles.htf)
        val session = resolveSessionUtc(ltf.last().t)

        return MarketContext(
            regime = regime,
            volPercentile = volPercentile,
            htfBias = htfBias,
            session = session,
            currentAtr = lastAtr
        )
    }

    /**
     * Computes 3-state HTF bias (BULL / BEAR / NEUTRAL) from closed HTF candles
     * using EMA50 slope + price position + confirmed 2-bar swing structure.
     */
    fun computeHtfBias(htfCandles: List<Candle>): Bias {
        if (htfCandles.size < cfg.trendEmaPeriod + cfg.trendSlopeLookback) return Bias.NEUTRAL

        val closes = DoubleArray(htfCandles.size) { htfCandles[it].c }
        val ema50 = Ind.ema(closes, cfg.trendEmaPeriod)
        val lastIdx = htfCandles.lastIndex
        val prevIdx = lastIdx - cfg.trendSlopeLookback
        val lastEma = ema50[lastIdx]
        val prevEma = ema50[prevIdx]
        if (lastEma.isNaN() || prevEma.isNaN()) return Bias.NEUTRAL

        val lastClose = htfCandles[lastIdx].c
        val emaBull = lastClose > lastEma && lastEma > prevEma
        val emaBear = lastClose < lastEma && lastEma < prevEma

        // Confirmed 2-bar fractal swings on closed HTF candles
        val n = 2
        val highs = mutableListOf<Double>()
        val lows = mutableListOf<Double>()
        for (i in n until htfCandles.size - n) {
            val c = htfCandles[i]
            if ((1..n).all { c.h > htfCandles[i - it].h && c.h > htfCandles[i + it].h }) highs += c.h
            if ((1..n).all { c.l < htfCandles[i - it].l && c.l < htfCandles[i + it].l }) lows += c.l
        }

        val structBull = highs.size >= 2 && lows.size >= 2 &&
            highs[highs.lastIndex] > highs[highs.lastIndex - 1] &&
            lows[lows.lastIndex] > lows[lows.lastIndex - 1]
        val structBear = highs.size >= 2 && lows.size >= 2 &&
            highs[highs.lastIndex] < highs[highs.lastIndex - 1] &&
            lows[lows.lastIndex] < lows[lows.lastIndex - 1]

        return when {
            emaBull && structBull -> Bias.BULL
            emaBear && structBear -> Bias.BEAR
            emaBull && !structBear -> Bias.BULL
            emaBear && !structBull -> Bias.BEAR
            else -> Bias.NEUTRAL
        }
    }

    private fun resolveSessionUtc(epochMs: Long): MarketSession {
        val secondsInDay = ((epochMs / 1000L) % 86400L + 86400L) % 86400L
        val hourUtc = (secondsInDay / 3600L).toInt()
        return when (hourUtc) {
            in 0..6 -> MarketSession.ASIA
            in 7..12 -> MarketSession.LONDON
            in 13..16 -> MarketSession.OVERLAP_LDN_NY
            else -> MarketSession.NEW_YORK
        }
    }
}
