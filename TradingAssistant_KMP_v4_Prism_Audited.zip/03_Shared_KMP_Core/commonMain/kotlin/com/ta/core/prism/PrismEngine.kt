package com.ta.core.prism

import com.ta.core.live.AlertCategory
import com.ta.core.live.AlertPriority
import com.ta.core.live.SmartAlertEvent
import com.ta.core.quant.BarNode

data class PrismSignalSnapshotRecord(
    val snapshotId: String,
    val symbol: String,
    val timeframe: String,
    val barOpenTimeMs: Long,
    val regime: Regime,
    val volPercentile: Double,
    val htfBias: Bias,
    val session: MarketSession,
    val consensusBias: Bias,
    val consensusConfidence: Double,
    val consensusAgreement: Double,
    val conflictsSerialized: String,
    val verdictsSerialized: String,
    val resultType: String, // "SIGNAL" or "NO_TRADE"
    val noTradeReason: String?,
    val entryPrice: Double?,
    val stopPrice: Double?,
    val tp1Price: Double?,
    val tp2Price: Double?,
    val tp3Price: Double?,
    val rr: Double?,
    val recommendedQty: Double?,
    val expiresAtMs: Long?,
    val configVersion: String,
    val createdAtEpochSec: Long
)

interface PrismSnapshotLogger {
    fun logSnapshot(record: PrismSignalSnapshotRecord)
    fun loadSnapshots(symbol: String): List<PrismSignalSnapshotRecord>
}

object NoOpPrismSnapshotLogger : PrismSnapshotLogger {
    override fun logSnapshot(record: PrismSignalSnapshotRecord) = Unit
    override fun loadSnapshots(symbol: String): List<PrismSignalSnapshotRecord> = emptyList()
}

class InMemoryPrismSnapshotLogger : PrismSnapshotLogger {
    private val logs = mutableListOf<PrismSignalSnapshotRecord>()

    override fun logSnapshot(record: PrismSignalSnapshotRecord) {
        logs += record
    }

    override fun loadSnapshots(symbol: String): List<PrismSignalSnapshotRecord> =
        logs.filter { it.symbol == symbol }

    fun allSnapshots(): List<PrismSignalSnapshotRecord> = logs.toList()
}

data class PrismEvaluationOutput(
    val context: MarketContext,
    val consensus: ConsensusResult,
    val analysisReport: AnalysisReport,
    val tradeResult: TradeResult,
    val snapshotRecord: PrismSignalSnapshotRecord,
    val alertEvent: SmartAlertEvent?,
    val hasSufficientHistory: Boolean
)

/**
 * Master Prism Engine facade:
 * - Strictly offline, pure & deterministic.
 * - Filters strictly to closed candles (zero look-ahead).
 * - Requires >= 250 closed candles for full warmup (ClassicTaStyle intentionally stays NEUTRAL below 220).
 * - Logs every evaluation snapshot for SQLDelight replay & backtest calibration.
 */
class PrismEngine(
    private val config: PrismConfig = PrismConfig(),
    private val analyzers: List<StyleAnalyzer> = defaultAnalyzers(),
    private val perfWeightProvider: (styleId: String, regime: Regime) -> Double = { _, _ -> 1.0 },
    private val snapshotLogger: PrismSnapshotLogger = InMemoryPrismSnapshotLogger(),
    private val configVersion: String = "prism_v1"
) {
    private val regimeDetector = RegimeDetector(config.regime)
    private val consensusEngine = ConsensusEngine(config.consensus, perfWeightProvider)
    private val analysisRenderer = AnalysisRenderer()
    private val tradeRenderer = TradeRenderer(config.gate)

    fun evaluateBarNodes(
        symbol: String,
        timeframe: String,
        rawLtfBars: List<BarNode>,
        rawHtfBars: List<BarNode>,
        riskProfile: PrismRiskProfile,
        previouslyEmittedAlertKeys: Set<String> = emptySet(),
        emitTradeAlerts: Boolean = true
    ): PrismEvaluationOutput? {
        val closedLtf = rawLtfBars.filter { it.closed }.map { Candle.fromBarNode(it) }
        val closedHtf = rawHtfBars.filter { it.closed }.map { Candle.fromBarNode(it) }
        if (closedLtf.isEmpty()) return null

        return evaluate(
            symbol = symbol,
            timeframe = timeframe,
            candles = MultiTF(ltf = closedLtf, htf = closedHtf),
            riskProfile = riskProfile,
            previouslyEmittedAlertKeys = previouslyEmittedAlertKeys,
            emitTradeAlerts = emitTradeAlerts
        )
    }

    fun evaluate(
        symbol: String,
        timeframe: String,
        candles: MultiTF,
        riskProfile: PrismRiskProfile,
        previouslyEmittedAlertKeys: Set<String> = emptySet(),
        emitTradeAlerts: Boolean = true
    ): PrismEvaluationOutput {
        val ltf = candles.ltf
        require(ltf.isNotEmpty()) { "Closed LTF candles must not be empty" }

        val hasSufficientHistory = ltf.size >= MIN_RECOMMENDED_CANDLES
        val ctx = regimeDetector.detect(candles)
        val verdicts = analyzers.map { it.analyze(ctx, ltf) }
        val consensus = consensusEngine.run(ctx, verdicts)
        val last = ltf.last()

        val analysisReport = analysisRenderer.render(ctx, consensus, last)
        val tradeResult = tradeRenderer.render(ctx, consensus, last, riskProfile)

        val snapshotRecord = buildSnapshotRecord(
            symbol = symbol,
            timeframe = timeframe,
            last = last,
            ctx = ctx,
            consensus = consensus,
            tradeResult = tradeResult
        )
        snapshotLogger.logSnapshot(snapshotRecord)

        val alertEvent = if (emitTradeAlerts && tradeResult is TradeResult.Signal) {
            val dedupKey = "PRISM_${symbol}_${timeframe}_${last.t}_${tradeResult.bias.name}"
            if (dedupKey !in previouslyEmittedAlertKeys) {
                SmartAlertEvent(
                    alertId = snapshotRecord.snapshotId,
                    timestampEpochSec = last.t / 1000L,
                    symbol = symbol,
                    timeframe = timeframe,
                    category = AlertCategory.COMPANION_SIGNAL_READY,
                    priority = AlertPriority.CRITICAL_EXECUTION_TRIGGER,
                    headlineCode = "PRISM_${tradeResult.bias.name}_SIGNAL",
                    referencePrice = tradeResult.entry,
                    targetLevelPrice = tradeResult.tps.firstOrNull() ?: tradeResult.entry,
                    deduplicationKey = dedupKey
                )
            } else null
        } else null

        return PrismEvaluationOutput(
            context = ctx,
            consensus = consensus,
            analysisReport = analysisReport,
            tradeResult = tradeResult,
            snapshotRecord = snapshotRecord,
            alertEvent = alertEvent,
            hasSufficientHistory = hasSufficientHistory
        )
    }

    private fun buildSnapshotRecord(
        symbol: String,
        timeframe: String,
        last: Candle,
        ctx: MarketContext,
        consensus: ConsensusResult,
        tradeResult: TradeResult
    ): PrismSignalSnapshotRecord {
        val snapshotId = "prism_${symbol}_${timeframe}_${last.t}"
        val verdictsSummary = consensus.verdicts.joinToString("|") { v ->
            "${v.styleId}:${v.bias.name}:${(v.confidence * 1000).toInt() / 1000.0}"
        }
        val conflictsSummary = consensus.conflicts.joinToString("|")

        return when (tradeResult) {
            is TradeResult.Signal -> PrismSignalSnapshotRecord(
                snapshotId = snapshotId,
                symbol = symbol,
                timeframe = timeframe,
                barOpenTimeMs = last.t,
                regime = ctx.regime,
                volPercentile = ctx.volPercentile,
                htfBias = ctx.htfBias,
                session = ctx.session,
                consensusBias = consensus.bias,
                consensusConfidence = consensus.confidence,
                consensusAgreement = consensus.agreement,
                conflictsSerialized = conflictsSummary,
                verdictsSerialized = verdictsSummary,
                resultType = "SIGNAL",
                noTradeReason = null,
                entryPrice = tradeResult.entry,
                stopPrice = tradeResult.stop,
                tp1Price = tradeResult.tps.getOrNull(0),
                tp2Price = tradeResult.tps.getOrNull(1),
                tp3Price = tradeResult.tps.getOrNull(2),
                rr = tradeResult.rr,
                recommendedQty = tradeResult.recommendedQty,
                expiresAtMs = tradeResult.expiresAt,
                configVersion = configVersion,
                createdAtEpochSec = last.t / 1000L
            )
            is TradeResult.NoTrade -> PrismSignalSnapshotRecord(
                snapshotId = snapshotId,
                symbol = symbol,
                timeframe = timeframe,
                barOpenTimeMs = last.t,
                regime = ctx.regime,
                volPercentile = ctx.volPercentile,
                htfBias = ctx.htfBias,
                session = ctx.session,
                consensusBias = consensus.bias,
                consensusConfidence = consensus.confidence,
                consensusAgreement = consensus.agreement,
                conflictsSerialized = conflictsSummary,
                verdictsSerialized = verdictsSummary,
                resultType = "NO_TRADE",
                noTradeReason = tradeResult.reason,
                entryPrice = null,
                stopPrice = null,
                tp1Price = null,
                tp2Price = null,
                tp3Price = null,
                rr = null,
                recommendedQty = null,
                expiresAtMs = null,
                configVersion = configVersion,
                createdAtEpochSec = last.t / 1000L
            )
        }
    }

    companion object {
        const val MIN_RECOMMENDED_CANDLES: Int = 250

        fun defaultAnalyzers(): List<StyleAnalyzer> = listOf(
            PriceActionStyle(),
            ClassicTaStyle(),
            MomentumMeanReversionStyle(),
            VolumeStyle(),
            BreakoutVolatilityStyle()
        )
    }
}
