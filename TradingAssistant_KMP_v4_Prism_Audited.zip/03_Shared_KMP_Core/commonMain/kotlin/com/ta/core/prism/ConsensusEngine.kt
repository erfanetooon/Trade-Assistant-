package com.ta.core.prism

import com.ta.core.backtest.BacktestResult
import kotlin.math.abs

data class StyleRegimePerformance(
    val styleId: String,
    val regime: Regime,
    val sampleCount: Int,
    val winRate: Double,      // 0.0 .. 1.0
    val profitFactor: Double,
    val expectancyR: Double
)

/**
 * Feeds ConsensusEngine.perfWeight(styleId, regime) from BacktestAndEvaluatorEngine outputs.
 * When sampleCount < cfg.minPerformanceSamples, defaults safely to 1.0.
 */
class BacktestPerformanceTable(
    private val records: Map<Pair<String, Regime>, StyleRegimePerformance> = emptyMap()
) {
    fun weightFor(styleId: String, regime: Regime, cfg: ConsensusConfig = ConsensusConfig()): Double {
        val perf = records[styleId to regime] ?: return 1.0
        if (perf.sampleCount < cfg.minPerformanceSamples) return 1.0

        // Combine out-of-sample expectancy and profit factor into a bounded multiplier [0.5 .. 1.5]
        val pfComponent = when {
            perf.profitFactor >= 1.8 -> 1.25
            perf.profitFactor >= 1.3 -> 1.10
            perf.profitFactor >= 1.0 -> 1.00
            perf.profitFactor >= 0.75 -> 0.80
            else -> 0.55
        }
        val expAdjust = (perf.expectancyR * 0.25).coerceIn(-0.25, 0.25)
        return (pfComponent + expAdjust).coerceIn(cfg.minPerfMultiplier, cfg.maxPerfMultiplier)
    }

    fun asWeightProvider(cfg: ConsensusConfig = ConsensusConfig()): (String, Regime) -> Double =
        { styleId, regime -> weightFor(styleId, regime, cfg) }

    companion object {
        fun fromBacktestResults(
            results: Map<Pair<String, Regime>, BacktestResult>
        ): BacktestPerformanceTable {
            val mapped = results.mapValues { (key, res) ->
                // Prefer out-of-sample metrics when available to avoid overfitted weights
                val seg = res.outOfSampleSummary
                val trades = seg?.totalTrades ?: res.totalTrades
                val winRatePct = seg?.winRatePct ?: res.winRatePct
                val pf = seg?.profitFactor ?: res.profitFactor
                val expR = seg?.expectancyR ?: res.expectancyR
                StyleRegimePerformance(
                    styleId = key.first,
                    regime = key.second,
                    sampleCount = trades,
                    winRate = (winRatePct / 100.0).coerceIn(0.0, 1.0),
                    profitFactor = pf,
                    expectancyR = expR
                )
            }
            return BacktestPerformanceTable(mapped)
        }
    }
}

/**
 * Consensus Core:
 * - Weight per style = regimeFit (1.0 or cfg.nonSuitableRegimeWeight) * perfWeight(styleId, regime).
 * - Computes weighted directional score, agreementScore, conflicts/vetoes, and contributingStyles.
 * - Strictly pure and deterministic.
 */
class ConsensusEngine(
    private val cfg: ConsensusConfig = ConsensusConfig(),
    private val perfWeight: (styleId: String, regime: Regime) -> Double = { _, _ -> 1.0 }
) {
    fun run(ctx: MarketContext, verdicts: List<StyleVerdict>): ConsensusResult {
        if (verdicts.isEmpty()) {
            return ConsensusResult(
                bias = Bias.NEUTRAL,
                confidence = 0.0,
                agreement = 0.0,
                conflicts = emptyList(),
                verdicts = emptyList(),
                contributingStyles = emptyList()
            )
        }

        val weights = verdicts.associateWith { verdict ->
            val regimeFit = if (ctx.regime in verdict.suitableRegimes) 1.0 else cfg.nonSuitableRegimeWeight
            val perf = perfWeight(verdict.styleId, ctx.regime)
                .takeIf { !it.isNaN() && it > 0.0 }
                ?.coerceIn(cfg.minPerfMultiplier, cfg.maxPerfMultiplier)
                ?: 1.0
            regimeFit * perf
        }

        val totalW = weights.values.sum().takeIf { it > 0.0 } ?: 1.0
        val rawScore = verdicts.sumOf { v ->
            val cleanConf = v.confidence.takeIf { !it.isNaN() }?.coerceIn(0.0, 1.0) ?: 0.0
            weights.getValue(v) * cleanConf * v.bias.sign
        } / totalW

        val bias = when {
            rawScore > cfg.biasThreshold -> Bias.BULL
            rawScore < -cfg.biasThreshold -> Bias.BEAR
            else -> Bias.NEUTRAL
        }

        val agreement = if (bias == Bias.NEUTRAL) {
            0.0
        } else {
            val agreeW = verdicts.filter { it.bias == bias }.sumOf { weights.getValue(it) }
            (agreeW / totalW).coerceIn(0.0, 1.0)
        }

        val conflicts = buildList {
            if (verdicts.any { it.bias == Bias.BULL } && verdicts.any { it.bias == Bias.BEAR }) {
                add("اختلاف جهت بین سبک‌ها")
            }
            if (bias != Bias.NEUTRAL && ctx.htfBias != Bias.NEUTRAL && ctx.htfBias != bias) {
                add("خلاف جهت تایم‌فریم بالاتر")
            }
            if (ctx.regime == Regime.VOLATILE && ctx.volPercentile > 0.95) {
                add("نوسان بیش‌ازحد بازار (ریسک اسپایک)")
            }
        }

        val contributing = if (bias == Bias.NEUTRAL) {
            emptyList()
        } else {
            verdicts
                .filter { it.bias == bias }
                .sortedByDescending { weights.getValue(it) * it.confidence }
                .map { it.styleId }
        }

        return ConsensusResult(
            bias = bias,
            confidence = abs(rawScore).coerceIn(0.0, 1.0),
            agreement = agreement,
            conflicts = conflicts,
            verdicts = verdicts,
            contributingStyles = contributing
        )
    }
}
