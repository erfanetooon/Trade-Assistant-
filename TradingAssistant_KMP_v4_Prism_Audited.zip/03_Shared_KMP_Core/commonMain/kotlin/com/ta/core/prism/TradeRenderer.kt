package com.ta.core.prism

import com.tradingassistant.core.risk.MarketType
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import com.tradingassistant.core.risk.TradeDirection
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class RiskGateDecision(
    val allowed: Boolean,
    val recommendedQty: Double = 0.0,
    val netRrTp2: Double? = null,
    val rejectionReason: String? = null
)

data class PrismRiskProfile(
    val symbol: String,
    val marketType: MarketType = MarketType.FUTURES,
    val totalCapitalUsdt: Double = 1000.0,
    val baseRiskPct: Double = 1.0,
    val requestedLeverage: Int = 3,
    val maxAllowedLeverage: Int = 5,
    val openPositionsRiskUsdt: Double = 0.0,
    val openPositionsCount: Int = 0,
    val maxConcurrentPositions: Int = 3,
    val todayRealizedLossUsdt: Double = 0.0,
    val consecutiveLossesCount: Int = 0,
    val cooldownUntilEpochSec: Long = 0L
)

/**
 * Adapter connecting Prism TradeRenderer directly to the existing RiskAndPsychologyEngine.
 */
object PrismRiskAdapter {

    fun evaluate(
        profile: PrismRiskProfile,
        bias: Bias,
        entry: Double,
        stop: Double,
        tp1: Double,
        tp2: Double?,
        currentEpochSec: Long
    ): RiskGateDecision {
        val direction = if (bias == Bias.BULL) TradeDirection.LONG else TradeDirection.SHORT
        val sizing = RiskAndPsychologyEngine.calculatePositionSize(
            PositionSizingInput(
                symbol = profile.symbol,
                marketType = profile.marketType,
                direction = direction,
                totalCapitalUsdt = profile.totalCapitalUsdt,
                baseRiskPct = profile.baseRiskPct,
                entryPrice = entry,
                currentMarkPrice = entry,
                stopLossPrice = stop,
                takeProfit1Price = tp1,
                takeProfit2Price = tp2,
                requestedLeverage = profile.requestedLeverage,
                maxAllowedLeverage = profile.maxAllowedLeverage,
                openPositionsRiskUsdt = profile.openPositionsRiskUsdt,
                openPositionsCount = profile.openPositionsCount,
                maxConcurrentPositions = profile.maxConcurrentPositions,
                todayRealizedLossUsdt = profile.todayRealizedLossUsdt,
                consecutiveLossesCount = profile.consecutiveLossesCount,
                cooldownUntilEpochSec = profile.cooldownUntilEpochSec,
                currentEpochSec = currentEpochSec
            )
        )
        return RiskGateDecision(
            allowed = sizing.isAllowed,
            recommendedQty = sizing.recommendedQuantityCoin,
            netRrTp2 = sizing.netRewardToRiskTp2,
            rejectionReason = sizing.rejectionReason
        )
    }
}

/**
 * Mode Renderer 2: TradeMode (Strict Gate-Protected Signal Generator)
 *
 * Fixes applied over reference:
 * 1. SL prioritizes PriceAction structural invalidation (fallback: nearest valid invalidation),
 *    and enforces minimum distance >= cfg.minStopAtrMultiple * ATR (default 1.0 ATR) from entry.
 * 2. TPs are derived from real key levels (swings / EMAs / Volume Profile / Bollinger) in the
 *    profit direction, with progressive structural fallback when in price discovery.
 * 3. RR is computed dynamically from real TP levels (hardcoded rr = 2.5 removed).
 * 4. Validates against existing RiskAndPsychologyEngine and returns recommendedQty.
 */
class TradeRenderer(private val cfg: GateConfig = GateConfig()) {

    fun render(
        ctx: MarketContext,
        r: ConsensusResult,
        last: Candle,
        riskProfile: PrismRiskProfile
    ): TradeResult = renderWithRiskEvaluator(ctx, r, last) { bias, entry, stop, tp1, tp2 ->
        PrismRiskAdapter.evaluate(
            profile = riskProfile,
            bias = bias,
            entry = entry,
            stop = stop,
            tp1 = tp1,
            tp2 = tp2,
            currentEpochSec = last.t / 1000L
        )
    }

    fun renderWithRiskEvaluator(
        ctx: MarketContext,
        r: ConsensusResult,
        last: Candle,
        riskEvaluator: (bias: Bias, entry: Double, stop: Double, tp1: Double, tp2: Double?) -> RiskGateDecision
    ): TradeResult {
        // Gate 1: Directional bias must be clear
        if (r.bias == Bias.NEUTRAL) return TradeResult.NoTrade("جهت مشخص نیست")

        // Gate 2: Regime must be allowed
        if (ctx.regime !in cfg.allowedRegimes) return TradeResult.NoTrade("رژیم بازار مجاز نیست")

        // Gate 3: No active conflicts or HTF/volatility vetoes
        if (cfg.vetoOnConflicts && r.conflicts.isNotEmpty()) {
            return TradeResult.NoTrade(r.conflicts.first())
        }

        // Gate 4: Minimum consensus confidence
        if (r.confidence < cfg.minConfidence) return TradeResult.NoTrade("اطمینان اجماع کم است")

        // Gate 5: Minimum agreement score
        if (r.agreement < cfg.minAgreement) return TradeResult.NoTrade("همنظری سبک‌ها کم است")

        // Gate 6: Minimum number of agreeing styles (regime-aware for RANGE)
        val agreeing = r.verdicts.filter { it.bias == r.bias }
        val requiredStyles = if (ctx.regime == Regime.RANGE) min(cfg.minStyles, cfg.minStylesRange) else cfg.minStyles
        if (agreeing.size < requiredStyles) return TradeResult.NoTrade("تعداد سبک‌های همنظر کافی نیست")

        val atr = ctx.currentAtr.takeIf { !it.isNaN() && it > 0.0 }
            ?: return TradeResult.NoTrade("مقدار ATR معتبر نیست")

        val entry = last.c
        val dir = r.bias.sign
        val entryZoneLow = entry - 0.15 * atr
        val entryZoneHigh = entry + 0.15 * atr

        // Structural Stop Loss: prefer PriceAction invalidation, fallback to nearest valid invalidation
        val paInv = agreeing
            .firstOrNull { it.styleId == "price_action" }
            ?.invalidation?.price
            ?.takeIf { if (r.bias == Bias.BULL) it < entry else it > entry }

        val validStops = agreeing
            .mapNotNull { it.invalidation?.price }
            .filter { if (r.bias == Bias.BULL) it < entry else it > entry }

        val rawStop = paInv ?: when {
            validStops.isEmpty() -> return TradeResult.NoTrade("نقطه ابطال ساختاری معتبر نیست")
            r.bias == Bias.BULL -> validStops.max()
            else -> validStops.min()
        }

        // Enforce minimum distance >= cfg.minStopAtrMultiple * ATR (default 1.0 ATR)
        val minStopDist = cfg.minStopAtrMultiple * atr
        val stop = if (r.bias == Bias.BULL) {
            min(rawStop, entry - minStopDist)
        } else {
            max(rawStop, entry + minStopDist)
        }

        val risk = abs(entry - stop)
        if (risk <= 1e-9) return TradeResult.NoTrade("ریسک نامعتبر است")

        // Take Profits from real key levels (swings / EMA / VP / Bollinger), with structural fallback
        val tps = buildKeyLevelTargets(r.verdicts, r.bias, entry, risk)
        val tp1 = tps[0]
        val tp2 = tps[1]

        // Real RR computed from actual TP2 (primary swing target) and checked against GateConfig.minRR
        val realRr = abs(tp2 - entry) / risk
        if (realRr < cfg.minRR) return TradeResult.NoTrade("نسبت RR واقعی کمتر از حد مجاز است")

        // Gate 7: Existing RiskAndPsychologyEngine approval + net-after-fee RR + position sizing
        val riskDecision = riskEvaluator(r.bias, entry, stop, tp1, tp2)
        if (!riskDecision.allowed) {
            return TradeResult.NoTrade(riskDecision.rejectionReason ?: "رد شده توسط مدیریت ریسک")
        }
        val effectiveRr = riskDecision.netRrTp2 ?: realRr
        if (effectiveRr < cfg.minRR) return TradeResult.NoTrade("نسبت RR خالص (پس از کارمزد) کمتر از حد مجاز است")

        val reasons = agreeing
            .flatMap { it.evidence }
            .sortedByDescending { it.weight }
            .map { it.text }
            .distinct()
            .take(5)

        return TradeResult.Signal(
            bias = r.bias,
            entryZoneLow = entryZoneLow,
            entryZoneHigh = entryZoneHigh,
            entry = entry,
            stop = stop,
            tps = tps,
            rr = effectiveRr,
            recommendedQty = riskDecision.recommendedQty,
            confidence = r.confidence,
            reasons = reasons,
            expiresAt = last.t + cfg.signalTtlMs
        )
    }

    private fun buildKeyLevelTargets(
        verdicts: List<StyleVerdict>,
        bias: Bias,
        entry: Double,
        risk: Double
    ): List<Double> {
        val dir = bias.sign
        val minFirstTargetDist = 1.0 * risk
        val minStepGap = 0.5 * risk

        val candidates = verdicts
            .flatMap { it.keyLevels }
            .map { it.price }
            .filter { !it.isNaN() && it > 0.0 }
            .filter { p ->
                val dist = (p - entry) * dir
                dist >= minFirstTargetDist
            }
            .sortedBy { abs(it - entry) }

        val picked = mutableListOf<Double>()
        for (lvl in candidates) {
            if (picked.isEmpty() || abs(lvl - picked.last()) >= minStepGap) {
                picked += lvl
            }
            if (picked.size == 3) break
        }

        // Fill missing targets structurally only when price is in discovery beyond known levels
        val fallbackMultiples = listOf(1.5, 2.5, 4.0)
        while (picked.size < 3) {
            val idx = picked.size
            val candidate = if (picked.isEmpty()) {
                entry + dir * risk * fallbackMultiples[idx]
            } else {
                val nextMin = picked.last() + dir * risk * 1.0
                val standard = entry + dir * risk * fallbackMultiples[idx]
                if (dir > 0) max(nextMin, standard) else min(nextMin, standard)
            }
            picked += candidate
        }

        return picked
    }
}
