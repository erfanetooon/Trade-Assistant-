package com.ta.core.backtest

import com.ta.core.quant.BarNode
import com.ta.core.structure.WyckoffRangeState
import com.ta.core.synthesis.StrategyConfigRequest
import com.ta.core.synthesis.StrategySynthesizerEngine
import com.tradingassistant.core.risk.MarketType
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import com.tradingassistant.core.risk.TradeDirection
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

data class ScoreBucketMetrics(
    val bucketLabel: String,
    val tradeCount: Int,
    val winRatePct: Double,
    val expectancyR: Double
)

data class BacktestSegmentSummary(
    val totalTrades: Int,
    val winRatePct: Double,
    val profitFactor: Double,
    val expectancyR: Double,
    val maxDrawdownPct: Double,
    val netReturnPct: Double
)

data class BacktestTradeRecord(
    val setupId: String,
    val strategyComboId: String,
    val direction: TradeDirection,
    val confluenceScore: Double,
    val entryBarIdx: Int,
    val exitBarIdx: Int,
    val entryPrice: Double,
    val exitPrice: Double,
    val feesAndFundingUsdt: Double,
    val netPnlUsdt: Double,
    val isWin: Boolean,
    val rMultiple: Double
)

data class BacktestResult(
    val statusCode: String,
    val strategyComboId: String,
    val totalTrades: Int,
    val winRatePct: Double,
    val profitFactor: Double,
    val expectancyR: Double,
    val maxDrawdownPct: Double,
    val netReturnPct: Double,
    val deflatedSharpeRatio: Double,
    val statisticalConfidencePct: Double,
    val isOverfittedWarning: Boolean,
    val inSampleSummary: BacktestSegmentSummary?,
    val outOfSampleSummary: BacktestSegmentSummary?,
    val scoreBuckets: List<ScoreBucketMetrics>
)

object BacktestAndEvaluatorEngine {

    fun runWalkForwardBacktest(
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        config: StrategyConfigRequest,
        riskTemplate: PositionSizingInput,
        numTrialsTested: Int = 1,
        inSampleSplitRatio: Double = 0.70,
        hoursPerBar: Double = 0.25,
        maxHoldBars: Int = 40
    ): BacktestResult {
        val closedLtf = ltfBars.filter { it.closed }
        val closedHtf = htfBars.filter { it.closed }
        val n = closedLtf.size
        val defaultCombo = config.userSelectedModules.map { it.name }.sorted().joinToString("+")

        if (n < 220 || closedHtf.size < 210) {
            return emptyResult("INSUFFICIENT_HISTORY", defaultCombo)
        }

        val initialCapital = max(100.0, riskTemplate.totalCapitalUsdt)
        var equity = initialCapital
        var peakEquity = initialCapital
        var maxDdPct = 0.0

        val trades = mutableListOf<BacktestTradeRecord>()
        val emittedSetups = HashSet<String>()
        var lastWyckoffState: WyckoffRangeState? = null
        var lastComboId = defaultCombo

        var i = 210
        while (i < n - 2) {
            val ltfSlice = closedLtf.subList(0, i + 1)
            val currentTs = closedLtf[i].t
            val htfSlice = closedHtf.filter { it.t <= currentTs }
            if (htfSlice.size < 210) {
                i++
                continue
            }

            val stepRisk = riskTemplate.copy(
                totalCapitalUsdt = equity,
                currentMarkPrice = closedLtf[i].c,
                currentEpochSec = if (currentTs > 10_000_000_000L) currentTs / 1000L else currentTs
            )

            val res = StrategySynthesizerEngine.executeSynthesisResult(
                ltfBars = ltfSlice,
                htfBars = htfSlice,
                config = config,
                riskTemplate = stepRisk,
                previousLtfWyckoff = lastWyckoffState,
                activeSetupIds = emittedSetups
            )

            val rep = res.report
            if (rep == null) {
                i++
                continue
            }
            lastWyckoffState = rep.assistantReport.wyckoffRangeState
            val sig = rep.companionSignal
            lastComboId = sig.strategyComboId

            if (!sig.isSignalActive || sig.direction == null || sig.riskPositionSizing == null) {
                i++
                continue
            }

            emittedSetups.add(sig.setupId)

            val entryIdx = i + 1
            val rawEntry = closedLtf[entryIdx].o
            val slip = riskTemplate.estimatedSlippagePct
            val fillEntry = if (sig.direction == TradeDirection.LONG) rawEntry * (1.0 + slip) else rawEntry * (1.0 - slip)

            var activeSl = sig.stopLossPrice
            val tp1 = sig.takeProfit1Price
            val tp2 = sig.takeProfit2Price
            val qtyTotal = sig.riskPositionSizing.recommendedQuantityCoin
            val riskDollars = max(1e-8, sig.riskPositionSizing.exactDollarAtRiskUsdt)

            if ((sig.direction == TradeDirection.LONG && activeSl >= fillEntry) ||
                (sig.direction == TradeDirection.SHORT && activeSl <= fillEntry) ||
                qtyTotal <= 0.0
            ) {
                i++
                continue
            }

            var remainingQty = qtyTotal
            var tp1Filled = false
            var realizedGrossUsdt = 0.0
            var totalFeesUsdt = fillEntry * qtyTotal * riskTemplate.takerFeeRate
            var exitIdx = min(n - 1, entryIdx + maxHoldBars)
            var weightedExitPriceSum = 0.0

            for (k in entryIdx..min(n - 1, entryIdx + maxHoldBars)) {
                val b = closedLtf[k]
                if (sig.direction == TradeDirection.LONG) {
                    if (b.l <= activeSl) {
                        val exitFill = activeSl * (1.0 - slip)
                        realizedGrossUsdt += (exitFill - fillEntry) * remainingQty
                        totalFeesUsdt += exitFill * remainingQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += exitFill * remainingQty
                        remainingQty = 0.0
                        exitIdx = k
                        break
                    }
                    if (!tp1Filled && b.h >= tp1) {
                        val halfQty = remainingQty * 0.5
                        val tp1Fill = tp1 * (1.0 - slip)
                        realizedGrossUsdt += (tp1Fill - fillEntry) * halfQty
                        totalFeesUsdt += tp1Fill * halfQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += tp1Fill * halfQty
                        remainingQty -= halfQty
                        tp1Filled = true
                        activeSl = max(activeSl, fillEntry)
                    }
                    if (tp1Filled && b.h >= tp2) {
                        val tp2Fill = tp2 * (1.0 - slip)
                        realizedGrossUsdt += (tp2Fill - fillEntry) * remainingQty
                        totalFeesUsdt += tp2Fill * remainingQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += tp2Fill * remainingQty
                        remainingQty = 0.0
                        exitIdx = k
                        break
                    }
                } else {
                    if (b.h >= activeSl) {
                        val exitFill = activeSl * (1.0 + slip)
                        realizedGrossUsdt += (fillEntry - exitFill) * remainingQty
                        totalFeesUsdt += exitFill * remainingQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += exitFill * remainingQty
                        remainingQty = 0.0
                        exitIdx = k
                        break
                    }
                    if (!tp1Filled && b.l <= tp1) {
                        val halfQty = remainingQty * 0.5
                        val tp1Fill = tp1 * (1.0 + slip)
                        realizedGrossUsdt += (fillEntry - tp1Fill) * halfQty
                        totalFeesUsdt += tp1Fill * halfQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += tp1Fill * halfQty
                        remainingQty -= halfQty
                        tp1Filled = true
                        activeSl = min(activeSl, fillEntry)
                    }
                    if (tp1Filled && b.l <= tp2) {
                        val tp2Fill = tp2 * (1.0 + slip)
                        realizedGrossUsdt += (fillEntry - tp2Fill) * remainingQty
                        totalFeesUsdt += tp2Fill * remainingQty * riskTemplate.takerFeeRate
                        weightedExitPriceSum += tp2Fill * remainingQty
                        remainingQty = 0.0
                        exitIdx = k
                        break
                    }
                }
            }

            if (remainingQty > 0.0) {
                val closeBar = closedLtf[exitIdx]
                val exitFill = if (sig.direction == TradeDirection.LONG) closeBar.c * (1.0 - slip) else closeBar.c * (1.0 + slip)
                realizedGrossUsdt += if (sig.direction == TradeDirection.LONG) {
                    (exitFill - fillEntry) * remainingQty
                } else {
                    (fillEntry - exitFill) * remainingQty
                }
                totalFeesUsdt += exitFill * remainingQty * riskTemplate.takerFeeRate
                weightedExitPriceSum += exitFill * remainingQty
            }

            val barsHeld = max(1, exitIdx - entryIdx)
            val fundingPeriods = floor((barsHeld * hoursPerBar) / 8.0)
            val fundingUsdt = if (config.marketType == MarketType.FUTURES && fundingPeriods > 0.0) {
                fillEntry * qtyTotal * abs(riskTemplate.fundingRatePer8h) * fundingPeriods
            } else 0.0

            val totalCost = totalFeesUsdt + fundingUsdt
            val netPnlUsdt = realizedGrossUsdt - totalCost
            val netR = netPnlUsdt / riskDollars

            equity = max(1.0, equity + netPnlUsdt)
            if (equity > peakEquity) peakEquity = equity
            val ddPct = ((peakEquity - equity) / peakEquity) * 100.0
            if (ddPct > maxDdPct) maxDdPct = ddPct

            trades.add(
                BacktestTradeRecord(
                    setupId = sig.setupId,
                    strategyComboId = sig.strategyComboId,
                    direction = sig.direction,
                    confluenceScore = sig.confluenceScore,
                    entryBarIdx = entryIdx,
                    exitBarIdx = exitIdx,
                    entryPrice = fillEntry,
                    exitPrice = weightedExitPriceSum / qtyTotal,
                    feesAndFundingUsdt = round2(totalCost),
                    netPnlUsdt = round2(netPnlUsdt),
                    isWin = netPnlUsdt > 0.0,
                    rMultiple = round2(netR)
                )
            )

            i = exitIdx + 1
        }

        if (trades.isEmpty()) {
            return emptyResult("NO_TRADES_EXECUTED", lastComboId)
        }

        val fullSummary = summarizeSegment(trades, initialCapital)
        val splitBarIdx = (210 + ((n - 210) * inSampleSplitRatio)).toInt()
        val isTrades = trades.filter { it.entryBarIdx < splitBarIdx }
        val oosTrades = trades.filter { it.entryBarIdx >= splitBarIdx }

        val dsrProb = computeBaileyDeflatedSharpe(trades.map { it.rMultiple }, max(1, numTrialsTested))
        val confidencePct = round1(dsrProb * 100.0)
        val overfitted = trades.size < 25 || dsrProb < 0.50

        val buckets = listOf(
            buildBucket("72-80", trades.filter { it.confluenceScore >= 72.0 && it.confluenceScore < 80.0 }),
            buildBucket("80-90", trades.filter { it.confluenceScore >= 80.0 && it.confluenceScore < 90.0 }),
            buildBucket("90-100", trades.filter { it.confluenceScore >= 90.0 })
        )

        return BacktestResult(
            statusCode = "OK",
            strategyComboId = lastComboId,
            totalTrades = fullSummary.totalTrades,
            winRatePct = fullSummary.winRatePct,
            profitFactor = fullSummary.profitFactor,
            expectancyR = fullSummary.expectancyR,
            maxDrawdownPct = round2(maxDdPct),
            netReturnPct = round2(((equity - initialCapital) / initialCapital) * 100.0),
            deflatedSharpeRatio = round2(dsrProb),
            statisticalConfidencePct = confidencePct,
            isOverfittedWarning = overfitted,
            inSampleSummary = if (isTrades.isNotEmpty()) summarizeSegment(isTrades, initialCapital) else null,
            outOfSampleSummary = if (oosTrades.isNotEmpty()) summarizeSegment(oosTrades, initialCapital) else null,
            scoreBuckets = buckets
        )
    }

    fun computeBaileyDeflatedSharpe(rReturns: List<Double>, numTrials: Int): Double {
        val n = rReturns.size
        if (n < 5) return 0.0
        val mean = rReturns.average()
        val variance = rReturns.sumOf { (it - mean).pow(2) } / n.toDouble()
        val std = sqrt(max(1e-9, variance))
        val sr = mean / std

        val skew = rReturns.sumOf { ((it - mean) / std).pow(3) } / n.toDouble()
        val kurt = rReturns.sumOf { ((it - mean) / std).pow(4) } / n.toDouble()

        val sr0 = RiskAndPsychologyEngine.expectedMaxSharpeNull(max(1, numTrials), 1.0 / n.toDouble())
        val denomTerm = 1.0 - (skew * sr) + (((kurt - 1.0) / 4.0) * sr * sr)
        val srStdErr = sqrt(max(1e-9, denomTerm) / max(1, n - 1).toDouble())
        val z = (sr - sr0) / max(1e-9, srStdErr)
        return RiskAndPsychologyEngine.normalCdf(z).coerceIn(0.0, 1.0)
    }

    private fun summarizeSegment(trades: List<BacktestTradeRecord>, startCap: Double): BacktestSegmentSummary {
        val total = trades.size
        val wins = trades.count { it.isWin }
        val wr = (wins.toDouble() / total.toDouble()) * 100.0
        val grossWin = trades.filter { it.netPnlUsdt > 0.0 }.sumOf { it.netPnlUsdt }
        val grossLoss = abs(trades.filter { it.netPnlUsdt < 0.0 }.sumOf { it.netPnlUsdt }).coerceAtLeast(1e-8)
        val pf = grossWin / grossLoss
        val expR = trades.map { it.rMultiple }.average()

        var eq = startCap
        var peak = startCap
        var mdd = 0.0
        for (t in trades) {
            eq = max(1.0, eq + t.netPnlUsdt)
            if (eq > peak) peak = eq
            val dd = ((peak - eq) / peak) * 100.0
            if (dd > mdd) mdd = dd
        }

        return BacktestSegmentSummary(
            totalTrades = total,
            winRatePct = round1(wr),
            profitFactor = round2(pf),
            expectancyR = round2(expR),
            maxDrawdownPct = round2(mdd),
            netReturnPct = round2(((eq - startCap) / startCap) * 100.0)
        )
    }

    private fun buildBucket(label: String, items: List<BacktestTradeRecord>): ScoreBucketMetrics {
        if (items.isEmpty()) return ScoreBucketMetrics(label, 0, 0.0, 0.0)
        val wr = (items.count { it.isWin }.toDouble() / items.size.toDouble()) * 100.0
        val expR = items.map { it.rMultiple }.average()
        return ScoreBucketMetrics(label, items.size, round1(wr), round2(expR))
    }

    private fun emptyResult(status: String, comboId: String) = BacktestResult(
        statusCode = status,
        strategyComboId = comboId,
        totalTrades = 0,
        winRatePct = 0.0,
        profitFactor = 0.0,
        expectancyR = 0.0,
        maxDrawdownPct = 0.0,
        netReturnPct = 0.0,
        deflatedSharpeRatio = 0.0,
        statisticalConfidencePct = 0.0,
        isOverfittedWarning = true,
        inSampleSummary = null,
        outOfSampleSummary = null,
        scoreBuckets = emptyList()
    )

    private fun round1(v: Double): Double = kotlin.math.round(v * 10.0) / 10.0
    private fun round2(v: Double): Double = kotlin.math.round(v * 100.0) / 100.0
}
