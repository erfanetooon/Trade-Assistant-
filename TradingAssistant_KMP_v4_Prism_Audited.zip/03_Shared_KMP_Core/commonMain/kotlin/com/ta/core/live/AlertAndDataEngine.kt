package com.ta.core.live

import com.ta.core.backtest.BacktestResult
import com.ta.core.quant.BarNode
import com.ta.core.structure.LiquidityPoolNode
import com.ta.core.structure.SupplyDemandZone
import com.ta.core.structure.WyckoffRangeState
import com.ta.core.synthesis.FullSynthesisReport
import com.ta.core.synthesis.StrategyConfigRequest
import com.ta.core.synthesis.StrategySynthesizerEngine
import com.tradingassistant.core.risk.PositionSizingInput
import com.tradingassistant.core.risk.RiskAndPsychologyEngine
import kotlin.math.abs
import kotlin.math.max

enum class FeedHealthCode {
    HEALTHY_LIVE,
    DEGRADED_LATENCY,
    STALE_DATA_LOCKED,
    DISCONNECTED
}

enum class AlertPriority {
    INFO,
    HIGH_APPROACHING_ZONE,
    CRITICAL_EXECUTION_TRIGGER,
    SECURITY_OR_RISK_LOCK
}

enum class AlertCategory {
    ZONE_PROXIMITY,
    LIQUIDITY_SWEEP,
    WYCKOFF_EVENT,
    COMPANION_SIGNAL_READY,
    STALE_DATA_WARNING,
    DOUGLAS_DISCIPLINE_LOCK,
    ADMIN_BROADCAST
}

data class SmartAlertEvent(
    val alertId: String,
    val timestampEpochSec: Long,
    val symbol: String,
    val timeframe: String,
    val category: AlertCategory,
    val priority: AlertPriority,
    val headlineCode: String,
    val referencePrice: Double,
    val targetLevelPrice: Double,
    val deduplicationKey: String
)

data class StrategyDriftReport(
    val strategyComboId: String,
    val backtestSampleSize: Int,
    val actualTradesCount: Int,
    val expectedWinRatePct: Double,
    val actualWinRatePct: Double,
    val winRateDriftPct: Double,
    val expectedExpectancyR: Double,
    val actualExpectancyR: Double,
    val expectancyDriftR: Double,
    val deflatedSharpeRatio: Double,
    val statisticalConfidencePct: Double,
    val avgDouglasAdherenceScore: Double,
    val diagnosticCode: String
)

data class JournalClosedSample(
    val tradeId: String,
    val strategyComboId: String,
    val realizedRMultiple: Double,
    val isWin: Boolean,
    val adherenceScore: Double
)

data class LivePipelineTickOutput(
    val statusCode: String,
    val feedHealth: FeedHealthCode,
    val dataLagMs: Long,
    val isTradingLockedByStaleData: Boolean,
    val synthesis: FullSynthesisReport?,
    val emittedAlerts: List<SmartAlertEvent>
)

object AlertAndDataEngine {

    fun processMarketSnapshot(
        symbol: String,
        ltfBars: List<BarNode>,
        htfBars: List<BarNode>,
        lastPacketReceivedEpochMs: Long,
        currentDeviceEpochMs: Long,
        maxAllowedLagMs: Long = 15_000L,
        config: StrategyConfigRequest,
        riskTemplate: PositionSizingInput,
        previouslyEmittedKeys: Set<String>,
        previousLtfWyckoff: WyckoffRangeState? = null,
        activeSetupIds: Set<String> = emptySet()
    ): LivePipelineTickOutput {
        val lag = max(0L, currentDeviceEpochMs - lastPacketReceivedEpochMs)
        val health = when {
            lastPacketReceivedEpochMs <= 0L -> FeedHealthCode.DISCONNECTED
            lag > maxAllowedLagMs -> FeedHealthCode.STALE_DATA_LOCKED
            lag > (maxAllowedLagMs / 2) -> FeedHealthCode.DEGRADED_LATENCY
            else -> FeedHealthCode.HEALTHY_LIVE
        }

        val nowSec = currentDeviceEpochMs / 1000L
        val alerts = mutableListOf<SmartAlertEvent>()

        if (health == FeedHealthCode.STALE_DATA_LOCKED || health == FeedHealthCode.DISCONNECTED) {
            val staleKey = "STALE_${symbol}_${nowSec / 300}"
            if (staleKey !in previouslyEmittedKeys) {
                alerts.add(
                    SmartAlertEvent(
                        alertId = "ALT-$nowSec-STALE",
                        timestampEpochSec = nowSec,
                        symbol = symbol,
                        timeframe = config.executionTimeframe,
                        category = AlertCategory.STALE_DATA_WARNING,
                        priority = AlertPriority.SECURITY_OR_RISK_LOCK,
                        headlineCode = "FEED_STALE_SIGNAL_GENERATION_SUSPENDED",
                        referencePrice = ltfBars.lastOrNull()?.c ?: 0.0,
                        targetLevelPrice = 0.0,
                        deduplicationKey = staleKey
                    )
                )
            }
            return LivePipelineTickOutput(
                statusCode = "STALE_DATA_LOCKED",
                feedHealth = health,
                dataLagMs = lag,
                isTradingLockedByStaleData = true,
                synthesis = null,
                emittedAlerts = alerts
            )
        }

        val sanitizedLtf = sanitizeBars(ltfBars)
        val sanitizedHtf = sanitizeBars(htfBars)
        val synthResult = StrategySynthesizerEngine.executeSynthesisResult(
            ltfBars = sanitizedLtf,
            htfBars = sanitizedHtf,
            config = config,
            riskTemplate = riskTemplate.copy(currentEpochSec = nowSec),
            previousLtfWyckoff = previousLtfWyckoff,
            activeSetupIds = activeSetupIds
        )

        val report = synthResult.report ?: return LivePipelineTickOutput(
            statusCode = synthResult.statusCode,
            feedHealth = health,
            dataLagMs = lag,
            isTradingLockedByStaleData = false,
            synthesis = null,
            emittedAlerts = alerts
        )

        val closedLtf = sanitizedLtf.filter { it.closed }
        val currentPrice = closedLtf.last().c
        val lastBarTime = closedLtf.last().t

        val proximityAlerts = detectZoneAndMagnetProximity(
            symbol = symbol,
            timeframe = config.executionTimeframe,
            currentPrice = currentPrice,
            nowSec = nowSec,
            barTimestamp = lastBarTime,
            demandZones = report.assistantReport.keyDemandZones,
            supplyZones = report.assistantReport.keySupplyZones,
            magnets = report.assistantReport.magnetLiquidityPools,
            existingKeys = previouslyEmittedKeys
        )
        alerts.addAll(proximityAlerts)

        val sig = report.companionSignal
        if (sig.isSignalActive && sig.direction != null) {
            val sigKey = "SIG_${sig.setupId}"
            if (sigKey !in previouslyEmittedKeys) {
                alerts.add(
                    SmartAlertEvent(
                        alertId = "ALT-$nowSec-SIG",
                        timestampEpochSec = nowSec,
                        symbol = symbol,
                        timeframe = config.executionTimeframe,
                        category = AlertCategory.COMPANION_SIGNAL_READY,
                        priority = AlertPriority.CRITICAL_EXECUTION_TRIGGER,
                        headlineCode = "COMPANION_${sig.direction.name}_CONFIRMED_SCORE_${sig.confluenceScore.toInt()}",
                        referencePrice = sig.optimalEntryPrice,
                        targetLevelPrice = sig.takeProfit1Price,
                        deduplicationKey = sigKey
                    )
                )
            }
        } else if (sig.noSignalReasonCode?.startsWith("RISK_ENGINE_BLOCKED") == true) {
            val lockKey = "LOCK_${symbol}_${nowSec / 900}"
            if (lockKey !in previouslyEmittedKeys) {
                alerts.add(
                    SmartAlertEvent(
                        alertId = "ALT-$nowSec-LOCK",
                        timestampEpochSec = nowSec,
                        symbol = symbol,
                        timeframe = config.executionTimeframe,
                        category = AlertCategory.DOUGLAS_DISCIPLINE_LOCK,
                        priority = AlertPriority.SECURITY_OR_RISK_LOCK,
                        headlineCode = sig.noSignalReasonCode,
                        referencePrice = currentPrice,
                        targetLevelPrice = 0.0,
                        deduplicationKey = lockKey
                    )
                )
            }
        }

        return LivePipelineTickOutput(
            statusCode = "OK",
            feedHealth = health,
            dataLagMs = lag,
            isTradingLockedByStaleData = false,
            synthesis = report,
            emittedAlerts = alerts
        )
    }

    fun evaluateExpectedVsActualDrift(
        strategyComboId: String,
        backtest: BacktestResult,
        journalTrades: List<JournalClosedSample>,
        numStrategiesTested: Int = 1
    ): StrategyDriftReport {
        if (backtest.strategyComboId != strategyComboId) {
            return StrategyDriftReport(
                strategyComboId = strategyComboId,
                backtestSampleSize = backtest.totalTrades,
                actualTradesCount = 0,
                expectedWinRatePct = 0.0,
                actualWinRatePct = 0.0,
                winRateDriftPct = 0.0,
                expectedExpectancyR = 0.0,
                actualExpectancyR = 0.0,
                expectancyDriftR = 0.0,
                deflatedSharpeRatio = backtest.deflatedSharpeRatio,
                statisticalConfidencePct = 0.0,
                avgDouglasAdherenceScore = 100.0,
                diagnosticCode = "STRATEGY_COMBO_MISMATCH_BETWEEN_BACKTEST_AND_JOURNAL"
            )
        }

        val matching = journalTrades.filter { it.strategyComboId == strategyComboId }
        val actualCount = matching.size
        if (actualCount == 0) {
            return StrategyDriftReport(
                strategyComboId = strategyComboId,
                backtestSampleSize = backtest.totalTrades,
                actualTradesCount = 0,
                expectedWinRatePct = backtest.winRatePct,
                actualWinRatePct = 0.0,
                winRateDriftPct = 0.0,
                expectedExpectancyR = backtest.expectancyR,
                actualExpectancyR = 0.0,
                expectancyDriftR = 0.0,
                deflatedSharpeRatio = backtest.deflatedSharpeRatio,
                statisticalConfidencePct = 0.0,
                avgDouglasAdherenceScore = 100.0,
                diagnosticCode = "AWAITING_DOUGLAS_20_TRADE_SAMPLE_BLOCK"
            )
        }

        val wins = matching.filter { it.isWin }
        val losses = matching.filter { !it.isWin }
        val actualWinRateRatio = wins.size.toDouble() / actualCount.toDouble()
        val actualWinRatePct = round1(actualWinRateRatio * 100.0)
        val actualExpR = round2(matching.map { it.realizedRMultiple }.average())
        val avgAdherence = round1(matching.map { it.adherenceScore }.average())

        val avgWinR = if (wins.isNotEmpty()) wins.map { it.realizedRMultiple }.average() else 0.0
        val avgLossR = if (losses.isNotEmpty()) abs(losses.map { it.realizedRMultiple }.average()) else 1.0

        val confidence = RiskAndPsychologyEngine.calculateStatisticalConfidencePct(
            sampleSize = actualCount,
            winRate = actualWinRateRatio,
            avgWinR = avgWinR,
            avgLossR = avgLossR,
            numStrategiesTested = max(1, numStrategiesTested)
        )

        val wrDrift = round1(actualWinRatePct - backtest.winRatePct)
        val expDrift = round2(actualExpR - backtest.expectancyR)

        val diag = when {
            actualCount < 20 -> "SAMPLE_BELOW_20_BLOCK_CONTINUE_EXECUTION"
            backtest.isOverfittedWarning -> "BACKTEST_OVERFITTED_LOW_DSR_WARNING"
            expDrift < -0.35 && avgAdherence < 75.0 -> "EXECUTION_DISCIPLINE_BREAKDOWN_NOT_STRATEGY_FAULT"
            expDrift < -0.35 && avgAdherence >= 85.0 -> "MARKET_REGIME_SHIFT_STRATEGY_EDGE_DECAY"
            actualExpR > 0.25 && avgAdherence >= 85.0 -> "VALIDATED_LIVE_EDGE_AND_HIGH_DISCIPLINE"
            else -> "WITHIN_NORMAL_STATISTICAL_VARIANCE"
        }

        return StrategyDriftReport(
            strategyComboId = strategyComboId,
            backtestSampleSize = backtest.totalTrades,
            actualTradesCount = actualCount,
            expectedWinRatePct = backtest.winRatePct,
            actualWinRatePct = actualWinRatePct,
            winRateDriftPct = wrDrift,
            expectedExpectancyR = backtest.expectancyR,
            actualExpectancyR = actualExpR,
            expectancyDriftR = expDrift,
            deflatedSharpeRatio = backtest.deflatedSharpeRatio,
            statisticalConfidencePct = round1(confidence),
            avgDouglasAdherenceScore = avgAdherence,
            diagnosticCode = diag
        )
    }

    fun verifySignedBroadcastPayload(
        notifId: String,
        title: String,
        body: String,
        targetUrl: String,
        audience: String,
        signatureBase64: String,
        asymmetricPublicKeyVerifier: (canonicalPayload: String, signatureBase64: String) -> Boolean
    ): Boolean {
        if (targetUrl.isNotBlank() && !targetUrl.startsWith("https://")) return false
        if (notifId.isBlank() || title.isBlank() || body.isBlank() || signatureBase64.isBlank()) return false
        val canonical = "$notifId|$title|$body|$targetUrl|$audience"
        return asymmetricPublicKeyVerifier(canonical, signatureBase64)
    }

    private fun sanitizeBars(raw: List<BarNode>): List<BarNode> {
        if (raw.isEmpty()) return emptyList()
        val dedup = LinkedHashMap<Long, BarNode>()
        for (b in raw) {
            if (b.c > 0.0 && b.h >= b.l && b.v >= 0.0) {
                dedup[b.t] = b
            }
        }
        return dedup.values.sortedBy { it.t }
    }

    private fun detectZoneAndMagnetProximity(
        symbol: String,
        timeframe: String,
        currentPrice: Double,
        nowSec: Long,
        barTimestamp: Long,
        demandZones: List<SupplyDemandZone>,
        supplyZones: List<SupplyDemandZone>,
        magnets: List<LiquidityPoolNode>,
        existingKeys: Set<String>
    ): List<SmartAlertEvent> {
        val out = mutableListOf<SmartAlertEvent>()
        for (z in demandZones.take(3)) {
            val distPct = abs(currentPrice - z.top) / max(1e-8, currentPrice)
            if (currentPrice in z.bottom..(z.top * 1.003) || distPct <= 0.0025) {
                val key = "ZONE_${symbol}_${timeframe}_${z.kind.name}_${z.createdTime}"
                if (key !in existingKeys) {
                    out.add(
                        SmartAlertEvent(
                            alertId = "ALT-$nowSec-Z",
                            timestampEpochSec = nowSec,
                            symbol = symbol,
                            timeframe = timeframe,
                            category = AlertCategory.ZONE_PROXIMITY,
                            priority = AlertPriority.HIGH_APPROACHING_ZONE,
                            headlineCode = "PRICE_ENTERING_${z.kind.name}_CONFLUENCE_${z.confluenceScore.toInt()}",
                            referencePrice = currentPrice,
                            targetLevelPrice = z.midConsequentEncroachment,
                            deduplicationKey = key
                        )
                    )
                }
            }
        }
        for (z in supplyZones.take(3)) {
            val distPct = abs(z.bottom - currentPrice) / max(1e-8, currentPrice)
            if (currentPrice in (z.bottom * 0.997)..z.top || distPct <= 0.0025) {
                val key = "ZONE_${symbol}_${timeframe}_${z.kind.name}_${z.createdTime}"
                if (key !in existingKeys) {
                    out.add(
                        SmartAlertEvent(
                            alertId = "ALT-$nowSec-Z",
                            timestampEpochSec = nowSec,
                            symbol = symbol,
                            timeframe = timeframe,
                            category = AlertCategory.ZONE_PROXIMITY,
                            priority = AlertPriority.HIGH_APPROACHING_ZONE,
                            headlineCode = "PRICE_ENTERING_${z.kind.name}_CONFLUENCE_${z.confluenceScore.toInt()}",
                            referencePrice = currentPrice,
                            targetLevelPrice = z.midConsequentEncroachment,
                            deduplicationKey = key
                        )
                    )
                }
            }
        }
        for (m in magnets.take(3)) {
            val distPct = abs(currentPrice - m.level) / max(1e-8, currentPrice)
            if (distPct <= 0.002) {
                val key = "MAG_${symbol}_${timeframe}_${m.kind.name}_${m.firstIdx}"
                if (key !in existingKeys) {
                    out.add(
                        SmartAlertEvent(
                            alertId = "ALT-$nowSec-M",
                            timestampEpochSec = nowSec,
                            symbol = symbol,
                            timeframe = timeframe,
                            category = AlertCategory.LIQUIDITY_SWEEP,
                            priority = AlertPriority.HIGH_APPROACHING_ZONE,
                            headlineCode = "APPROACHING_LIQUIDITY_POOL_${m.kind.name}",
                            referencePrice = currentPrice,
                            targetLevelPrice = m.level,
                            deduplicationKey = key
                        )
                    )
                }
            }
        }
        return out
    }

    private fun round1(v: Double): Double = kotlin.math.round(v * 10.0) / 10.0
    private fun round2(v: Double): Double = kotlin.math.round(v * 100.0) / 100.0
}
