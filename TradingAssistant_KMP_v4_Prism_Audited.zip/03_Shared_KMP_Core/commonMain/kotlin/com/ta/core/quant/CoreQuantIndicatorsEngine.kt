package com.ta.core.quant

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class BarNode(
    val t: Long,
    val o: Double,
    val h: Double,
    val l: Double,
    val c: Double,
    val v: Double,
    val closed: Boolean
)

enum class RegimeCode {
    TREND_BULL_STRONG,
    TREND_BEAR_STRONG,
    TREND_WEAK,
    RANGE_MEAN_REVERT,
    VOL_SQUEEZE_BREAKOUT_PREP,
    VOL_EXTREME_EXPANSION,
    UNDEFINED
}

enum class DivCode {
    NONE,
    BULL_REGULAR,
    BEAR_REGULAR,
    BULL_HIDDEN,
    BEAR_HIDDEN
}

enum class VwapAnchorMode {
    UTC_DAILY,
    UTC_WEEKLY
}

data class RegimeThresholds(
    val adxTrendMin: Double = 25.0,
    val adxRangeMax: Double = 20.0,
    val erTrendMin: Double = 0.35,
    val erRangeMax: Double = 0.28,
    val squeezeBwPctMax: Double = 15.0,
    val extremeBwPctMin: Double = 92.0,
    val extremeAtrPctMin: Double = 4.0
)

data class MacdTuple(
    val line: Double,
    val sig: Double,
    val hist: Double,
    val histSlope: Double
)

data class BollTuple(
    val mid: Double,
    val up: Double,
    val low: Double,
    val bw: Double,
    val pctB: Double,
    val bwPercentile: Double
)

data class KeltnerTuple(
    val mid: Double,
    val up: Double,
    val low: Double
)

data class AdxTuple(
    val adx: Double,
    val pDi: Double,
    val mDi: Double,
    val slope: Double
)

data class StochTuple(
    val k: Double,
    val d: Double
)

data class VwapTuple(
    val vwap: Double,
    val up1: Double,
    val low1: Double,
    val up2: Double,
    val low2: Double,
    val zScore: Double,
    val anchorMode: VwapAnchorMode = VwapAnchorMode.UTC_DAILY,
    val sessionBarsCount: Int = 0
)

data class VolProfileTuple(
    val poc: Double,
    val vah: Double,
    val valPrice: Double,
    val hvnList: List<Double>,
    val lvnList: List<Double>
)

data class QuantSnapshot(
    val timestamp: Long,
    val closePrice: Double,
    val emaFast: Double,
    val emaMid: Double,
    val emaSlow: Double,
    val smaBase: Double,
    val rsi14: Double,
    val rsiDiv: DivCode,
    val macd: MacdTuple,
    val macdDiv: DivCode,
    val atr14: Double,
    val atrPct: Double,
    val baselineAtrPct: Double,
    val boll: BollTuple,
    val keltner: KeltnerTuple,
    val isTtmSqueeze: Boolean,
    val adx: AdxTuple,
    val stoch: StochTuple,
    val obv: Double,
    val obvEma: Double,
    val vwap: VwapTuple,
    val volProfile: VolProfileTuple,
    val volZScore: Double,
    val efficiencyRatio: Double,
    val regime: RegimeCode
)

data class QuantComputeResult(
    val statusCode: String,
    val snapshot: QuantSnapshot?
)

object CoreQuantIndicatorsEngine {

    fun computeSnapshot(
        rawBars: List<BarNode>,
        emaFastLen: Int = 20,
        emaMidLen: Int = 50,
        emaSlowLen: Int = 200,
        rsiLen: Int = 14,
        atrLen: Int = 14,
        adxLen: Int = 14,
        bollLen: Int = 20,
        bollMult: Double = 2.0,
        keltnerMult: Double = 1.5,
        vpBins: Int = 48,
        vpLookback: Int = 120,
        vwapAnchorMode: VwapAnchorMode = VwapAnchorMode.UTC_DAILY,
        regimeThresholds: RegimeThresholds = RegimeThresholds()
    ): QuantSnapshot? {
        return computeSnapshotResult(
            rawBars = rawBars,
            emaFastLen = emaFastLen,
            emaMidLen = emaMidLen,
            emaSlowLen = emaSlowLen,
            rsiLen = rsiLen,
            atrLen = atrLen,
            adxLen = adxLen,
            bollLen = bollLen,
            bollMult = bollMult,
            keltnerMult = keltnerMult,
            vpBins = vpBins,
            vpLookback = vpLookback,
            vwapAnchorMode = vwapAnchorMode,
            regimeThresholds = regimeThresholds
        ).snapshot
    }

    fun computeSnapshotResult(
        rawBars: List<BarNode>,
        emaFastLen: Int = 20,
        emaMidLen: Int = 50,
        emaSlowLen: Int = 200,
        rsiLen: Int = 14,
        atrLen: Int = 14,
        adxLen: Int = 14,
        bollLen: Int = 20,
        bollMult: Double = 2.0,
        keltnerMult: Double = 1.5,
        vpBins: Int = 48,
        vpLookback: Int = 120,
        vwapAnchorMode: VwapAnchorMode = VwapAnchorMode.UTC_DAILY,
        regimeThresholds: RegimeThresholds = RegimeThresholds()
    ): QuantComputeResult {
        val bars = rawBars.filter { it.closed }
        val n = bars.size
        val minRequired = max(emaSlowLen + 10, vpLookback)
        if (n < minRequired) {
            return QuantComputeResult("INSUFFICIENT_HISTORY", null)
        }

        val closes = DoubleArray(n) { bars[it].c }
        val highs = DoubleArray(n) { bars[it].h }
        val lows = DoubleArray(n) { bars[it].l }
        val vols = DoubleArray(n) { bars[it].v }

        val emaFastArr = calcEmaSeries(closes, emaFastLen)
        val emaMidArr = calcEmaSeries(closes, emaMidLen)
        val emaSlowArr = calcEmaSeries(closes, emaSlowLen)
        val smaBaseArr = calcSmaSeries(closes, emaSlowLen)

        val rsiArr = calcRsiWilderSeries(closes, rsiLen)
        val macdSeries = calcMacdSeries(closes, 12, 26, 9)
        val atrArr = calcAtrWilderSeries(highs, lows, closes, atrLen)
        val adxSeries = calcAdxWilderSeries(highs, lows, closes, adxLen)
        val bollSeries = calcBollingerSeries(closes, bollLen, bollMult, 100)
        val keltnerLast = calcKeltnerLast(closes, emaFastArr, atrArr, keltnerMult)
        val stochLast = calcStochSeries(highs, lows, closes, 14, 3, 3)
        val obvArr = calcObvSeries(closes, vols)
        val obvEmaArr = calcEmaSeries(obvArr, 20)
        val vwapLast = calcSessionAnchoredVwap(bars, vwapAnchorMode)
        val vpLast = calcVolumeProfile(bars.takeLast(vpLookback), vpBins, 0.70)
        val volZ = calcZScoreLast(vols, 30)
        val er = calcKaufmanEfficiencyRatio(closes, 20)

        val lastIdx = n - 1
        val lastBar = bars[lastIdx]
        val lastAtr = atrArr[lastIdx]
        val atrPct = if (lastBar.c > 0.0) (lastAtr / lastBar.c) * 100.0 else 0.0
        val baselineAtrPct = calcMedianAtrPct(atrArr, closes, atrLen)

        val bLast = bollSeries[lastIdx]
        val squeeze = bLast.up < keltnerLast.up && bLast.low > keltnerLast.low

        val rsiDiv = detectOscillatorDivergence(highs, lows, closes, rsiArr, 5, 60)
        val histArr = DoubleArray(n) { macdSeries[it].hist }
        val macdDiv = detectOscillatorDivergence(highs, lows, closes, histArr, 5, 60)

        val regime = classifyMarketRegime(
            close = lastBar.c,
            emaFast = emaFastArr[lastIdx],
            emaMid = emaMidArr[lastIdx],
            emaSlow = emaSlowArr[lastIdx],
            adx = adxSeries[lastIdx],
            boll = bLast,
            isSqueeze = squeeze,
            er = er,
            atrPct = atrPct,
            thresholds = regimeThresholds
        )

        val snap = QuantSnapshot(
            timestamp = lastBar.t,
            closePrice = lastBar.c,
            emaFast = emaFastArr[lastIdx],
            emaMid = emaMidArr[lastIdx],
            emaSlow = emaSlowArr[lastIdx],
            smaBase = smaBaseArr[lastIdx],
            rsi14 = rsiArr[lastIdx],
            rsiDiv = rsiDiv,
            macd = macdSeries[lastIdx],
            macdDiv = macdDiv,
            atr14 = lastAtr,
            atrPct = atrPct,
            baselineAtrPct = baselineAtrPct,
            boll = bLast,
            keltner = keltnerLast,
            isTtmSqueeze = squeeze,
            adx = adxSeries[lastIdx],
            stoch = stochLast,
            obv = obvArr[lastIdx],
            obvEma = obvEmaArr[lastIdx],
            vwap = vwapLast,
            volProfile = vpLast,
            volZScore = volZ,
            efficiencyRatio = er,
            regime = regime
        )
        return QuantComputeResult("OK", snap)
    }

    fun calcMedianAtrPct(atrArr: DoubleArray, closes: DoubleArray, warmup: Int): Double {
        val n = closes.size
        if (n <= warmup) return 0.0
        val samples = mutableListOf<Double>()
        for (i in warmup until n) {
            if (closes[i] > 0.0 && atrArr[i] > 0.0) {
                samples.add((atrArr[i] / closes[i]) * 100.0)
            }
        }
        if (samples.isEmpty()) return 0.0
        samples.sort()
        val mid = samples.size / 2
        return if (samples.size % 2 == 1) samples[mid] else (samples[mid - 1] + samples[mid]) * 0.5
    }

    fun calcSmaSeries(src: DoubleArray, period: Int): DoubleArray {
        val n = src.size
        val out = DoubleArray(n)
        if (n == 0 || period <= 1) return src.copyOf()
        var sum = 0.0
        for (i in 0 until n) {
            sum += src[i]
            if (i >= period) sum -= src[i - period]
            out[i] = if (i >= period - 1) sum / period else sum / (i + 1)
        }
        return out
    }

    fun calcEmaSeries(src: DoubleArray, period: Int): DoubleArray {
        val n = src.size
        val out = DoubleArray(n)
        if (n == 0) return out
        val k = 2.0 / (period + 1.0)
        var seedSum = 0.0
        val seedEnd = min(n, period)
        for (i in 0 until seedEnd) {
            seedSum += src[i]
            out[i] = seedSum / (i + 1)
        }
        for (i in seedEnd until n) {
            out[i] = (src[i] - out[i - 1]) * k + out[i - 1]
        }
        return out
    }

    fun calcRsiWilderSeries(closes: DoubleArray, period: Int): DoubleArray {
        val n = closes.size
        val out = DoubleArray(n) { 50.0 }
        if (n <= period) return out

        var gainSum = 0.0
        var lossSum = 0.0
        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff > 0) gainSum += diff else lossSum -= diff
        }
        var avgGain = gainSum / period
        var avgLoss = lossSum / period
        out[period] = if (avgLoss == 0.0) 100.0 else 100.0 - (100.0 / (1.0 + (avgGain / avgLoss)))

        for (i in (period + 1) until n) {
            val diff = closes[i] - closes[i - 1]
            val g = if (diff > 0) diff else 0.0
            val l = if (diff < 0) -diff else 0.0
            avgGain = ((avgGain * (period - 1)) + g) / period
            avgLoss = ((avgLoss * (period - 1)) + l) / period
            out[i] = if (avgLoss == 0.0) 100.0 else 100.0 - (100.0 / (1.0 + (avgGain / avgLoss)))
        }
        return out
    }

    fun calcAtrWilderSeries(highs: DoubleArray, lows: DoubleArray, closes: DoubleArray, period: Int): DoubleArray {
        val n = closes.size
        val tr = DoubleArray(n)
        val out = DoubleArray(n)
        if (n == 0) return out
        tr[0] = highs[0] - lows[0]
        for (i in 1 until n) {
            val hl = highs[i] - lows[i]
            val hc = abs(highs[i] - closes[i - 1])
            val lc = abs(lows[i] - closes[i - 1])
            tr[i] = max(hl, max(hc, lc))
        }
        var sum = 0.0
        val seedEnd = min(n, period)
        for (i in 0 until seedEnd) {
            sum += tr[i]
            out[i] = sum / (i + 1)
        }
        for (i in seedEnd until n) {
            out[i] = ((out[i - 1] * (period - 1)) + tr[i]) / period
        }
        return out
    }

    fun calcMacdSeries(closes: DoubleArray, fast: Int, slow: Int, sigLen: Int): Array<MacdTuple> {
        val n = closes.size
        val fastEma = calcEmaSeries(closes, fast)
        val slowEma = calcEmaSeries(closes, slow)
        val macdLine = DoubleArray(n) { fastEma[it] - slowEma[it] }
        val sigLine = calcEmaSeries(macdLine, sigLen)
        return Array(n) { i ->
            val h = macdLine[i] - sigLine[i]
            val prevH = if (i > 0) macdLine[i - 1] - sigLine[i - 1] else h
            MacdTuple(macdLine[i], sigLine[i], h, h - prevH)
        }
    }

    fun calcBollingerSeries(
        closes: DoubleArray,
        period: Int,
        mult: Double,
        percentileLookback: Int
    ): Array<BollTuple> {
        val n = closes.size
        val sma = calcSmaSeries(closes, period)
        val bwArr = DoubleArray(n)
        val upArr = DoubleArray(n)
        val lowArr = DoubleArray(n)
        val pctBArr = DoubleArray(n)

        for (i in 0 until n) {
            val start = max(0, i - period + 1)
            val count = i - start + 1
            val mean = sma[i]
            var sqSum = 0.0
            for (j in start..i) {
                val d = closes[j] - mean
                sqSum += d * d
            }
            val std = sqrt(sqSum / count)
            val u = mean + mult * std
            val l = mean - mult * std
            upArr[i] = u
            lowArr[i] = l
            bwArr[i] = if (mean > 0.0) ((u - l) / mean) * 100.0 else 0.0
            pctBArr[i] = if (u > l) (closes[i] - l) / (u - l) else 0.5
        }

        return Array(n) { i ->
            val lbStart = max(0, i - percentileLookback + 1)
            val windowCount = i - lbStart + 1
            var lowerCount = 0
            for (j in lbStart..i) {
                if (bwArr[j] < bwArr[i]) lowerCount++
            }
            val pctRank = (lowerCount.toDouble() / windowCount.toDouble()) * 100.0
            BollTuple(sma[i], upArr[i], lowArr[i], bwArr[i], pctBArr[i], pctRank)
        }
    }

    private fun calcKeltnerLast(
        closes: DoubleArray,
        emaArr: DoubleArray,
        atrArr: DoubleArray,
        mult: Double
    ): KeltnerTuple {
        val i = closes.size - 1
        val mid = emaArr[i]
        val range = atrArr[i] * mult
        return KeltnerTuple(mid, mid + range, mid - range)
    }

    fun calcAdxWilderSeries(
        highs: DoubleArray,
        lows: DoubleArray,
        closes: DoubleArray,
        period: Int
    ): Array<AdxTuple> {
        val n = closes.size
        if (n < period * 2) {
            return Array(n) { AdxTuple(0.0, 0.0, 0.0, 0.0) }
        }
        val tr = DoubleArray(n)
        val pDm = DoubleArray(n)
        val mDm = DoubleArray(n)

        for (i in 1 until n) {
            val upMove = highs[i] - highs[i - 1]
            val downMove = lows[i - 1] - lows[i]
            pDm[i] = if (upMove > downMove && upMove > 0.0) upMove else 0.0
            mDm[i] = if (downMove > upMove && downMove > 0.0) downMove else 0.0
            val hl = highs[i] - lows[i]
            val hc = abs(highs[i] - closes[i - 1])
            val lc = abs(lows[i] - closes[i - 1])
            tr[i] = max(hl, max(hc, lc))
        }

        var smTr = 0.0
        var smPDm = 0.0
        var smMDm = 0.0
        for (i in 1..period) {
            smTr += tr[i]
            smPDm += pDm[i]
            smMDm += mDm[i]
        }

        val pDiArr = DoubleArray(n)
        val mDiArr = DoubleArray(n)
        val dxArr = DoubleArray(n)

        for (i in period until n) {
            if (i > period) {
                smTr = smTr - (smTr / period) + tr[i]
                smPDm = smPDm - (smPDm / period) + pDm[i]
                smMDm = smMDm - (smMDm / period) + mDm[i]
            }
            val pDi = if (smTr > 0.0) (smPDm / smTr) * 100.0 else 0.0
            val mDi = if (smTr > 0.0) (smMDm / smTr) * 100.0 else 0.0
            pDiArr[i] = pDi
            mDiArr[i] = mDi
            val sumDi = pDi + mDi
            dxArr[i] = if (sumDi > 0.0) (abs(pDi - mDi) / sumDi) * 100.0 else 0.0
        }

        val adxArr = DoubleArray(n)
        var dxSum = 0.0
        val adxStart = period * 2 - 1
        for (i in period..adxStart) {
            dxSum += dxArr[i]
        }
        adxArr[adxStart] = dxSum / period
        for (i in (adxStart + 1) until n) {
            adxArr[i] = ((adxArr[i - 1] * (period - 1)) + dxArr[i]) / period
        }

        return Array(n) { i ->
            val slope = if (i > 0) adxArr[i] - adxArr[i - 1] else 0.0
            AdxTuple(adxArr[i], pDiArr[i], mDiArr[i], slope)
        }
    }

    private fun calcStochSeries(
        highs: DoubleArray,
        lows: DoubleArray,
        closes: DoubleArray,
        kPeriod: Int,
        kSmooth: Int,
        dPeriod: Int
    ): StochTuple {
        val n = closes.size
        val rawK = DoubleArray(n)
        for (i in 0 until n) {
            val s = max(0, i - kPeriod + 1)
            var hh = highs[s]
            var ll = lows[s]
            for (j in s..i) {
                if (highs[j] > hh) hh = highs[j]
                if (lows[j] < ll) ll = lows[j]
            }
            rawK[i] = if (hh > ll) ((closes[i] - ll) / (hh - ll)) * 100.0 else 50.0
        }
        val kArr = calcSmaSeries(rawK, kSmooth)
        val dArr = calcSmaSeries(kArr, dPeriod)
        return StochTuple(kArr[n - 1], dArr[n - 1])
    }

    private fun calcObvSeries(closes: DoubleArray, vols: DoubleArray): DoubleArray {
        val n = closes.size
        val out = DoubleArray(n)
        for (i in 1 until n) {
            out[i] = when {
                closes[i] > closes[i - 1] -> out[i - 1] + vols[i]
                closes[i] < closes[i - 1] -> out[i - 1] - vols[i]
                else -> out[i - 1]
            }
        }
        return out
    }

    fun calcSessionAnchoredVwap(bars: List<BarNode>, mode: VwapAnchorMode): VwapTuple {
        val lastBar = bars.last()
        val lastBucket = sessionBucket(lastBar.t, mode)
        var startIdx = bars.size - 1
        while (startIdx > 0 && sessionBucket(bars[startIdx - 1].t, mode) == lastBucket) {
            startIdx--
        }
        val slice = bars.subList(startIdx, bars.size)
        var cumPV = 0.0
        var cumV = 0.0
        var cumPV2 = 0.0
        for (b in slice) {
            val tp = (b.h + b.l + b.c) / 3.0
            cumPV += tp * b.v
            cumPV2 += tp * tp * b.v
            cumV += b.v
        }
        if (cumV <= 0.0) {
            return VwapTuple(lastBar.c, lastBar.c, lastBar.c, lastBar.c, lastBar.c, 0.0, mode, slice.size)
        }
        val vwap = cumPV / cumV
        val variance = max(0.0, (cumPV2 / cumV) - (vwap * vwap))
        val std = sqrt(variance)
        val z = if (std > 0.0) (lastBar.c - vwap) / std else 0.0
        return VwapTuple(
            vwap = vwap,
            up1 = vwap + std,
            low1 = vwap - std,
            up2 = vwap + 2.0 * std,
            low2 = vwap - 2.0 * std,
            zScore = z,
            anchorMode = mode,
            sessionBarsCount = slice.size
        )
    }

    private fun sessionBucket(timestamp: Long, mode: VwapAnchorMode): Long {
        val epochSec = if (timestamp > 10_000_000_000L) timestamp / 1000L else timestamp
        val utcDay = epochSec / 86_400L
        return when (mode) {
            VwapAnchorMode.UTC_DAILY -> utcDay
            VwapAnchorMode.UTC_WEEKLY -> (utcDay + 3L) / 7L
        }
    }

    fun calcVolumeProfile(bars: List<BarNode>, numBins: Int, valueAreaPct: Double): VolProfileTuple {
        var minP = Double.MAX_VALUE
        var maxP = -Double.MAX_VALUE
        for (b in bars) {
            if (b.l < minP) minP = b.l
            if (b.h > maxP) maxP = b.h
        }
        if (maxP <= minP || numBins <= 1) {
            val c = bars.last().c
            return VolProfileTuple(c, c, c, emptyList(), emptyList())
        }
        val step = (maxP - minP) / numBins
        val binVols = DoubleArray(numBins)
        val binCenters = DoubleArray(numBins) { minP + (it + 0.5) * step }

        var totalVol = 0.0
        for (b in bars) {
            val startBin = ((b.l - minP) / step).toInt().coerceIn(0, numBins - 1)
            val endBin = ((b.h - minP) / step).toInt().coerceIn(0, numBins - 1)
            val span = (endBin - startBin + 1).coerceAtLeast(1)
            val volPerBin = b.v / span
            for (idx in startBin..endBin) {
                binVols[idx] += volPerBin
                totalVol += volPerBin
            }
        }

        var pocIdx = 0
        for (i in 1 until numBins) {
            if (binVols[i] > binVols[pocIdx]) pocIdx = i
        }

        val targetVol = totalVol * valueAreaPct
        var accVol = binVols[pocIdx]
        var lowIdx = pocIdx
        var highIdx = pocIdx

        while (accVol < targetVol && (lowIdx > 0 || highIdx < numBins - 1)) {
            val nextUpVol = if (highIdx < numBins - 1) binVols[highIdx + 1] else -1.0
            val nextDownVol = if (lowIdx > 0) binVols[lowIdx - 1] else -1.0
            if (nextUpVol >= nextDownVol) {
                highIdx++
                accVol += binVols[highIdx]
            } else {
                lowIdx--
                accVol += binVols[lowIdx]
            }
        }

        val avgBinVol = totalVol / numBins
        val hvn = mutableListOf<Double>()
        val lvn = mutableListOf<Double>()
        for (i in 1 until (numBins - 1)) {
            if (binVols[i] > avgBinVol * 1.5 && binVols[i] >= binVols[i - 1] && binVols[i] >= binVols[i + 1]) {
                hvn.add(binCenters[i])
            } else if (binVols[i] < avgBinVol * 0.5 && binVols[i] <= binVols[i - 1] && binVols[i] <= binVols[i + 1]) {
                lvn.add(binCenters[i])
            }
        }

        return VolProfileTuple(
            poc = binCenters[pocIdx],
            vah = binCenters[highIdx] + (step * 0.5),
            valPrice = binCenters[lowIdx] - (step * 0.5),
            hvnList = hvn,
            lvnList = lvn
        )
    }

    private fun calcZScoreLast(series: DoubleArray, lookback: Int): Double {
        val n = series.size
        val start = max(0, n - lookback)
        val count = n - start
        if (count < 2) return 0.0
        var sum = 0.0
        for (i in start until n) sum += series[i]
        val mean = sum / count
        var sq = 0.0
        for (i in start until n) {
            val d = series[i] - mean
            sq += d * d
        }
        val std = sqrt(sq / count)
        return if (std > 0.0) (series[n - 1] - mean) / std else 0.0
    }

    private fun calcKaufmanEfficiencyRatio(closes: DoubleArray, period: Int): Double {
        val n = closes.size
        if (n <= period) return 0.5
        val netChange = abs(closes[n - 1] - closes[n - 1 - period])
        var sumAbsDiff = 0.0
        for (i in (n - period) until n) {
            sumAbsDiff += abs(closes[i] - closes[i - 1])
        }
        return if (sumAbsDiff > 0.0) (netChange / sumAbsDiff).coerceIn(0.0, 1.0) else 0.0
    }

    private fun detectOscillatorDivergence(
        highs: DoubleArray,
        lows: DoubleArray,
        closes: DoubleArray,
        osc: DoubleArray,
        pivotSpan: Int,
        maxLookback: Int
    ): DivCode {
        val n = closes.size
        if (n < maxLookback + pivotSpan * 2) return DivCode.NONE

        val pivotHighIdxs = mutableListOf<Int>()
        val pivotLowIdxs = mutableListOf<Int>()

        val latestConfirmIdx = n - 1 - pivotSpan
        val earliestIdx = max(pivotSpan, n - maxLookback)

        for (i in latestConfirmIdx downTo earliestIdx) {
            var isHigh = true
            var isLow = true
            for (k in 1..pivotSpan) {
                if (highs[i] <= highs[i - k] || highs[i] < highs[i + k]) isHigh = false
                if (lows[i] >= lows[i - k] || lows[i] > lows[i + k]) isLow = false
            }
            if (isHigh && pivotHighIdxs.size < 2) pivotHighIdxs.add(i)
            if (isLow && pivotLowIdxs.size < 2) pivotLowIdxs.add(i)
            if (pivotHighIdxs.size >= 2 && pivotLowIdxs.size >= 2) break
        }

        if (pivotLowIdxs.size >= 2) {
            val p2 = pivotLowIdxs[0]
            val p1 = pivotLowIdxs[1]
            if (n - 1 - p2 <= pivotSpan + 3) {
                if (lows[p2] < lows[p1] && osc[p2] > osc[p1]) return DivCode.BULL_REGULAR
                if (lows[p2] > lows[p1] && osc[p2] < osc[p1]) return DivCode.BULL_HIDDEN
            }
        }

        if (pivotHighIdxs.size >= 2) {
            val p2 = pivotHighIdxs[0]
            val p1 = pivotHighIdxs[1]
            if (n - 1 - p2 <= pivotSpan + 3) {
                if (highs[p2] > highs[p1] && osc[p2] < osc[p1]) return DivCode.BEAR_REGULAR
                if (highs[p2] < highs[p1] && osc[p2] > osc[p1]) return DivCode.BEAR_HIDDEN
            }
        }

        return DivCode.NONE
    }

    private fun classifyMarketRegime(
        close: Double,
        emaFast: Double,
        emaMid: Double,
        emaSlow: Double,
        adx: AdxTuple,
        boll: BollTuple,
        isSqueeze: Boolean,
        er: Double,
        atrPct: Double,
        thresholds: RegimeThresholds
    ): RegimeCode {
        if (isSqueeze || boll.bwPercentile <= thresholds.squeezeBwPctMax) {
            return RegimeCode.VOL_SQUEEZE_BREAKOUT_PREP
        }
        if (boll.bwPercentile >= thresholds.extremeBwPctMin && atrPct >= thresholds.extremeAtrPctMin) {
            return RegimeCode.VOL_EXTREME_EXPANSION
        }
        val bullStack = close > emaFast && emaFast > emaMid && emaMid > emaSlow
        val bearStack = close < emaFast && emaFast < emaMid && emaMid < emaSlow

        if (adx.adx >= thresholds.adxTrendMin && er >= thresholds.erTrendMin) {
            if (bullStack && adx.pDi > adx.mDi) return RegimeCode.TREND_BULL_STRONG
            if (bearStack && adx.mDi > adx.pDi) return RegimeCode.TREND_BEAR_STRONG
            return RegimeCode.TREND_WEAK
        }
        if (adx.adx < thresholds.adxRangeMax && er < thresholds.erRangeMax) {
            return RegimeCode.RANGE_MEAN_REVERT
        }
        return RegimeCode.TREND_WEAK
    }
}
