package com.tradingassistant.core.risk

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class MarketType { SPOT, FUTURES }
enum class TradeDirection { LONG, SHORT }

data class HorizonMapping(
    val sliderValue: Int,
    val categoryName: String,
    val higherTimeframe: String,
    val executionTimeframe: String,
    val riskMultiplier: Double
)

data class PositionSizingInput(
    val symbol: String,
    val marketType: MarketType,
    val direction: TradeDirection,
    val totalCapitalUsdt: Double,
    val baseRiskPct: Double,
    val entryPrice: Double,
    val currentMarkPrice: Double,
    val stopLossPrice: Double,
    val takeProfit1Price: Double,
    val takeProfit2Price: Double?,
    val requestedLeverage: Int,
    val maxAllowedLeverage: Int,
    val takerFeeRate: Double = 0.0005,
    val estimatedSlippagePct: Double = 0.0005,
    val fundingRatePer8h: Double = 0.0001,
    val expectedHoldingHours: Double = 8.0,
    val maintenanceMarginRate: Double = 0.004,
    val currentBaselineAtrPct: Double = 0.015,
    val currentRealizedAtrPct: Double = 0.015,
    val openPositionsRiskUsdt: Double = 0.0,
    val openPositionsCount: Int = 0,
    val maxConcurrentPositions: Int = 3,
    val hasSameDirectionCorrelatedTrade: Boolean = false,
    val todayRealizedLossUsdt: Double = 0.0,
    val todayLossUtcDayIndex: Long = -1L,
    val maxDailyLossPct: Double = 3.0,
    val maxTotalRiskExposurePct: Double = 5.0,
    val consecutiveLossesCount: Int = 0,
    val maxConsecutiveLosses: Int = 3,
    val cooldownUntilEpochSec: Long = 0L,
    val currentEpochSec: Long
)

data class PositionSizingResult(
    val isAllowed: Boolean,
    val rejectionReason: String?,
    val recommendedQuantityCoin: Double,
    val notionalPositionValueUsdt: Double,
    val requiredMarginUsdt: Double,
    val safeLeverage: Int,
    val estimatedLiquidationPrice: Double?,
    val exactDollarAtRiskUsdt: Double,
    val effectiveRiskPctOfCapital: Double,
    val feeAndFundingImpactUsdt: Double,
    val netRewardToRiskTp1: Double,
    val netRewardToRiskTp2: Double?,
    val warnings: List<String>
)

object RiskAndPsychologyEngine {

    fun mapHorizonSlider(sliderValue: Int): HorizonMapping {
        val clamped = sliderValue.coerceIn(0, 100)
        return when {
            clamped < 35 -> HorizonMapping(
                sliderValue = clamped,
                categoryName = "SHORT_TERM_INTRADAY",
                higherTimeframe = "1h",
                executionTimeframe = "5m",
                riskMultiplier = 0.75
            )
            clamped <= 70 -> HorizonMapping(
                sliderValue = clamped,
                categoryName = "MEDIUM_TERM_SWING",
                higherTimeframe = "4h",
                executionTimeframe = "15m",
                riskMultiplier = 1.0
            )
            else -> HorizonMapping(
                sliderValue = clamped,
                categoryName = "LONG_TERM_POSITION",
                higherTimeframe = "1d",
                executionTimeframe = "1h",
                riskMultiplier = 1.0
            )
        }
    }

    fun resolveTieredMaintenanceMarginRate(notionalUsdt: Double, baseMmr: Double): Double {
        return when {
            notionalUsdt > 1_000_000.0 -> max(baseMmr, 0.025)
            notionalUsdt > 250_000.0 -> max(baseMmr, 0.010)
            notionalUsdt > 50_000.0 -> max(baseMmr, 0.005)
            else -> max(0.001, baseMmr)
        }
    }

    fun calculatePositionSize(input: PositionSizingInput): PositionSizingResult {
        val warnings = mutableListOf<String>()

        if (!isValidPositive(input.totalCapitalUsdt) ||
            !isValidPositive(input.entryPrice) ||
            !isValidPositive(input.currentMarkPrice) ||
            !isValidPositive(input.stopLossPrice) ||
            !isValidPositive(input.takeProfit1Price) ||
            !isValidPositive(input.baseRiskPct) ||
            input.requestedLeverage <= 0 ||
            input.maxAllowedLeverage <= 0
        ) {
            return rejected("INVALID_NUMERIC_INPUT_PARAMETERS")
        }

        if (input.currentEpochSec < input.cooldownUntilEpochSec) {
            val remainingMin = max(1L, (input.cooldownUntilEpochSec - input.currentEpochSec) / 60L)
            return rejected("COOLDOWN_LOCK_ACTIVE_${remainingMin}_MIN_REMAINING")
        }

        val cooldownExpired = input.cooldownUntilEpochSec > 0L && input.currentEpochSec >= input.cooldownUntilEpochSec
        val effectiveConsecutiveLosses = if (cooldownExpired) 0 else input.consecutiveLossesCount
        if (effectiveConsecutiveLosses >= input.maxConsecutiveLosses) {
            return rejected("MAX_CONSECUTIVE_LOSSES_REACHED_${input.maxConsecutiveLosses}")
        }

        if (input.openPositionsCount >= input.maxConcurrentPositions) {
            return rejected("MAX_CONCURRENT_POSITIONS_REACHED_${input.maxConcurrentPositions}")
        }

        if (input.marketType == MarketType.SPOT && input.direction == TradeDirection.SHORT) {
            return rejected("SHORT_NOT_ALLOWED_IN_SPOT")
        }

        if (input.direction == TradeDirection.LONG) {
            if (input.stopLossPrice >= input.entryPrice) {
                return rejected("INVALID_LONG_SL_ABOVE_ENTRY")
            }
            if (input.takeProfit1Price <= input.entryPrice) {
                return rejected("INVALID_LONG_TP_BELOW_ENTRY")
            }
        } else {
            if (input.stopLossPrice <= input.entryPrice) {
                return rejected("INVALID_SHORT_SL_BELOW_ENTRY")
            }
            if (input.takeProfit1Price >= input.entryPrice) {
                return rejected("INVALID_SHORT_TP_ABOVE_ENTRY")
            }
        }

        val currentUtcDay = input.currentEpochSec / 86_400L
        val effectiveTodayLoss = if (input.todayLossUtcDayIndex >= 0L && currentUtcDay != input.todayLossUtcDayIndex) {
            0.0
        } else {
            max(0.0, input.todayRealizedLossUsdt)
        }

        val maxDailyLossUsdt = input.totalCapitalUsdt * (input.maxDailyLossPct / 100.0)
        if (effectiveTodayLoss >= maxDailyLossUsdt) {
            return rejected("DAILY_DRAWDOWN_LIMIT_REACHED_${input.maxDailyLossPct}_PCT")
        }
        val remainingDailyRiskBudget = maxDailyLossUsdt - effectiveTodayLoss

        val maxRiskExposureUsdt = input.totalCapitalUsdt * (input.maxTotalRiskExposurePct / 100.0)
        val remainingExposureBudget = maxRiskExposureUsdt - max(0.0, input.openPositionsRiskUsdt)
        if (remainingExposureBudget <= 0.0) {
            return rejected("MAX_PORTFOLIO_RISK_EXPOSURE_REACHED_${input.maxTotalRiskExposurePct}_PCT")
        }

        val volScale = if (input.currentRealizedAtrPct > 0.0 && input.currentBaselineAtrPct > 0.0) {
            (input.currentBaselineAtrPct / input.currentRealizedAtrPct).coerceIn(0.35, 1.0)
        } else 1.0
        if (volScale < 0.85) {
            warnings.add("VOLATILITY_TARGETING_SCALED_TO_${(volScale * 100).toInt()}_PCT")
        }

        val correlationScale = if (input.hasSameDirectionCorrelatedTrade) {
            warnings.add("CORRELATED_ASSET_PENALTY_40_PCT_APPLIED")
            0.60
        } else 1.0

        val rawPlannedRiskUsdt = input.totalCapitalUsdt * (input.baseRiskPct / 100.0) * volScale * correlationScale
        val finalRiskUsdt = min(rawPlannedRiskUsdt, min(remainingDailyRiskBudget, remainingExposureBudget))

        val effectiveEntry = if (input.direction == TradeDirection.LONG) {
            input.entryPrice * (1.0 + input.estimatedSlippagePct)
        } else {
            input.entryPrice * (1.0 - input.estimatedSlippagePct)
        }

        val effectiveStop = if (input.direction == TradeDirection.LONG) {
            input.stopLossPrice * (1.0 - input.estimatedSlippagePct)
        } else {
            input.stopLossPrice * (1.0 + input.estimatedSlippagePct)
        }

        val priceStopDistancePerCoin = abs(effectiveEntry - effectiveStop)
        val feePerCoin = (effectiveEntry * input.takerFeeRate) + (effectiveStop * input.takerFeeRate)
        val fundingPeriods = max(0.0, floor(input.expectedHoldingHours / 8.0))
        val fundingPerCoin = if (input.marketType == MarketType.FUTURES) {
            effectiveEntry * abs(input.fundingRatePer8h) * fundingPeriods
        } else 0.0

        val totalLossPerCoinAtStop = priceStopDistancePerCoin + feePerCoin + fundingPerCoin
        if (totalLossPerCoinAtStop <= 0.0) {
            return rejected("ZERO_STOP_DISTANCE_INVALID")
        }

        var quantityCoin = finalRiskUsdt / totalLossPerCoinAtStop
        var notionalUsdt = quantityCoin * effectiveEntry

        var safeLeverage = if (input.marketType == MarketType.SPOT) {
            1
        } else {
            min(input.requestedLeverage, input.maxAllowedLeverage).coerceAtLeast(1)
        }

        if (input.marketType == MarketType.SPOT && notionalUsdt > input.totalCapitalUsdt) {
            notionalUsdt = input.totalCapitalUsdt
            quantityCoin = notionalUsdt / effectiveEntry
            warnings.add("SPOT_NOTIONAL_CAPPED_AT_TOTAL_CAPITAL")
        }

        var estimatedLiqPrice: Double? = null
        if (input.marketType == MarketType.FUTURES) {
            val tieredMmr = resolveTieredMaintenanceMarginRate(notionalUsdt, input.maintenanceMarginRate)
            val stopDistPct = abs(input.currentMarkPrice - effectiveStop) / input.currentMarkPrice
            val maxSafeLevForStop = floor(1.0 / ((stopDistPct * 1.35) + tieredMmr)).toInt().coerceAtLeast(1)
            if (safeLeverage > maxSafeLevForStop) {
                safeLeverage = maxSafeLevForStop
                warnings.add("LEVERAGE_REDUCED_TO_${safeLeverage}X_FOR_MARK_PRICE_LIQUIDATION_SAFETY")
            }

            estimatedLiqPrice = if (input.direction == TradeDirection.LONG) {
                input.currentMarkPrice * (1.0 - (1.0 / safeLeverage) + tieredMmr)
            } else {
                input.currentMarkPrice * (1.0 + (1.0 / safeLeverage) - tieredMmr)
            }
        }

        val requiredMarginUsdt = notionalUsdt / safeLeverage
        if (requiredMarginUsdt > input.totalCapitalUsdt) {
            val scaleDown = (input.totalCapitalUsdt * 0.95) / requiredMarginUsdt
            quantityCoin *= scaleDown
            notionalUsdt = quantityCoin * effectiveEntry
            warnings.add("POSITION_SCALED_TO_AVAILABLE_FREE_MARGIN")
        }

        val actualRiskUsdt = quantityCoin * totalLossPerCoinAtStop
        val feeAndFundingUsdt = quantityCoin * (feePerCoin + fundingPerCoin)

        val grossProfitPerCoinTp1 = abs(input.takeProfit1Price - effectiveEntry)
        val netProfitUsdtTp1 = (quantityCoin * grossProfitPerCoinTp1) - feeAndFundingUsdt
        val netRrTp1 = if (actualRiskUsdt > 0.0) netProfitUsdtTp1 / actualRiskUsdt else 0.0

        val netRrTp2 = input.takeProfit2Price?.let { tp2 ->
            val grossTp2 = abs(tp2 - effectiveEntry)
            val netTp2 = (quantityCoin * grossTp2) - feeAndFundingUsdt
            if (actualRiskUsdt > 0.0) netTp2 / actualRiskUsdt else 0.0
        }

        if (netRrTp1 < 1.2) {
            warnings.add("NET_RR_BELOW_1_2_AFTER_FEES_${round2(netRrTp1)}")
        }

        return PositionSizingResult(
            isAllowed = true,
            rejectionReason = null,
            recommendedQuantityCoin = round6(quantityCoin),
            notionalPositionValueUsdt = round2(notionalUsdt),
            requiredMarginUsdt = round2(notionalUsdt / safeLeverage),
            safeLeverage = safeLeverage,
            estimatedLiquidationPrice = estimatedLiqPrice?.let { round2(it) },
            exactDollarAtRiskUsdt = round2(actualRiskUsdt),
            effectiveRiskPctOfCapital = round2((actualRiskUsdt / input.totalCapitalUsdt) * 100.0),
            feeAndFundingImpactUsdt = round2(feeAndFundingUsdt),
            netRewardToRiskTp1 = round2(netRrTp1),
            netRewardToRiskTp2 = netRrTp2?.let { round2(it) },
            warnings = warnings
        )
    }

    fun calculateDouglasAdherenceScore(
        movedStopLossWider: Boolean,
        exitedPrematurelyOutOfFear: Boolean,
        enteredOutsideZoneOnFomo: Boolean,
        exceededPlannedRisk: Boolean
    ): Double {
        var score = 100.0
        if (movedStopLossWider) score -= 45.0
        if (exceededPlannedRisk) score -= 35.0
        if (enteredOutsideZoneOnFomo) score -= 20.0
        if (exitedPrematurelyOutOfFear) score -= 20.0
        return max(0.0, score)
    }

    fun calculateStatisticalConfidencePct(
        sampleSize: Int,
        winRate: Double,
        avgWinR: Double,
        avgLossR: Double,
        numStrategiesTested: Int = 1
    ): Double {
        if (sampleSize < 20) return 0.0
        val lossRate = 1.0 - winRate
        val expectancyR = (winRate * avgWinR) - (lossRate * avgLossR)
        if (expectancyR <= 0.0) return 0.0

        val varianceR = (winRate * (avgWinR - expectancyR) * (avgWinR - expectancyR)) +
            (lossRate * (-avgLossR - expectancyR) * (-avgLossR - expectancyR))
        val stdR = sqrt(max(1e-9, varianceR))
        val sharpe = expectancyR / stdR

        val srBenchmark = expectedMaxSharpeNull(max(1, numStrategiesTested), 1.0 / sampleSize.toDouble())
        val seSharpe = sqrt((1.0 + 0.5 * sharpe * sharpe) / max(1, sampleSize - 1).toDouble())
        val z = (sharpe - srBenchmark) / max(1e-9, seSharpe)
        return (normalCdf(z) * 100.0).coerceIn(0.0, 99.9)
    }

    fun expectedMaxSharpeNull(numTrials: Int, srVariance: Double): Double {
        if (numTrials <= 1) return 0.0
        val gamma = 0.5772156649
        val n = numTrials.toDouble()
        val term1 = (1.0 - gamma) * normalInv(1.0 - (1.0 / n))
        val term2 = gamma * normalInv(1.0 - (1.0 / (n * exp(1.0))))
        return sqrt(max(1e-9, srVariance)) * (term1 + term2)
    }

    fun normalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.39894228
        return if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            1.0 - c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        } else {
            val t = 1.0 / (1.0 - p * x)
            c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        }
    }

    fun normalInv(p: Double): Double {
        val boundP = min(max(p, 1e-6), 1.0 - 1e-6)
        val t = sqrt(-2.0 * ln(if (boundP < 0.5) boundP else 1.0 - boundP))
        val c0 = 2.515517
        val c1 = 0.802853
        val c2 = 0.010328
        val d1 = 1.432788
        val d2 = 0.189269
        val d3 = 0.001308
        val xp = t - (c0 + c1 * t + c2 * t * t) / (1.0 + d1 * t + d2 * t * t + d3 * t * t * t)
        return if (boundP < 0.5) -xp else xp
    }

    private fun isValidPositive(v: Double): Boolean = !v.isNaN() && !v.isInfinite() && v > 0.0

    private fun rejected(reason: String) = PositionSizingResult(
        isAllowed = false,
        rejectionReason = reason,
        recommendedQuantityCoin = 0.0,
        notionalPositionValueUsdt = 0.0,
        requiredMarginUsdt = 0.0,
        safeLeverage = 1,
        estimatedLiquidationPrice = null,
        exactDollarAtRiskUsdt = 0.0,
        effectiveRiskPctOfCapital = 0.0,
        feeAndFundingImpactUsdt = 0.0,
        netRewardToRiskTp1 = 0.0,
        netRewardToRiskTp2 = null,
        warnings = emptyList()
    )

    private fun round2(v: Double): Double = kotlin.math.round(v * 100.0) / 100.0
    private fun round6(v: Double): Double = kotlin.math.round(v * 1_000_000.0) / 1_000_000.0
}
