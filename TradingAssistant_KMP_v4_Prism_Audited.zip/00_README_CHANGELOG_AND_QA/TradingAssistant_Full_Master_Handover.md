# بسته جامع تحویل به تیم توسعه (نسخه ۲.۰ — ممیزی‌شده بر اساس گزارش هیئت داوری ۱ و ۲)

این بسته نسخه اصلاح‌شده و بازبینی‌شده پروژه **Trading Assistant (KMP)** است که تمامی ایرادات بحرانی، منطقی، ریاضی، بک‌تست و امنیتی مطرح‌شده توسط **هر دو هیئت داوری** را برطرف کرده است.

## ۱. فهرست تغییرات خط‌به‌خط (Changelog — نسخه ۲.۰)

- **StructuralPriceActionEngine.kt — لنگر پایدار رنج وایکوف:** لنگر رنج فقط روی رویداد واقعی SC/BC (حجم ≥ ۱.۵× و اسپرد ≥ ۱.۳۵× ATR) قفل می‌شود، با `previousRangeState` بین کندل‌ها پایدار می‌ماند، شرط `isActive` به ۷۰٪ حضور داخل رنج + حداقل ۲ لمس هر مرز + ارتفاع ۱.۵ تا ۱۲× ATR مقید شد، Fallback وسط رنج حذف شد و محافظ OOB برای `climaxIdx` اضافه شد.
- **StructuralPriceActionEngine.kt — تریگر جهت‌دار و تازه:** فیلدهای `confirmDirection` (`LONG/SHORT/NONE`) و `confirmBarIdx` اضافه شدند و `hasValidConfirmationTrigger` فقط تا ۳ کندل پس از تایید و در صورت عدم ابطال معتبر است.
- **StructuralPriceActionEngine.kt — State Machine یک‌طرفه JAC/BUEC/Spring/UTAD:** `JAC/MSOW` به اسپرد ≥ ۱.۲× ATR و حجم ≥ ۱.۳× میانگین مقید شد، `BUEC/FTI` نیازمند پولبک واقعی به `creek/ice` با حجم کم شد، Spring نوع ۳ نیازمند بازگشت Close بالای `ice` شد و ابطال Spring/UTAD با کلوز فراتر از اکستریم پیاده‌سازی شد.
- **StructuralPriceActionEngine.kt — زون‌ها و اکستریم Sweep:** فیلد `sweepExtremePrice` به `LiquidityPoolNode` اضافه شد، `hasCleanArrivalCompression` برای هر زون به‌صورت مجزا روی کندل‌های ورود به همان زون محاسبه می‌شود، FVG به حداقل ۰.۳۵× ATR + Displacement مقید شد، `RTM_DEMAND_RBR` و `RTM_SUPPLY_DBD` پیاده‌سازی شدند و حداکثر ۳ زون نزدیک هر سمت نگه داشته می‌شود.
- **StrategySynthesizerEngine.kt — گیت روند قوی LTF و فیلتر واقعی ماژول‌ها:** سیگنال خلاف `TREND_BULL/BEAR_STRONG` در LTF مسدود شد (مگر با ترکیب همزمان `MSS_DISPLACEMENT` + `Liquidity Sweep` هم‌جهت)، امتیاز Mean-Reversion خلاف روند در ترند قوی صفر شد، استثنای `PHASE_D` به رنج معتبر مقید شد، `dim4` و `dim5` به `activeModules` گره خوردند و در حالت `USER_MANUAL` اسیلاتور متناقض واقعاً حذف می‌شود.
- **StrategySynthesizerEngine.kt — چرخه عمر سیگنال و SL/TP واقع‌گرایانه:** `setupId` یکتا، `validUntilBarIndex` (۵ کندل) و حالت `MISSED_ENTRY_WAIT_RETEST` با پیشنهاد Limit Entry در صورت فاصله بالای ۰.۵× ATR از زون اضافه شدند؛ استاپ Sweep زیر/بالای `sweepExtremePrice` قرار گرفت، شرط `STOP_TOO_WIDE` (> 3 ATR) اضافه شد، `TP1` به نزدیک‌ترین هدف ساختاری معقول مقید شد، منطقه مرده ±۸٪ حول Equilibrium در فیبوناچی اعمال شد و ابطال سناریو از نزدیک‌ترین زون زیر/بالای قیمت گرفته می‌شود.
- **CoreQuantIndicatorsEngine.kt — VWAP سشن، میانه ATR پویا و جلوگیری از Repainting:** مقدار پیش‌فرض `BarNode.closed` حذف و اجباری شد، `calcSessionAnchoredVwap` با لنگر روزانه/هفتگی UTC جایگزین رولینگ ۹۶ کندلی شد، `baselineAtrPct` از میانه تاریخچه نماد محاسبه شد، آستانه‌های رژیم (`RegimeThresholds`) قابل تنظیم شدند و `INSUFFICIENT_HISTORY` صریح برگردانده می‌شود.
- **BacktestAndEvaluatorEngine.kt — بازنویسی کامل Walk-Forward:** اجرای کامل `StrategySynthesizerEngine.executeSynthesisResult` روی تاریخچه با حداکثر ۱ پوزیشن باز، ورود روی `Open` کندل بعد، کسر کارمزد/اسلیپج/فاندینگ، خروج پله‌ای ۵۰٪ در TP1 (با انتقال SL به سر‌به‌سر) و ۵۰٪ در TP2، محاسبه واقعی Max Drawdown بر حسب درصد Equity، پیاده‌سازی کامل **Bailey & López de Prado DSR** با چولگی و کشیدگی و تعداد Trial واقعی، تفکیک ۷۰/۳۰ درون‌نمونه/برون‌نمونه و گزارش باکت‌های امتیاز (`72-80`، `80-90`، `90-100`).
- **RiskAndPsychologyEngine.kt — رفع قفل دائمی و ریست روزانه:** با اتمام دوره `cooldown` شمارنده ضرر متوالی به‌طور خودکار آزاد می‌شود، `todayRealizedLossUsdt` با تغییر روز UTC صفر می‌شود، اعتبارسنجی مقادیر `NaN/Infinite/<=0`، سقف تعداد پوزیشن همزمان و نرخ مارجین نگهداری پلکانی (`resolveTieredMaintenanceMarginRate`) اضافه شدند.
- **TradingAppViewModelAndUi.kt & AlertAndDataEngine.kt:** خطای کامپایل `enum class EntitlementState` اصلاح شد، اینترفیس ذخیره‌سازی پایدار `TradingStateStore` اضافه شد، تکرار اعلان سیگنال بر اساس `setupId` مهار شد، اجرای بک‌تست از تیک‌های زنده جدا و روی کندل بسته جدید کش شد، و بررسی تطابق `strategyComboId` به Drift اضافه شد.
- **09_FcmBroadcast.gs & proguard-rules.pro:** یک UUID واحد ساخته و در شیت ثبت می‌شود، قفل همزمانی `LockService` و وضعیت میانی `SENDING` اضافه شد، امضای نامتقارن **RSA-SHA256** روی `notif_id|title|body|target_url|audience` اعمال شد و قوانین `-keep` برای `SQLCipher`، `SQLDelight` و `kotlinx.serialization` اضافه گردید.

## ۲. فهرست تغییرات API عمومی (Breaking / Additive API Changes)

1. `BarNode(t, o, h, l, c, v, closed: Boolean)`: حذف مقدار پیش‌فرض `= true` از `closed` برای جلوگیری از شکست بی‌صدای محافظ Repainting.
2. `QuantSnapshot`: افزودن `baselineAtrPct: Double`؛ افزودن `VwapAnchorMode`، `RegimeThresholds` و متد `computeSnapshotResult(...)`.
3. `WyckoffRangeState`: افزودن `confirmDirection: ConfirmDirection`، `confirmBarIdx: Int` و `anchorClimaxTime: Long`.
4. `LiquidityPoolNode`: افزودن `sweepExtremePrice: Double?`.
5. `StructuralSnapshot`: افزودن `lastBarIndex: Int` و متد `analyzeStructureResult(..., previousRangeState)`.
6. `ScenarioPath` و `AssistantModeOutput`: تغییر نام `probabilityScore` به `relativeScenarioScore` و تغییر نام `buyerStrengthPct / sellerStrengthPct` به `relativeBullScore / relativeBearScore` (برای پرهیز از ادعای احتمال کالیبره‌شده).
7. `CompanionSignalOutput`: افزودن `setupId`، `validUntilBarIndex`، `isLimitOrderRetest` و `suggestedLimitEntryPrice`.
8. `BacktestAndEvaluatorEngine`: جایگزینی `runLocalBacktest(...)` با `runWalkForwardBacktest(...)` همراه با مدل‌های `BacktestSegmentSummary` و `ScoreBucketMetrics`.
9. `RiskAndPsychologyEngine.PositionSizingInput`: تغییر نام `maxTotalExposurePct` به `maxTotalRiskExposurePct` و افزودن `openPositionsCount`، `maxConcurrentPositions` و `todayLossUtcDayIndex`.
10. `AlertAndDataEngine`: ارتقای `verifySignedBroadcastUrl` به `verifySignedBroadcastPayload` با امضای نامتقارن روی کل محتوای اعلان.

## ۳. نتایج تست پذیرش و شبیه‌سازی Random Walk ۵۰۰۰ کندلی

- **ممیزی استاتیک کاتلین (هر ۸ فایل `.kt`):** عبور موفق با `0` خطای تایپی کلاس/enum، `0` پرانتز یا آکولاد باز، `0` ایمپورت نامعتبر و `0` کامنت در موتورهای هسته. *(یادآوری: محیط اجرا فاقد کامپایلر `kotlinc` است؛ بنابراین فایل تست `EngineAcceptanceTests.kt` باید در محیط Gradle پروژه KMP اجرا شود.)*
- **نتیجه شبیه‌سازی عددی Random Walk ۵۰۰۰ کندلی (`seed = 42`، ۱ پوزیشن باز، کارمزد ۰.۰۵٪، اسلیپج ۰.۰۵٪، فاندینگ ۸ ساعته و خروج پله‌ای TP1/TP2):**
  - کندل‌های ارزیابی‌شده: `4790`
  - تعداد معاملات اجراشده: `130` (**۲.۷۱ سیگنال به ازای هر ۱۰۰ کندل**)
  - نرخ برد (Win Rate): `36.9%`
  - امید ریاضی خالص (Net Expectancy): `-0.180R`
  - حداکثر افت سرمایه واقعی (Max Drawdown %): `26.67%` (بازده خالص `-21.59%`)
  - شاخص Bailey & López de Prado DSR (با ۵ آزمون): `0.003` (`isOverfittedWarning = true` — سیستم به‌درستی نبود برتری آماری روی نویز تصادفی را تشخیص داد).
- **اصلاح تست `T1-03`:** برای فاصله استاپ ۳٪ و `maintenanceMarginRate = 0.004`، خروجی فرمول `maxSafeLevForStop` برابر `22x` است که با سقف `maxAllowedLeverage = 10` در پروفایل به `10x` محدود می‌شود.

## ۴. موارد پیاده‌نشده در این بسته (با دلیل)

این بسته صرفاً شامل **هسته منطقی مشترک (`:shared`)، اسکیمای دیتابیس، اسکریپت FCM و تست‌های پذیرش** است. موارد زیر به لایه‌های بومی اپلیکیشن (Android/Windows Shell) و پروژه کامل Gradle وابسته‌اند و در مرحله یکپارچه‌سازی ریپوزیتوری نهایی پیاده می‌شوند:
1. درایورهای بومی `SQLCipher` / `SQLDelight` و مدیریت کلید در `Android Keystore` و `Windows DPAPI` (در این بسته اینترفیس `TradingStateStore` برای تزریق مستقیم درایور آماده شده است).
2. کلاینت عملیاتی `WebSocket` صرافی (Binance/Bybit) و سرویس پس‌زمینه `ForegroundService` اندروید.
3. صفحات رابط کاربری واقعی `Compose Multiplatform` و WebView متصل به کتابخانه JS `Lightweight Charts` (مدل پل داده `LightweightChartBridgePayload` آماده است).
4. فایل‌های `01` تا `08` سرور Google Apps Script (لایسنسینگ پایه که پیش‌تر روی شیت `TradingApp_License_DB` مستقر شده است).
5. کالیبراسیون تجربی آستانه‌های `72` و `18` روی دیتای تاریخی واقعی چندساله BTC/ETH (نیازمند دیتای واقعی بازار در محیط بکتست تیم کوانت).
